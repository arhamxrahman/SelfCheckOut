package Checkout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;

public class MembershipControllerTest extends BaseTest {
	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testManualMembershipEntry() {
		membershipController.enterMembership();
		assertTrue(isEnabledMembershipEntry());
		membershipController.manualEntry(cardNumber);
		assertEquals(membershipController.getMembershipNumber(), cardNumber);
		assertTrue(isDisabledFromPayments());
	}

	@Test
	public void testSwipeMembershipEntry() {
		membershipController.enterMembership();
		assertTrue(isEnabledMembershipEntry());
		try {
			scs.cardReader.swipe(membershipCard);
			scs.cardReader.remove();
			assertEquals(membershipController.getMembershipNumber(), cardNumber);
			assertTrue(isDisabledFromPayments());
		} catch (IOException e) {

		}
	}

	@Test
	public void testTapMembershipCard() {
		membershipController.enterMembership();
		assertTrue(isEnabledMembershipEntry());
		try {
			scs.cardReader.tap(membershipCard);
			assertEquals(membershipController.getMembershipNumber(), cardNumber);
			assertTrue(isDisabledFromPayments());
		} catch (IOException e) {

		}
	}

	@Test
	public void testInsertMembershipCard() {
		membershipController.enterMembership();
		assertTrue(isEnabledMembershipEntry());
		try {
			scs.cardReader.insert(membershipCard, pin);
			assertEquals(membershipController.getMembershipNumber(), null);
			assertFalse(isDisabledFromPayments());
		} catch (IOException e) {

		}
	}

	private boolean isEnabledMembershipEntry() {
		return !scs.cardReader.isDisabled() && scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled()
				&& scs.scanningArea.isDisabled() && scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled()
				&& scs.banknoteInput.isDisabled() && scs.printer.isDisabled();
	}

	private boolean isDisabledFromPayments() {
		return !scs.mainScanner.isDisabled() && !scs.handheldScanner.isDisabled() && !scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && !scs.printer.isDisabled();
	}
}

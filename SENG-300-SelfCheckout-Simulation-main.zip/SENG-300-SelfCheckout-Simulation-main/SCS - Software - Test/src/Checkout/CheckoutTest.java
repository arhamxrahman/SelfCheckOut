package Checkout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;
import Station.StationState;

public class CheckoutTest extends BaseTest {
	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testPayWithMixedPayments() throws OverloadException, DisabledException, IOException {
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.coinSlot.accept(loonie);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 1.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 1.00, 0.0);
		assertFalse(checkout.isPaidInFull());
		assertTrue(isDisabledFromPayments());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);

		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		scs.baggingArea.add(item1);
		int numOfBags = 2;
		cart.addPlasticBags(numOfBags);
		BigDecimal pricePerBag = new BigDecimal(0.1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CREDIT);
		checkout.setAmountToPay(priceItem1.add(new BigDecimal(0.24))
				.add(pricePerBag.multiply(new BigDecimal(numOfBags))).setScale(2, RoundingMode.HALF_DOWN));

		scs.cardReader.insert(creditCard, pin);
		scs.cardReader.remove();
		assertEquals(checkout.getTotalPayments().doubleValue(), 7.43, 0.0);

		assertTrue(checkout.isPaidInFull());
		assertTrue(isDisabledFromPayments());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);

		scs.baggingArea.remove(item1);
		scs.baggingArea.remove(item5);
	}

	@Test
	public void testEmptyDispenser() throws DisabledException, OverloadException {
		for (BigDecimal dispenser : scs.coinDispensers.keySet()) {
			scs.coinDispensers.get(dispenser).unload();
		}
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		scs.baggingArea.add(item1);
		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);
		scs.banknoteInput.accept(fiveDollars);
		scs.coinSlot.accept(toonie);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 7.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 7.00, 0.0);
		assertTrue(checkout.isPaidInFull());
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.SUSPEND);
	}

	@Test
	public void testDefaultPaymentMethod() {
		checkout.selectPaymentMethod(PaymentMethod.PENDING);
		assertFalse(isEnabledCashPayment());
	}

	@Test
	public void testSetAmountToPayInPendingState() {
		checkout.startCheckout();
		assertTrue(isDisabledFromAddingItems());
		checkout.selectPaymentMethod(PaymentMethod.CASH);
		assertTrue(isEnabledCashPayment());
		assertFalse(isEnabledCardPayment());
		checkout.setAmountToPay(new BigDecimal(10));
	}

	@Test
	public void testReturnToShopping() {
		checkout.returnToShopping();
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.ADDING);
	}

	private boolean isDisabledFromAddingItems() {
		return scs.mainScanner.isDisabled() && scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled()
				&& scs.scanningArea.isDisabled() && scs.baggingArea.isDisabled() && scs.printer.isDisabled();
	}

	private boolean isEnabledCashPayment() {
		return !scs.coinSlot.isDisabled() && !scs.banknoteInput.isDisabled() && scs.cardReader.isDisabled();
	}

	private boolean isEnabledCardPayment() {
		return !scs.cardReader.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled();
	}

	private boolean isDisabledFromPayments() {
		return !scs.mainScanner.isDisabled() && !scs.handheldScanner.isDisabled() && !scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && !scs.printer.isDisabled();
	}
}

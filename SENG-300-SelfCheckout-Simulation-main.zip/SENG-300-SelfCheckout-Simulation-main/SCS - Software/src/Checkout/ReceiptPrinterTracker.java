package Checkout;

import java.util.ArrayList;

import org.lsmr.selfcheckout.devices.EmptyException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.ReceiptPrinter;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

//Each class that implements the ReceiptPrinter can also implement this and pass the Station object in to gain access to the ReceiptPrinter before using it to track whether it is low.

public class ReceiptPrinterTracker {
	ReceiptPrinter printer;
	int linesOfPaperRemaining = 0;
	int charactersOfInkRemaining = 0;
	int lowPaperThreshold = 3; // Number of lines remaining which are considered low
	int lowInkThreshold = 3; // Number of chars remaining which are considered low

	private ArrayList<ReceiptPrinterTrackerObserver> observers = new ArrayList<>();

	public void attach(ReceiptPrinterTrackerObserver observer) {
		this.observers.add(observer);
	}

	public void detach(ReceiptPrinterTrackerObserver observer) {
		this.observers.remove(observer);
	}

	// Can either pass in the station to get the ReceiptPrinter from it
	public ReceiptPrinterTracker(SelfCheckoutStation station) {
		this.printer = station.printer;
	}

	public ReceiptPrinterTracker(SelfCheckoutStation station, int lowInkThreshold, int lowPaperThreshold) {
		this.printer = station.printer;
		this.lowPaperThreshold = lowPaperThreshold;
		this.lowInkThreshold = lowInkThreshold;
	}

	public void addPaper(int units) throws OverloadException {
		printer.addPaper(units);

		linesOfPaperRemaining += units;
	}

	public void addInk(int quantity) throws OverloadException {
		printer.addInk(quantity);

		charactersOfInkRemaining += quantity;
	}

	public void print(char c) throws EmptyException, OverloadException {
		printer.print(c);

		if (c == '\n') {
			linesOfPaperRemaining--;
		} else if (c != ' ' && Character.isWhitespace(c))
			return;
		else {
			charactersOfInkRemaining--;
		}
		// If the amount of characters able to be printed is 0 or less, notify that ink
		// is empty.
		// Else, if characters left is less than low threshold of remaining ink, notify
		// that the ink is low.
		if (charactersOfInkRemaining <= 0) {
			notifyEmptyInk();
		} else if (charactersOfInkRemaining <= lowInkThreshold) {
			notifyLowInk();
		}

		// If the amount of lines able to be printed is 0 or less, notify that paper is
		// empty.
		// Else, if lines left is less than low threshold of remaining paper, notify
		// that the paper is low.
		if (linesOfPaperRemaining <= 0) {
			notifyEmptyPaper();
		} else if (linesOfPaperRemaining <= lowPaperThreshold) {
			notifyLowPaper();
		}
	}

	private void notifyLowInk() {
		for (ReceiptPrinterTrackerObserver l : observers)
			l.lowInk(printer);
	}

	private void notifyLowPaper() {
		for (ReceiptPrinterTrackerObserver l : observers)
			l.lowPaper(printer);
	}

	private void notifyEmptyInk() {
		for (ReceiptPrinterTrackerObserver l : observers)
			l.emptyInk(printer);
	}

	private void notifyEmptyPaper() {
		for (ReceiptPrinterTrackerObserver l : observers)
			l.emptyPaper(printer);
	}
}

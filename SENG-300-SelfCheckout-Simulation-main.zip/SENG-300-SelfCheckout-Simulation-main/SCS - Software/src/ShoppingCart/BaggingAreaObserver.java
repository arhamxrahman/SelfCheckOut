package ShoppingCart;

import Station.ControllerObserver;

public interface BaggingAreaObserver extends ControllerObserver {
	public void baggingAreaWeightDiscrepancy(BaggingAreaController baggingAreaController);

	public void baggingAreaOverload(BaggingAreaController baggingAreaController);
}

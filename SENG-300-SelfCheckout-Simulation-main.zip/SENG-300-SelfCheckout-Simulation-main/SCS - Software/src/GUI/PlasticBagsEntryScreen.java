package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import Station.StationController;

public class PlasticBagsEntryScreen {
	StationController stationController;
	Session session;

	JFrame addingFrame;
	JFrame bagsFrame;
	JPanel bagsPanel;

	JButton button0;
	JButton button1;
	JButton button2;
	JButton button3;
	JButton button4;
	JButton button5;
	JButton button6;
	JButton button7;
	JButton button8;
	JButton button9;
	JButton button00;
	JButton clear;

	JLabel bagLabel;
	JTextField bagsInputField;
	JButton enter;
	JButton back;

	public PlasticBagsEntryScreen(JFrame addingFrame, StationController stationController, Session session) {
		this.addingFrame = addingFrame;
		this.stationController = stationController;
		this.session = session;

		bagsFrame = new JFrame("How many bags did you use today?");
		bagsPanel = new JPanel();
		bagsPanel.setLayout(new GridBagLayout());

		addWidgets();

		bagsFrame.getContentPane().add(bagsPanel, BorderLayout.CENTER);
		bagsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		bagsFrame.setSize(600, 400);
		bagsFrame.setVisible(true);
	}

	private void addWidgets() {
		bagLabel = new JLabel("Number of Bags*", SwingConstants.CENTER);

		bagsInputField = new JTextField(0);
		bagsInputField.setEditable(false);

		back = new JButton("Cancel");
		back.setBackground(Color.RED);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addingFrame.setVisible(true); // set to the adding page
				bagsFrame.dispose();
			}
		});

		enter = new JButton("Enter");
		enter.setBackground(Color.GREEN);
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String input = bagsInputField.getText();
				if (!input.isEmpty()) {
					stationController.getShoppingCart().addPlasticBags(Integer.valueOf(input));
				}

				CheckoutScreen next = new CheckoutScreen(addingFrame, stationController, session);
				next.checkoutFrame.setVisible(true);
				next.checkoutFrame.setLocationRelativeTo(bagsFrame);
				bagsFrame.dispose();
			}
		});

		button0 = new JButton("0");
		button0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "0");
			}
		});

		button00 = new JButton("00");
		button00.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "00");
			}
		});

		button1 = new JButton("1");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "1");
			}
		});

		button2 = new JButton("2");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "2");
			}
		});

		button3 = new JButton("3");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "3");
			}
		});

		button4 = new JButton("4");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "4");
			}
		});

		button5 = new JButton("5");
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "5");
			}
		});

		button6 = new JButton("6");
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "6");
			}
		});

		button7 = new JButton("7");
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "7");
			}
		});

		button8 = new JButton("8");
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "8");
			}
		});

		button9 = new JButton("9");
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText(bagsInputField.getText() + "9");
			}
		});

		clear = new JButton("Clear");
		clear.setBackground(Color.PINK);
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bagsInputField.setText("");
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 2;
		gbc.gridheight = 2;
		bagsPanel.add(bagLabel, gbc);

		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridheight = 1;
		bagsPanel.add(bagsInputField, gbc);

		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		bagsPanel.add(back, gbc);

		gbc.gridx = 1;
		gbc.gridy = 3;
		bagsPanel.add(enter, gbc);

		gbc.gridx = 2;
		gbc.gridy = 0;
		bagsPanel.add(button1, gbc);

		gbc.gridx = 3;
		gbc.gridy = 0;
		bagsPanel.add(button2, gbc);

		gbc.gridx = 4;
		gbc.gridy = 0;
		bagsPanel.add(button3, gbc);

		gbc.gridx = 2;
		gbc.gridy = 1;
		bagsPanel.add(button4, gbc);

		gbc.gridx = 3;
		gbc.gridy = 1;
		bagsPanel.add(button5, gbc);

		gbc.gridx = 4;
		gbc.gridy = 1;
		bagsPanel.add(button6, gbc);

		gbc.gridx = 2;
		gbc.gridy = 2;
		bagsPanel.add(button7, gbc);

		gbc.gridx = 3;
		gbc.gridy = 2;
		bagsPanel.add(button8, gbc);

		gbc.gridx = 4;
		gbc.gridy = 2;
		bagsPanel.add(button9, gbc);

		gbc.gridx = 2;
		gbc.gridy = 3;
		bagsPanel.add(button00, gbc);

		gbc.gridx = 3;
		gbc.gridy = 3;
		bagsPanel.add(button0, gbc);

		gbc.gridx = 4;
		gbc.gridy = 3;
		bagsPanel.add(clear, gbc);
	}
}
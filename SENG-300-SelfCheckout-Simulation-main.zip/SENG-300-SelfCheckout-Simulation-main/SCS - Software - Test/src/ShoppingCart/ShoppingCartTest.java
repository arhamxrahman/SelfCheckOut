package ShoppingCart;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;

public class ShoppingCartTest extends BaseTest {

	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testTotalCostCalculation() throws OverloadException {
		BigDecimal expectTotal = new BigDecimal(0.0);
		// Barcode Items
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		scs.baggingArea.add(item1);
		expectTotal = expectTotal.add(priceItem1);

		Item item2 = new BarcodedItem(barcodeItem2, weightItem2);
		while (cart.getScannedItemList().get(barcodeItem2) == null) {
			scs.handheldScanner.scan(item2);
		}
		scs.baggingArea.add(item2);
		expectTotal = expectTotal.add(priceItem2);

		Item item3 = new BarcodedItem(barcodeItem3, weightItem3);
		while (cart.getScannedItemList().get(barcodeItem3) == null) {
			scs.mainScanner.scan(item3);
		}
		scs.baggingArea.add(item3);
		expectTotal = expectTotal.add(priceItem3);

		Item item4 = new BarcodedItem(barcodeItem4, weightItem4);
		while (cart.getScannedItemList().get(barcodeItem4) == null) {
			scs.mainScanner.scan(item4);
		}
		scs.baggingArea.add(item4);
		expectTotal = expectTotal.add(priceItem4);

		// PLU Items
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);
		expectTotal = expectTotal.add(priceItem5.multiply(BigDecimal.valueOf(weightBunch5)));

		Item item6 = new PLUCodedItem(pluCodeItem6, weightBunch6);
		scs.scanningArea.add(item6);
		enterPLUCodeController.entered(pluCodeItem6);
		scs.scanningArea.remove(item6);
		scs.baggingArea.add(item6);
		expectTotal = expectTotal.add(priceItem6.multiply(BigDecimal.valueOf(weightBunch6)));

		Item item7 = new PLUCodedItem(pluCodeItem7, weightBunch7);
		scs.scanningArea.add(item7);
		enterPLUCodeController.entered(pluCodeItem7);
		scs.scanningArea.remove(item7);
		scs.baggingArea.add(item7);
		expectTotal = expectTotal.add(priceItem7.multiply(BigDecimal.valueOf(weightBunch7)));

		Item item8 = new PLUCodedItem(pluCodeItem8, weightBunch8);
		scs.scanningArea.add(item8);
		enterPLUCodeController.entered(pluCodeItem8);
		scs.scanningArea.remove(item8);
		scs.baggingArea.add(item8);
		expectTotal = expectTotal.add(priceItem8.multiply(BigDecimal.valueOf(weightBunch8)));

		// Buy 5 plastic bags
		cart.addPlasticBags(5);
		BigDecimal pricePerBag = new BigDecimal(0.1);
		expectTotal = expectTotal.add(pricePerBag.multiply(BigDecimal.valueOf(5)));

		BigDecimal actualTotal = cart.calculateTotalCosts();

		assertEquals(actualTotal.doubleValue(), expectTotal.doubleValue(), 0.01);
	}

	@Test
	public void testSelectedBypassBaggingArea() {
		cart.byPassBaggingArea();
		assertTrue(isSystemSuspended());
	}

	private boolean isSystemSuspended() {
		return scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled() && scs.scanningArea.isDisabled()
				&& scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && scs.printer.isDisabled();
	}
}

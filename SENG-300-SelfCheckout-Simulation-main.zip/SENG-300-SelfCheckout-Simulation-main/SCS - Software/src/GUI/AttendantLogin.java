package GUI;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AttendantLogin {
	App app;

	JFrame attendentLoginFrame;
	JPanel loginPanel;

	JTextField userNameTextField = new JTextField(20);
	JPasswordField passwordTextField = new JPasswordField(20);

	JButton login;

	public AttendantLogin(App app) {
		this.app = app;

		attendentLoginFrame = new JFrame("Attendent Login");
		loginPanel = new JPanel();
		loginPanel.setLayout(new GridBagLayout());

		addWidgets();

		attendentLoginFrame.getContentPane().add(loginPanel, BorderLayout.CENTER);
		attendentLoginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		attendentLoginFrame.setLocationRelativeTo(null);
		attendentLoginFrame.setSize(600, 400);
		attendentLoginFrame.setVisible(true);
	}

	private void addWidgets() {
		login = new JButton("Login");
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// add check if loggein in is true implement later
				String username = userNameTextField.getText();
				String password = new String(passwordTextField.getPassword());

				if (app.getAttendantIntervention().login(username, password)) {
					AttendantMainScreen next = new AttendantMainScreen(attendentLoginFrame, app);
					next.attendantMainFrame.setVisible(true);
					attendentLoginFrame.setVisible(false);
					passwordTextField.setText("");
					userNameTextField.setText("");
				} else {
					passwordTextField.setText("");
					attendentLoginFrame.setTitle("INVALID PASSWORD OR USERNAME");
				}
			}
		});

		userNameTextField.setMargin(new Insets(0, 10, 0, 0));
		passwordTextField.setMargin(new Insets(0, 10, 0, 0));

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		JLabel username = new JLabel("Username");
		loginPanel.add(username, gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		loginPanel.add(userNameTextField, gbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		JLabel password = new JLabel("Password");
		loginPanel.add(password, gbc);
		gbc.gridx = 0;
		gbc.gridy = 3;
		loginPanel.add(passwordTextField, gbc);
		gbc.gridx = 0;
		gbc.gridy = 4;

		loginPanel.add(login, gbc);
	}
}

package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Currency;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.SimulationException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.external.ProductDatabases;

import Checkout.Checkout;
import Checkout.CheckoutObserver;
import ShoppingCart.ShoppingCart;
import ShoppingCart.ShoppingCartObserver;
import Station.StationController;
import Station.StationObserver;
import Station.StationState;

public class AttendantStationScreen implements StationObserver, ShoppingCartObserver, CheckoutObserver {
	App app;
	JFrame attendantMainFrame;
	int stationIndex;

	JFrame stationFrame;
	JPanel stationPanel;

	WelcomeScreen station;

	JLabel stationStateLabel;

	JButton backButton = new JButton("Back");
	JButton startupButton = new JButton("Start Up Station");
	JButton shutdownButton = new JButton("Shut Down Station");
	JButton approveButton = new JButton("<html><center>Approve Weight<br/> Discrepancy</center></html>");
	JButton blockButton = new JButton("Block Station");
	JButton lookupButton = new JButton("Look Up");
	JButton refillCoinButton = new JButton("Refill Coins");
	JButton refillBanknoteButton = new JButton("Refill Banknotes");
	JButton addPaperButton = new JButton("Add Papers");
	JButton emptyCoinButton = new JButton("Empty Coins");
	JButton emptyBanknoteButton = new JButton("Empty Banknotes");
	JButton addInkButton = new JButton("Add Ink");

	JPanel productList = new JPanel();

	Map<BigDecimal, ArrayList<Coin>> coinsToRefill = new HashMap<>();
	Map<Integer, ArrayList<Banknote>> banknoteToRefill = new HashMap<>();
	Set<BigDecimal> coinDenominations = new HashSet<>();
	Set<Integer> banknoteDenominations = new HashSet<>();

	public AttendantStationScreen(JFrame attendantMainFrame, App app, int stationIndex) {
		this.attendantMainFrame = attendantMainFrame;
		this.app = app;
		this.stationIndex = stationIndex;

		app.getStationController(stationIndex).attach(this);
		app.getStationController(stationIndex).getShoppingCart().attach(this);
		app.getStationController(stationIndex).getCheckout().attach(this);

		stationFrame = new JFrame("Station " + stationIndex + " Attendant Control");
		stationPanel = new JPanel();
		stationPanel.setLayout(new GridBagLayout());

		addWidgets();
		setupRefillStandard();

		stationFrame.getContentPane().add(stationPanel, BorderLayout.CENTER);
		stationFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		stationFrame.setSize(600, 800);
		stationFrame.setVisible(true);
	}

	private void addWidgets() {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.weightx = 1;
		gbc.weighty = 1;

		setupButtons(gbc);
		updateStatus();

		productList.setLayout(new GridBagLayout());

		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.gridwidth = 3;
		stationPanel.add(productList, gbc);
	}

	private void startupStation() {
		startupButton.setEnabled(false);
		shutdownButton.setEnabled(true);
		approveButton.setEnabled(true);
		blockButton.setEnabled(true);
		lookupButton.setEnabled(true);
		refillCoinButton.setEnabled(true);
		refillBanknoteButton.setEnabled(true);
		emptyCoinButton.setEnabled(true);
		emptyBanknoteButton.setEnabled(true);
		addPaperButton.setEnabled(true);
		addInkButton.setEnabled(true);
	}

	private void shutdownStation() {
		startupButton.setEnabled(true);
		shutdownButton.setEnabled(false);
		approveButton.setEnabled(false);
		blockButton.setEnabled(false);
		lookupButton.setEnabled(true);
		refillCoinButton.setEnabled(true);
		refillBanknoteButton.setEnabled(true);
		emptyCoinButton.setEnabled(true);
		emptyBanknoteButton.setEnabled(true);
		addPaperButton.setEnabled(true);
		addInkButton.setEnabled(true);
	}

	private void updateStatus() {
		StationState state = app.getStationController(stationIndex).getState();
		stationStateLabel.setText(state.toString());
		switch (state) {
		case ADDING:
			stationStateLabel.setBackground(Color.GREEN);
			break;
		case BAGGING:
			stationStateLabel.setBackground(Color.GREEN);
			break;
		case PAYING:
			stationStateLabel.setBackground(Color.YELLOW);
			break;
		case PAID:
			stationStateLabel.setBackground(Color.CYAN);
			break;
		case SUSPEND:
			stationStateLabel.setBackground(Color.RED);
			break;
		default:
			break;
		}

		productList.removeAll();
		productList.revalidate();
		productList.repaint();

		GridBagConstraints igbc = new GridBagConstraints();
		igbc.fill = GridBagConstraints.BOTH;
		igbc.weightx = 1;
		igbc.weighty = 1;

		Map<Barcode, Integer> scannedBarcodeItemList = app.getStationController(stationIndex).getShoppingCart()
				.getScannedItemList();
		Map<PriceLookupCode, Double> enteredPLUItemList = app.getStationController(stationIndex).getShoppingCart()
				.getEnteredItemList();

		int i = 0;
		for (Barcode barcode : scannedBarcodeItemList.keySet()) {
			JButton removeButton = new JButton("X");
			removeButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					app.getAttendantIntervention().removeProduct(stationIndex, new BarcodedItem(barcode, 1));
				}
			});

			JLabel productLabel = new JLabel(ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getDescription(),
					SwingConstants.CENTER);

			igbc.gridx = 0;
			igbc.gridy = i;
			igbc.gridwidth = 1;
			productList.add(removeButton, igbc);
			igbc.gridx = 1;
			igbc.gridy = i;
			igbc.gridwidth = 2;
			productList.add(productLabel, igbc);
			i++;
		}

		for (PriceLookupCode plu : enteredPLUItemList.keySet()) {
			JButton removeButton = new JButton("X");
			removeButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					app.getAttendantIntervention().removeProduct(stationIndex, new PLUCodedItem(plu, 1));
				}
			});

			JLabel productLabel = new JLabel(ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getDescription(),
					SwingConstants.CENTER);

			igbc.gridx = 0;
			igbc.gridy = i;
			igbc.gridwidth = 1;
			productList.add(removeButton, igbc);
			igbc.gridx = 1;
			igbc.gridy = i;
			igbc.gridwidth = 2;
			productList.add(productLabel, igbc);
			i++;
		}
	}

	private void setupButtons(GridBagConstraints gbc) {
		backButton.setBackground(Color.RED);
		backButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				attendantMainFrame.setVisible(true);
				stationFrame.dispose();
			}
		});

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 1;
		stationPanel.add(backButton, gbc);

		stationStateLabel = new JLabel(app.getStationController(stationIndex).getState().toString(),
				SwingConstants.CENTER);
		stationStateLabel.setOpaque(true);
		stationStateLabel.setBackground(Color.GREEN);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		stationPanel.add(stationStateLabel, gbc);

		startupButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (app.getAttendantIntervention().startUpStation(stationIndex)) {
					station = new WelcomeScreen(app, stationIndex);
					station.welcomeFrame.setVisible(true);
					startupStation();
				}
			}
		});

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		stationPanel.add(startupButton, gbc);

		shutdownButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (app.getAttendantIntervention().shutDownStation(stationIndex)) {
					shutdownStation();
					station.welcomeFrame.dispose();
				}
			}
		});

		gbc.gridx = 2;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		stationPanel.add(shutdownButton, gbc);

		approveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				app.getAttendantIntervention().approvedWeightDiscrepancy(stationIndex);
			}
		});

		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		stationPanel.add(approveButton, gbc);

		blockButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				app.getAttendantIntervention().blocksStation(stationIndex);
			}
		});

		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		stationPanel.add(blockButton, gbc);

		lookupButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AttendantLookupScreen next = new AttendantLookupScreen(stationFrame);
				next.lookupFrame.setVisible(true);
			}
		});

		gbc.gridx = 2;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		stationPanel.add(lookupButton, gbc);

		refillCoinButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					app.getAttendantIntervention().refillCoinDispenser(stationIndex, coinsToRefill);
				} catch (SimulationException | OverloadException e1) {

				}
			}
		});

		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		stationPanel.add(refillCoinButton, gbc);

		refillBanknoteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					app.getAttendantIntervention().refillBanknoteDispenser(stationIndex, banknoteToRefill);
				} catch (SimulationException | OverloadException e1) {

				}
			}
		});

		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		stationPanel.add(refillBanknoteButton, gbc);

		addPaperButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					app.getAttendantIntervention().addsPaper(0, 100);
				} catch (OverloadException e1) {

				}
			}
		});

		gbc.gridx = 2;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		stationPanel.add(addPaperButton, gbc);

		emptyCoinButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					app.getAttendantIntervention().emptyCoinDispenser(stationIndex, coinDenominations);
				} catch (SimulationException | OverloadException e1) {

				}
			}
		});

		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		stationPanel.add(emptyCoinButton, gbc);

		emptyBanknoteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					app.getAttendantIntervention().emptyBanknoteDispenser(stationIndex, banknoteDenominations);
				} catch (SimulationException | OverloadException e1) {

				}
			}
		});

		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		stationPanel.add(emptyBanknoteButton, gbc);

		addInkButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					app.getAttendantIntervention().addsPaper(0, 100);
				} catch (OverloadException e1) {

				}
			}
		});

		gbc.gridx = 2;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		stationPanel.add(addInkButton, gbc);

		shutdownStation();
	}

	@Override
	public void callAttendant(StationController stationController) {
		updateStatus();
	}

	@Override
	public void itemAdded(ShoppingCart shoppingCart) {
		updateStatus();
	}

	@Override
	public void baggingAreaWeightDiscrepancy(ShoppingCart shoppingCart) {
		updateStatus();
		approveButton.setEnabled(true);
	}

	@Override
	public void baggingAreaOverload(ShoppingCart shoppingCart) {
		// remove buttons
		updateStatus();
	}

	@Override
	public void emptyDispensers(Checkout checkout) {
		updateStatus();
		refillCoinButton.setEnabled(true);
		refillBanknoteButton.setEnabled(true);
	}

	@Override
	public void transactionFailed(Checkout checkout) {
		updateStatus();
	}

	@Override
	public void paidInFull(Checkout checkout) {
		updateStatus();
	}

	private void setupRefillStandard() {

		List<BigDecimal> coinDenominations = app.getStationController(stationIndex).getStation().coinDenominations;
		int[] banknoteDenominations = app.getStationController(stationIndex).getStation().banknoteDenominations;

		Currency currency = Currency.getInstance("CAD");

		Coin nickel = new Coin(currency, new BigDecimal(0.05));
		Coin dime = new Coin(currency, new BigDecimal(0.10));
		Coin quarter = new Coin(currency, new BigDecimal(0.25));
		Coin loonie = new Coin(currency, new BigDecimal(1.00));
		Coin toonie = new Coin(currency, new BigDecimal(2.00));

		ArrayList<Coin> nickels = new ArrayList<>(Arrays.asList(nickel, nickel, nickel, nickel, nickel));
		ArrayList<Coin> dimes = new ArrayList<>(Arrays.asList(dime, dime, dime, dime, dime));
		ArrayList<Coin> quarters = new ArrayList<>(Arrays.asList(quarter, quarter, quarter, quarter, quarter));
		ArrayList<Coin> loonies = new ArrayList<>(Arrays.asList(loonie, loonie, loonie, loonie, loonie));
		ArrayList<Coin> toonies = new ArrayList<>(Arrays.asList(toonie, toonie, toonie, toonie, toonie));

		Banknote fiveDollars = new Banknote(currency, 5);
		Banknote tenDollars = new Banknote(currency, 10);
		Banknote twentyDollars = new Banknote(currency, 20);
		Banknote fiftyDollars = new Banknote(currency, 50);
		Banknote hundredDollars = new Banknote(currency, 10);

		ArrayList<Banknote> fives = new ArrayList<>(
				Arrays.asList(fiveDollars, fiveDollars, fiveDollars, fiveDollars, fiveDollars));
		ArrayList<Banknote> tens = new ArrayList<>(
				Arrays.asList(tenDollars, tenDollars, tenDollars, tenDollars, tenDollars));
		ArrayList<Banknote> twenties = new ArrayList<>(
				Arrays.asList(twentyDollars, twentyDollars, twentyDollars, twentyDollars, twentyDollars));
		ArrayList<Banknote> fifties = new ArrayList<>(Arrays.asList(fiftyDollars, fiftyDollars, fiftyDollars));
		ArrayList<Banknote> hundreds = new ArrayList<>(Arrays.asList(hundredDollars, hundredDollars));

		for (BigDecimal denomination : coinDenominations) {
			this.coinDenominations.add(denomination);
			if (denomination.compareTo(new BigDecimal(0.05)) == 0) {
				coinsToRefill.put(denomination, nickels);
			} else if (denomination.compareTo(new BigDecimal(0.10)) == 0) {
				coinsToRefill.put(denomination, dimes);
			} else if (denomination.compareTo(new BigDecimal(0.25)) == 0) {
				coinsToRefill.put(denomination, quarters);
			} else if (denomination.compareTo(new BigDecimal(1.00)) == 0) {
				coinsToRefill.put(denomination, loonies);
			} else if (denomination.compareTo(new BigDecimal(2.00)) == 0) {
				coinsToRefill.put(denomination, toonies);
			}
		}

		for (int denomination : banknoteDenominations) {
			this.banknoteDenominations.add(denomination);
			if (denomination == 5) {
				banknoteToRefill.put(denomination, fives);
			} else if (denomination == 10) {
				banknoteToRefill.put(denomination, tens);
			} else if (denomination == 20) {
				banknoteToRefill.put(denomination, twenties);
			} else if (denomination == 50) {
				banknoteToRefill.put(denomination, fifties);
			} else if (denomination == 100) {
				banknoteToRefill.put(denomination, hundreds);
			}
		}
	}
}

package GUI;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class WelcomeScreen {
	App app;

	JFrame welcomeFrame;
	JPanel welcomePanel;
	JLabel welcomeText;
	JButton startButton;

	int stationIndex;

	public WelcomeScreen(App app, int stationIndex) {
		this.app = app;
		this.stationIndex = stationIndex;
		welcomeFrame = new JFrame("Welcome!");
		welcomeFrame.setSize(800, 650);
		welcomePanel = new JPanel();
		welcomePanel.setLayout(new GridLayout(2, 1));

		addWidgets();

		welcomeFrame.getContentPane().add(welcomePanel, BorderLayout.CENTER);
		welcomeFrame.setLocationRelativeTo(null);
		welcomeFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		welcomeFrame.setVisible(true);
	}

	private void addWidgets() {
		welcomeText = new JLabel("Welcome!", SwingConstants.CENTER);
		startButton = new JButton("Start");

		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddingItemScreen next = new AddingItemScreen(app, stationIndex, welcomeFrame);
				next.addingItemsFrame.setVisible(true);
				next.addingItemsFrame.setLocationRelativeTo(welcomeFrame);
				welcomeFrame.dispose();
			}
		});

		welcomePanel.add(welcomeText);
		welcomePanel.add(startButton);
	}
}

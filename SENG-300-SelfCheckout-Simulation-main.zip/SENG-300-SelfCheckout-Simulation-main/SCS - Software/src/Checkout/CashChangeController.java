package Checkout;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.EmptyException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

public class CashChangeController {
	BigDecimal amount;
	BigDecimal amountRounded;
	SelfCheckoutStation station;
	int minBanknoteDenom;
	BigDecimal minBanknoteDenomBD;
	BigDecimal minCoinDenom;

	/*
	 * If the amount passed in is greater than or equal to the smallest denomination
	 * of banknotes, we dispense banknotes. If the amount is less than the smallest
	 * denomination of banknotes, we dispense coins. In either case we look at the
	 * greatest of the denominations which are less than or equal to the amount and
	 * dispense that. Then we repeat for the remaining amount and so on until the
	 * amount is paid off.
	 */

	public CashChangeController(BigDecimal amount, SelfCheckoutStation station) {
		this.amount = amount;
		this.station = station;

		Arrays.sort(station.banknoteDenominations);
		minBanknoteDenom = station.banknoteDenominations[0];
		minBanknoteDenomBD = new BigDecimal(minBanknoteDenom);

		Collections.sort(station.coinDenominations, Collections.reverseOrder());
		minCoinDenom = station.coinDenominations.get(0);

	}

	public void giveChange() throws EmptyException, DisabledException, OverloadException {
		while (amount.compareTo(minBanknoteDenomBD) >= 0) {
			for (int denom : station.banknoteDenominations) {
				if (new BigDecimal(denom).compareTo(amount) <= 0) {
					try {
						// System.out.println("before" + amount);
						station.banknoteDispensers.get(denom).emit(); // Might need to check if the slot is occupied
						station.banknoteOutput.removeDanglingBanknotes();
						// System.out.println("banknote emmited val:" + denom);
					} catch (Exception e) {
						// System.out.println("sink full");
						// do something to empty sink
					}
					amount = amount.subtract(new BigDecimal(denom));
					// System.out.println("after " + amount);
					// dispense the banknote
					// This will encounter the first banknote that is less than or equal to the
					// amount, then exit the for loop after dispensing it.
					break;
				}
			}
		}

		while (amount.floatValue() > 0.0) {
			for (int i = 0; i < station.coinDenominations.size(); i++) {
				if (station.coinDenominations.get(i).compareTo(amount) <= 0
						|| i == station.coinDenominations.size() - 1) {
					station.coinDispensers.get(station.coinDenominations.get(i)).emit();
					amount = amount.subtract(station.coinDenominations.get(i));
					// dispense the coin
					// This will encounter the first coin that is less than or equal to the amount,
					// then exit the for loop after dispensing it.
					break;
				}
			}
		}
	}
}

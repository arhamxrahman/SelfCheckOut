package Supervision;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.lsmr.selfcheckout.InvalidArgumentSimulationException;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.products.PLUCodedProduct;

public class AttendantLooksUpProduct {
	private SelfCheckoutStation scs;
	private final static Set<AttendantLooksUpProductObserver> observers = new HashSet<>();
	private Map<PriceLookupCode, Double> enteredItemList = new HashMap<>(); // for PLU products
	private double lastEnteredPLUProductWeight;
	String descriptionEnteredAttendant = "";
	private PriceLookupCode codeFound;

	public AttendantLooksUpProduct(SelfCheckoutStation scs) {
		this.scs = scs;
	}

	public void attach(AttendantLooksUpProductObserver observer) {
		observers.add(observer);
	}

	public static void deattach(AttendantLooksUpProductObserver observer) {
		observers.remove(observer);
	}

	public String getDescriptionEnteredAttendant() {
		return descriptionEnteredAttendant;
	}

	public void setDescriptionEnteredAttendant(String descriptionEnteredAttendant) {
		this.descriptionEnteredAttendant = descriptionEnteredAttendant;
	}

	public PriceLookupCode checkEnteredDescription(PLUCodedProduct plucp, String descriptionEnteredAttendant2,
			SelfCheckoutStation scs2) throws OverloadException {

		if (plucp.getDescription().contains(descriptionEnteredAttendant2)) {
			codeFound = plucp.getPLUCode();
			lastEnteredPLUProductWeight = scs2.scanningArea.getCurrentWeight();
		} else {
			throw new InvalidArgumentSimulationException("could not find plu item with that description");
		}
		notifyProductEntered();
		return codeFound;

	}

	public double getLastEnteredPLUProductWeight() {
		return lastEnteredPLUProductWeight;
	}

	public Map<PriceLookupCode, Double> getEnteredItemList() {
		return enteredItemList;
	}

	private void notifyProductEntered() {
		for (AttendantLooksUpProductObserver l : observers)
			l.pluProductEntered(this);
	}
}
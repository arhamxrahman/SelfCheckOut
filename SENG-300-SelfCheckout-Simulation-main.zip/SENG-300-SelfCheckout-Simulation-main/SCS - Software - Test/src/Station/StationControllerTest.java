package Station;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;

public class StationControllerTest extends BaseTest {

	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testAttendantCall() {
		attendantIntervention.getStationControllers().get(currentStationIndex).callAttendant();
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.SUSPEND);
	}

	@Test
	public void testRestartSession() {
		attendantIntervention.getStationControllers().get(currentStationIndex).restartSession();
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.ADDING);
	}

	@Test
	public void testSetState() {
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.ADDING);
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.ADDING);

		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.BAGGING);
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.BAGGING);

		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.PAYING);
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.PAYING);

		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.PAID);
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.PAID);

		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.SUSPEND);
	}

	@Test
	public void testAttachedStationControllerObserver() {
		class SO implements StationObserver {
			@Override
			public void callAttendant(StationController stationController) {

			}
		}
		SO observer = new SO();
		attendantIntervention.getStationControllers().get(currentStationIndex).attach(observer);
		attendantIntervention.getStationControllers().get(currentStationIndex).deattach(observer);
	}
}

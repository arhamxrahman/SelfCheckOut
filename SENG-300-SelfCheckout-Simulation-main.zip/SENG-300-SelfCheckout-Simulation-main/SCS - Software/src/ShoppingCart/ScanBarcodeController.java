package ShoppingCart;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.InvalidArgumentSimulationException;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.BarcodeScanner;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.BarcodeScannerObserver;
import org.lsmr.selfcheckout.external.ProductDatabases;
import org.lsmr.selfcheckout.products.BarcodedProduct;

import Station.StationController;

public class ScanBarcodeController {
	private final Set<ScanBarcodeObserver> controllerObservers = new HashSet<>();
	private Map<Barcode, Integer> scannedItemList = new HashMap<>(); // for Barcode products
	private BarcodedProduct lastScannedBarcodedProduct;

	public class BSO implements BarcodeScannerObserver {

		@Override
		public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// ignore
		}

		@Override
		public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// ignore
		}

		@Override
		public void barcodeScanned(BarcodeScanner barcodeScanner, Barcode barcode) {
			if (ProductDatabases.BARCODED_PRODUCT_DATABASE.containsKey(barcode)) {
				lastScannedBarcodedProduct = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode);
				if (scannedItemList.containsKey(barcode)) {
					scannedItemList.replace(barcode, scannedItemList.get(barcode) + 1);
				} else {
					scannedItemList.put(barcode, 1);
				}
				notifyProductScanned();
			} else {
				throw new InvalidArgumentSimulationException("Invalid barcode");
			}
		}
	}

	public ScanBarcodeController(StationController stationController) {

	}

	public void attach(ScanBarcodeObserver observer) {
		controllerObservers.add(observer);
	}

	public void deattach(ScanBarcodeObserver observer) {
		controllerObservers.remove(observer);
	}

	public double getLastScannedBarcodedProductWeight() {
		return lastScannedBarcodedProduct.getExpectedWeight();
	}

	public Map<Barcode, Integer> getScannedItemList() {
		return scannedItemList;
	}

	public void resetScannedItemList() {
		scannedItemList = new HashMap<>();
	}

	private void notifyProductScanned() {
		for (ScanBarcodeObserver l : controllerObservers)
			l.barcodeProductScanned(this);
	}
}

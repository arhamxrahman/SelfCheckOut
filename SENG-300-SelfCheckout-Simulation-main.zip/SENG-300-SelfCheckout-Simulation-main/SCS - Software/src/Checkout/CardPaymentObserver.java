package Checkout;

import java.math.BigDecimal;

import Station.ControllerObserver;

public interface CardPaymentObserver extends ControllerObserver {
	public void successfulCardTransaction(CardPaymentController cardPaymentController, BigDecimal amountPaid);

	public void failedCardTransaction(CardPaymentController cardPaymentController);
}

package GUI;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.external.ProductDatabases;

import Station.StationController;

public class ThankYouScreen {
	Session session;

	JFrame thanksFrame;
	JPanel thanksPanel;
	JScrollPane scrollPane;
	JLabel thanksLabel;
	JTextArea receiptTextArea;
	JButton nextButton;

	public ThankYouScreen(Session session) {
		this.session = session;

		thanksFrame = new JFrame("Thank You!");
		thanksFrame.setSize(600, 400);
		thanksPanel = new JPanel();
		thanksPanel.setLayout(new GridLayout(3, 1));

		thanksLabel = new JLabel("Thank You For Shopping at Your Generic Company!", SwingConstants.CENTER);

		receiptTextArea = new JTextArea();
		receiptTextArea.setEditable(false);
		printReceipt();
		scrollPane = new JScrollPane(receiptTextArea);

		nextButton = new JButton("Continue");
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomeScreen next = new WelcomeScreen(session.getApp(), session.getStationIndex());

				next.welcomeFrame.setVisible(true);
				next.welcomeFrame.setLocationRelativeTo(thanksFrame);
				thanksFrame.dispose();
			}
		});

		thanksPanel.add(thanksLabel);
		thanksPanel.add(scrollPane);
		thanksPanel.add(nextButton);

		thanksFrame.getContentPane().add(thanksPanel, BorderLayout.CENTER);
		thanksFrame.setLocationRelativeTo(null);
		thanksFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		thanksFrame.setVisible(true);
	}

	private void printReceipt() {
		StationController stationController = session.getStationController();
		StringBuilder str = new StringBuilder();

		Map<Barcode, Integer> scannedItemList = stationController.getShoppingCart().getScannedItemList();
		Map<PriceLookupCode, Double> enteredItemList = stationController.getShoppingCart().getEnteredItemList();

		if (session.getMembership() != null) {
			str.append("Welcome #");
			str.append(session.getMembership());
			str.append('\n');
		}

		for (Barcode barcode : scannedItemList.keySet()) {
			String description = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getDescription();
			int quantity = scannedItemList.get(barcode);
			BigDecimal price = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getPrice().setScale(2,
					RoundingMode.HALF_DOWN);
			str.append(barcode);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(quantity);
			str.append(" @ $");
			str.append(price);
			str.append("				");
			str.append(price.multiply(new BigDecimal(quantity)));
			str.append('\n');
		}

		for (PriceLookupCode plu : enteredItemList.keySet()) {
			String description = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getDescription();
			BigDecimal weight = new BigDecimal(enteredItemList.get(plu) / 1000).setScale(3, RoundingMode.HALF_DOWN);
			BigDecimal price = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice().multiply(new BigDecimal(1000))
					.setScale(2, RoundingMode.HALF_DOWN);
			BigDecimal cost = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice()
					.multiply(new BigDecimal(enteredItemList.get(plu))).setScale(2, RoundingMode.HALF_DOWN);
			str.append(plu);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(weight);
			str.append(" kg @ $");
			str.append(price);
			str.append("/kg			");
			str.append(cost);
			str.append('\n');
		}

		int numOfBags = stationController.getShoppingCart().getNumOfBags();
		BigDecimal pricePerBag = stationController.getShoppingCart().getPricePerBag();
		if (numOfBags > 0) {
			BigDecimal cost = pricePerBag.multiply(new BigDecimal(numOfBags)).setScale(2, RoundingMode.HALF_DOWN);
			str.append("Plastic Bag");
			str.append('\n');
			str.append(numOfBags);
			str.append(" @ $");
			str.append(pricePerBag.setScale(2, RoundingMode.HALF_DOWN));
			str.append("				");
			str.append(cost);
			str.append('\n');
		}

		BigDecimal totalCosts = stationController.getShoppingCart().calculateTotalCosts();
		BigDecimal totalPayments = stationController.getCheckout().getTotalPayments().setScale(2,
				RoundingMode.HALF_DOWN);
		BigDecimal change = totalPayments.subtract(totalCosts).setScale(2, RoundingMode.HALF_DOWN);

		str.append("Total				");
		str.append(totalCosts);
		str.append('\n');
		str.append("Received				");
		str.append(totalPayments);
		str.append('\n');
		if (change.compareTo(new BigDecimal(0.00)) > 0) {
			str.append("Change				");
			str.append(change);
			str.append('\n');
		}

		str.append("Thank you for shopping with us!");

		receiptTextArea.setText(str.toString());
	}
}

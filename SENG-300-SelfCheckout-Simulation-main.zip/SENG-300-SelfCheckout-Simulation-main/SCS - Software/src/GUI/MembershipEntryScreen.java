package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class MembershipEntryScreen {
	Session session;

	JFrame addingFrame;
	JFrame membershipFrame;
	JPanel membershipPanel;

	JLabel membershipLabel;
	JTextField numberInputField;
	JButton enter;
	JButton back;

	public MembershipEntryScreen(JFrame addingFrame, Session session) {
		this.addingFrame = addingFrame;
		this.session = session;
		membershipFrame = new JFrame("Membership");
		membershipPanel = new JPanel();
		membershipPanel.setLayout(new GridBagLayout());

		addWidgets();

		membershipFrame.getContentPane().add(membershipPanel, BorderLayout.CENTER);
		membershipFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		membershipFrame.setSize(500, 300);
		membershipFrame.setVisible(true);
	}

	private void addWidgets() {
		membershipLabel = new JLabel("Enter your membership number", SwingConstants.CENTER);

		numberInputField = new JTextField();
		numberInputField.setEditable(true);

		enter = new JButton("Enter");
		back = new JButton("Cancel");

		enter.setBackground(Color.GREEN);
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numberInput = numberInputField.getText();
				session.setMembership(numberInput);
				session.getStationController().getCheckout().getMembershipController().manualEntry(numberInput);
				addingFrame.setVisible(true); // set to the adding page
				membershipFrame.dispose();
			}
		});

		back.setBackground(Color.RED);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				session.setMembership("");
				addingFrame.setVisible(true); // set to the adding page
				membershipFrame.dispose();
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 2;
		membershipPanel.add(membershipLabel, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		membershipPanel.add(numberInputField, gbc);

		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		membershipPanel.add(back, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		membershipPanel.add(enter, gbc);
	}
}
package Checkout;

import org.lsmr.selfcheckout.Card.CardData;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.CardReader;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.CardReaderObserver;

import Station.StationController;
import Station.StationState;

public class MembershipController {
	private StationController stationController;
	private String membershipNumber = null;

	public MembershipController(StationController stationController) {
		this.stationController = stationController;
	}

	// GUI button to choice entering membership number
	public void enterMembership() {
		enableMembershipEntry();
	}

	// GUI button for confirming manual entry
	public void manualEntry(String membershipNumber) {
		this.membershipNumber = membershipNumber;
		stationController.setState(StationState.ADDING);
	}

	public void resetMembership() {
		membershipNumber = null;
	}

	public class CRO implements CardReaderObserver {

		@Override
		public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void cardInserted(CardReader reader) {
			// Ignore
		}

		@Override
		public void cardRemoved(CardReader reader) {
			// Ignore
		}

		@Override
		public void cardTapped(CardReader reader) {
			// Ignore
		}

		@Override
		public void cardSwiped(CardReader reader) {

		}

		@Override
		public void cardDataRead(CardReader reader, CardData data) {
			membershipNumber = data.getNumber();
			stationController.setState(StationState.ADDING);
		}
	}

	public String getMembershipNumber() {
		return membershipNumber;
	}

	private void enableMembershipEntry() {
		stationController.getStation().cardReader.enable();
		stationController.getStation().mainScanner.disable();
		stationController.getStation().handheldScanner.disable();
		stationController.getStation().scanningArea.disable();
		stationController.getStation().baggingArea.disable();
		stationController.getStation().coinSlot.disable();
		stationController.getStation().banknoteInput.disable();
		stationController.getStation().printer.disable();
	}
}
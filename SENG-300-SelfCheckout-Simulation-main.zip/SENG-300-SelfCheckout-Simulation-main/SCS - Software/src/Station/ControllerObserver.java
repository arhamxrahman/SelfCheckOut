package Station;

/**
 * This class represents the abstract interface for all controller observers.
 * All subclasses should add their own event notification methods, the first
 * parameter of which should always be the controller affected.
 */
public interface ControllerObserver {
}

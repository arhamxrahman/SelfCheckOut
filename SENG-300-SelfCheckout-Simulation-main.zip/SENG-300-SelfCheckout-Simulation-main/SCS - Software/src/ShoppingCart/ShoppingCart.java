package ShoppingCart;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.external.ProductDatabases;

import Station.ControllerObserver;
import Station.StationController;
import Station.StationState;

public class ShoppingCart {
	private SelfCheckoutStation scs;
	private StationController stationController;
	private BaggingAreaController baggingAreaController;
	private ScanBarcodeController scanBarcodeController;
	private EnterPLUCodeController enterPLUCodeController;
	private Map<Barcode, Integer> scannedBarcodeItemList = new HashMap<>(); // for Barcode products
	private Map<PriceLookupCode, Double> enteredPLUItemList = new HashMap<>(); // for PLU code products
	private int numOfBags;
	private BigDecimal pricePerBag = new BigDecimal(0.1);
	private double maxPlasticBagWeight = 10.0; // in grams
	private Set<ControllerObserver> controllerObservers = new HashSet<>();
	private Set<ShoppingCartObserver> shoppingCartObservers = new HashSet<>();

	private class SBO implements ScanBarcodeObserver {
		@Override
		public void barcodeProductScanned(ScanBarcodeController scanBarcodeController) {
			stationController.setState(StationState.BAGGING);
			baggingAreaController.setStatus(BAProcessing.BARCODE);
			scannedBarcodeItemList = scanBarcodeController.getScannedItemList();
			notifyItemAdded();
		}
	}

	private class EPO implements EnterPLUCodeObserver {
		@Override
		public void pluProductEntered(EnterPLUCodeController enterPLUCodeController) {
			stationController.setState(StationState.BAGGING);
			baggingAreaController.setStatus(BAProcessing.PLU);
			enteredPLUItemList = enterPLUCodeController.getEnteredItemList();
			notifyItemAdded();
		}
	}

	private class BAO implements BaggingAreaObserver {
		@Override
		public void baggingAreaWeightDiscrepancy(BaggingAreaController baggingAreaController) {
			notifyWeightDiscrepancy();
		}

		@Override
		public void baggingAreaOverload(BaggingAreaController baggingAreaController) {
			notifyOverload();
		}
	}

	public ShoppingCart(StationController stationController, ScanBarcodeController scanBarcodeController,
			EnterPLUCodeController enterPLUCodeController, BaggingAreaController baggingAreaController) {
		this.scs = stationController.getStation();
		this.stationController = stationController;
		this.scanBarcodeController = scanBarcodeController;
		this.enterPLUCodeController = enterPLUCodeController;
		SBO sbo = new SBO();
		this.scanBarcodeController.attach(sbo);
		controllerObservers.add(sbo);
		EPO epo = new EPO();
		this.enterPLUCodeController.attach(epo);
		controllerObservers.add(epo);
		BAO bao = new BAO();
		baggingAreaController.attach(bao);
		controllerObservers.add(bao);
		this.baggingAreaController = baggingAreaController;
	}

	// GUI button for customer purchasing plastic bags
	public void addPlasticBags(int numOfBags) {
		this.numOfBags = numOfBags;
		baggingAreaController.setStatus(BAProcessing.PLASTICBAGS);
		baggingAreaController.setCurrentExpectedWeight(numOfBags * maxPlasticBagWeight);
	}

	// GUI button for customer placing their own bags in bagging area
	public void useReusableBags() {
		baggingAreaController.setStatus(BAProcessing.REUSABLEBAGS);
	}

	// GUI button for bypass placing item in bagging area
	public void byPassBaggingArea() {
		stationController.setState(StationState.SUSPEND);
		notifyWeightDiscrepancy();
		// stop timer if already started -> bagging area will not wait for scanned item
		// wait for attendant approval to continue shopping (add items)
	}

	// GUI button for attendant removing product
	public void removeProduct(Item item) {
		stationController.setState(StationState.BAGGING);
		if (item instanceof BarcodedItem) {
			baggingAreaController.setStatus(BAProcessing.BARCODE);
			Barcode barcode = ((BarcodedItem) item).getBarcode();
			baggingAreaController.setCurrentExpectedWeight(
					ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getExpectedWeight());
			scannedBarcodeItemList.remove(barcode);
			scs.baggingArea.remove(item);
		} else if (item instanceof PLUCodedItem) {
			baggingAreaController.setStatus(BAProcessing.PLU);
			PriceLookupCode plu = ((PLUCodedItem) item).getPLUCode();
			baggingAreaController.setCurrentExpectedWeight(enteredPLUItemList.get(plu));
			enteredPLUItemList.remove(plu);
			scs.baggingArea.remove(item);
		}
	}

	public BigDecimal calculateTotalCosts() {
		BigDecimal total = new BigDecimal(0.0);

		// Barcode: quantity * price
		for (Barcode barcode : scannedBarcodeItemList.keySet()) {
			total = total.add(ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getPrice()
					.multiply(new BigDecimal(scannedBarcodeItemList.get(barcode)).setScale(2, RoundingMode.HALF_DOWN)));
		}

		// PLU: weight * price
		for (PriceLookupCode plu : enteredPLUItemList.keySet()) {
			total = total.add(ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice()
					.multiply(new BigDecimal(enteredPLUItemList.get(plu)).setScale(2, RoundingMode.HALF_DOWN)));
		}

		// bags: quantity * price
		total = total.add(pricePerBag.multiply(new BigDecimal(numOfBags).setScale(2, RoundingMode.HALF_DOWN)));

		return total.setScale(2, RoundingMode.HALF_DOWN);
	}

	public void resetShoppingCart() {
		scanBarcodeController.resetScannedItemList();
		scannedBarcodeItemList = scanBarcodeController.getScannedItemList();
		enterPLUCodeController.resetEnteredItemList();
		enteredPLUItemList = enterPLUCodeController.getEnteredItemList();
		numOfBags = 0;
	}

	public void attach(ShoppingCartObserver observer) {
		shoppingCartObservers.add(observer);
	}

	public void deattach(ShoppingCartObserver observer) {
		shoppingCartObservers.remove(observer);
	}

	public Map<Barcode, Integer> getScannedItemList() {
		return scannedBarcodeItemList;
	}

	public Map<PriceLookupCode, Double> getEnteredItemList() {
		return enteredPLUItemList;
	}

	public int getNumOfBags() {
		return numOfBags;
	}

	public BigDecimal getPricePerBag() {
		return pricePerBag;
	}

	public ScanBarcodeController getScanBarcodeController() {
		return scanBarcodeController;
	}

	public EnterPLUCodeController getEnterPLUCodeController() {
		return enterPLUCodeController;
	}

	public BaggingAreaController getBaggingAreaController() {
		return baggingAreaController;
	}

	public Set<ControllerObserver> getControllerObservers() {
		return controllerObservers;
	}

	private void notifyItemAdded() {
		for (ShoppingCartObserver l : shoppingCartObservers)
			l.itemAdded(this);
	}

	private void notifyWeightDiscrepancy() {
		for (ShoppingCartObserver l : shoppingCartObservers)
			l.baggingAreaWeightDiscrepancy(this);
	}

	private void notifyOverload() {
		for (ShoppingCartObserver l : shoppingCartObservers)
			l.baggingAreaOverload(this);
	}
}

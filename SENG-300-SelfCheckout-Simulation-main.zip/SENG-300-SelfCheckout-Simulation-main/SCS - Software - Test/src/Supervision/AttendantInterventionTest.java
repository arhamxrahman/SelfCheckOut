package Supervision;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.SimulationException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

import BaseTest.BaseTest;
import Station.StationState;

public class AttendantInterventionTest extends BaseTest {

	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testLoginWithValidIDAndPasscode() {
		attendantIntervention.login(employID1, passcode1);
		assertTrue(attendantIntervention.isAuthenticated());
	}

	@Test
	public void testLoginWithInvalidID() {
		String unknownID = "abcd";
		attendantIntervention.login(unknownID, passcode1);
		assertFalse(attendantIntervention.isAuthenticated());
	}

	@Test
	public void testLoginWithInvalidPasscode() {
		String wrongPasscode = "1357";
		attendantIntervention.login(employID1, wrongPasscode);
		assertFalse(attendantIntervention.isAuthenticated());
	}

	@Test
	public void testLogout() {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.logout();
		assertFalse(attendantIntervention.isAuthenticated());
	}

	@Test
	public void testVoidLogout() {
		attendantIntervention.logout();
		assertFalse(attendantIntervention.isAuthenticated());
	}

	@Test
	public void testStartUpStation() {
		attendantIntervention.login(employID1, passcode1);
		assertTrue(attendantIntervention.startUpStation(currentStationIndex));
	}

	@Test
	public void testShutDownStation() {
		attendantIntervention.login(employID1, passcode1);
		assertTrue(attendantIntervention.shutDownStation(currentStationIndex));
	}

	@Test
	public void testStartUpStationNotAuthenticated() {
		assertFalse(attendantIntervention.startUpStation(currentStationIndex));
	}

	@Test
	public void testShutDownStationNotAuthenticated() {
		assertFalse(attendantIntervention.shutDownStation(currentStationIndex));
	}

	@Test
	public void testApproveWeightDiscrepancyAuthenticated() {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.approvedWeightDiscrepancy(currentStationIndex);
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.ADDING);
	}

	@Test
	public void testApproveWeightDiscrepancyNotAuthenticated() {
		assertFalse(attendantIntervention.approvedWeightDiscrepancy(currentStationIndex));
	}

	@Test
	public void testAttendantRemoveProductAuthenticated() throws OverloadException {
		attendantIntervention.login(employID1, passcode1);

		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		assertEquals(1, cart.getEnteredItemList().size());
		assertTrue(attendantIntervention.removeProduct(currentStationIndex, item5));
	}

	@Test
	public void testAttendantRemoveProductNotAuthenticated() throws OverloadException {
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		assertEquals(1, cart.getEnteredItemList().size());
		assertFalse(attendantIntervention.removeProduct(currentStationIndex, item5));
	}

	@Test
	public void testStationBlockedByAttendantAuthenticated() {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.blocksStation(currentStationIndex);
		assertEquals(attendantIntervention.getStationControllers().get(currentStationIndex).getState(),
				StationState.SUSPEND);
	}

	@Test
	public void testStationBlockedByAttendantNotAuthenticated() {
		assertFalse(attendantIntervention.blocksStation(currentStationIndex));
	}

	@Test
	public void testAddPaperAuthenticatedAndSuspended() throws OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		assertTrue(attendantIntervention.addsPaper(currentStationIndex, 1));
	}

	@Test
	public void testAddPaperAuthenticatedButActive() throws OverloadException {
		attendantIntervention.login(employID1, passcode1);
		assertFalse(attendantIntervention.addsPaper(currentStationIndex, 1));
	}

	@Test
	public void testAddPaperNotAuthenticatedAndSuspended() throws OverloadException {
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);
		assertFalse(attendantIntervention.addsPaper(currentStationIndex, 1));
	}

	@Test
	public void testAddPaperNotAuthenticatedAndActive() throws OverloadException {
		assertFalse(attendantIntervention.addsPaper(currentStationIndex, 1));
	}

	@Test(expected = OverloadException.class)
	public void testAddingTooMuchPaper() throws OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		assertTrue(attendantIntervention.addsPaper(currentStationIndex, Integer.MAX_VALUE));
	}

	@Test
	public void testAddInkAuthenticatedAndSuspended() throws OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		assertTrue(attendantIntervention.addsInk(currentStationIndex, 1));
	}

	@Test
	public void testAddInkAuthenticatedButActive() throws OverloadException {
		attendantIntervention.login(employID1, passcode1);
		assertFalse(attendantIntervention.addsInk(currentStationIndex, 1));
	}

	@Test
	public void testAddInkNotAuthenticatedAndSuspended() throws OverloadException {
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);
		assertFalse(attendantIntervention.addsInk(currentStationIndex, 1));
	}

	@Test
	public void testAddInkNotAuthenticatedAndActive() throws OverloadException {
		assertFalse(attendantIntervention.addsInk(currentStationIndex, 1));
	}

	@Test(expected = OverloadException.class)
	public void testAddingTooMuchInk() throws OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		assertTrue(attendantIntervention.addsInk(currentStationIndex, Integer.MAX_VALUE));
	}

	@Test
	// This test case tests if the attendant may load 3 nickels into the machine.
	public void testLoadNickelsAuthenticatedAndSuspended() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		// Make it so that we want to load a bag of nickels in to the machine.
		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);

		// we get the current number of nickels before we load it into the coin
		// dispenser
		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfNickels = scs.coinDispensers.get(nickelValue).size();

		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		// then, we assert that we added 3 nickels from whatever we started at
		assertEquals(scs.coinDispensers.get(nickelValue).size() - currentNumberOfNickels, 3, 0);
	}

	@Test
	public void testLoadNickelsAuthenticatedButActive() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);

		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfNickels = scs.coinDispensers.get(nickelValue).size();

		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		assertNotEquals(scs.coinDispensers.get(nickelValue).size() - currentNumberOfNickels, 3, 0);
	}

	@Test
	public void testLoadNickelsNotAuthenticatedButSuspended() throws SimulationException, OverloadException {
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfNickels = scs.coinDispensers.get(nickelValue).size();

		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		assertNotEquals(scs.coinDispensers.get(nickelValue).size() - currentNumberOfNickels, 3, 0);
	}

	@Test
	public void testLoadNickelsNotAuthenticatedAndActive() throws SimulationException, OverloadException {
		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfNickels = scs.coinDispensers.get(nickelValue).size();

		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		assertNotEquals(scs.coinDispensers.get(nickelValue).size() - currentNumberOfNickels, 3, 0);
	}

	@Test
	// This test case tests if the attendant may load 3 blue bills (5 dollars) into
	// the machine.
	public void testLoadBlueBillsAuthenticatedAndSuspended() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		// Make it so that we want to load a bag of nickels in to the machine.
		Map<Integer, ArrayList<Banknote>> toInsert = new HashMap<Integer, ArrayList<Banknote>>();

		Integer blueBillValue = 5;
		ArrayList<Banknote> bagOfBlueBills = new ArrayList<Banknote>();
		Banknote blueBill = new Banknote(currency, blueBillValue);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);

		toInsert.put(blueBillValue, bagOfBlueBills);

		// we get the current number of blue bills before we load it into the bank note
		// dispenser
		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfBlueBills = scs.banknoteDispensers.get(blueBillValue).size();

		attendantIntervention.refillBanknoteDispenser(currentStationIndex, toInsert);

		assertEquals(scs.banknoteDispensers.get(blueBillValue).size() - currentNumberOfBlueBills, 3, 0);
	}

	@Test
	public void testLoadBlueBillsAuthenticatedButNotSuspended() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);

		Map<Integer, ArrayList<Banknote>> toInsert = new HashMap<Integer, ArrayList<Banknote>>();

		Integer blueBillValue = 5;
		ArrayList<Banknote> bagOfBlueBills = new ArrayList<Banknote>();
		Banknote blueBill = new Banknote(currency, blueBillValue);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);

		toInsert.put(blueBillValue, bagOfBlueBills);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfBlueBills = scs.banknoteDispensers.get(blueBillValue).size();

		attendantIntervention.refillBanknoteDispenser(currentStationIndex, toInsert);

		assertNotEquals(scs.banknoteDispensers.get(blueBillValue).size() - currentNumberOfBlueBills, 3, 0);
	}

	@Test
	public void testLoadBlueBillsNotAuthenticatedButSuspended() throws SimulationException, OverloadException {
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		Map<Integer, ArrayList<Banknote>> toInsert = new HashMap<Integer, ArrayList<Banknote>>();

		Integer blueBillValue = 5;
		ArrayList<Banknote> bagOfBlueBills = new ArrayList<Banknote>();
		Banknote blueBill = new Banknote(currency, blueBillValue);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);

		toInsert.put(blueBillValue, bagOfBlueBills);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfBlueBills = scs.banknoteDispensers.get(blueBillValue).size();

		attendantIntervention.refillBanknoteDispenser(currentStationIndex, toInsert);

		assertNotEquals(scs.banknoteDispensers.get(blueBillValue).size() - currentNumberOfBlueBills, 3, 0);
	}

	@Test
	public void testLoadBlueBillsNotAuthenticatedButActive() throws SimulationException, OverloadException {
		Map<Integer, ArrayList<Banknote>> toInsert = new HashMap<Integer, ArrayList<Banknote>>();

		Integer blueBillValue = 5;
		ArrayList<Banknote> bagOfBlueBills = new ArrayList<Banknote>();
		Banknote blueBill = new Banknote(currency, blueBillValue);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);

		toInsert.put(blueBillValue, bagOfBlueBills);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		int currentNumberOfBlueBills = scs.banknoteDispensers.get(blueBillValue).size();

		attendantIntervention.refillBanknoteDispenser(currentStationIndex, toInsert);

		assertNotEquals(scs.banknoteDispensers.get(blueBillValue).size() - currentNumberOfBlueBills, 3, 0);
	}

	@Test
	// This test case tests if the attendant may unload 3 nickels from the machine.
	public void testUnloadNickelsAuthenticatedAndSuspended() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);

		toInsert.put(nickelValue, bagOfNickels);
		Set<BigDecimal> toDelete = new HashSet<BigDecimal>();
		toDelete.add(nickelValue);
		attendantIntervention.emptyCoinDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertEquals(scs.coinDispensers.get(nickelValue).size(), 0, 0);
	}

	@Test
	public void testUnloadNickelsAuthenticatedButActive() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);

		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);

		toInsert.put(nickelValue, bagOfNickels);
		Set<BigDecimal> toDelete = new HashSet<BigDecimal>();
		toDelete.add(nickelValue);
		attendantIntervention.emptyCoinDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertNotEquals(scs.coinDispensers.get(nickelValue).size(), 0, 0);
	}

	@Test
	public void testUnloadNickelsNotAuthenticatedButSuspended() throws SimulationException, OverloadException {
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);

		toInsert.put(nickelValue, bagOfNickels);
		Set<BigDecimal> toDelete = new HashSet<BigDecimal>();
		toDelete.add(nickelValue);
		attendantIntervention.emptyCoinDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertNotEquals(scs.coinDispensers.get(nickelValue).size(), 0, 0);
	}

	@Test
	public void testUnloadNickelsNotAuthenticatedAndActive() throws SimulationException, OverloadException {
		Map<BigDecimal, ArrayList<Coin>> toInsert = new HashMap<BigDecimal, ArrayList<Coin>>();

		BigDecimal nickelValue = new BigDecimal(0.05);
		ArrayList<Coin> bagOfNickels = new ArrayList<Coin>();
		Coin nickel = new Coin(currency, nickelValue);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		bagOfNickels.add(nickel);
		toInsert.put(nickelValue, bagOfNickels);
		attendantIntervention.refillCoinDispenser(currentStationIndex, toInsert);

		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);
		bagOfNickels.remove(nickel);

		toInsert.put(nickelValue, bagOfNickels);
		Set<BigDecimal> toDelete = new HashSet<BigDecimal>();
		toDelete.add(nickelValue);
		attendantIntervention.emptyCoinDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertNotEquals(scs.coinDispensers.get(nickelValue).size(), 0, 0);
	}

	@Test
	// This test case tests if the attendant unloads 3 blue bills (5 dollars) into
	// the machine
	public void testUnloadBlueBillsAuthenticatedAndSuspended() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		Map<Integer, ArrayList<Banknote>> toInsert = new HashMap<Integer, ArrayList<Banknote>>();

		Integer blueBillValue = 5;
		ArrayList<Banknote> bagOfBlueBills = new ArrayList<Banknote>();
		Banknote blueBill = new Banknote(currency, blueBillValue);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);
		bagOfBlueBills.add(blueBill);

		toInsert.put(blueBillValue, bagOfBlueBills);
		attendantIntervention.refillBanknoteDispenser(currentStationIndex, toInsert);

		bagOfBlueBills.remove(blueBill);
		bagOfBlueBills.remove(blueBill);
		bagOfBlueBills.remove(blueBill);
		toInsert.put(blueBillValue, bagOfBlueBills);
		Set<Integer> toDelete = new HashSet<Integer>();
		toDelete.add(blueBillValue);
		attendantIntervention.emptyBanknoteDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertEquals(scs.banknoteDispensers.get(blueBillValue).size(), 0, 0);
	}

	@Test
	public void testUnloadBlueBillsAuthenticatedButActive() throws SimulationException, OverloadException {
		attendantIntervention.login(employID1, passcode1);

		Integer blueBillValue = 5;
		Set<Integer> toDelete = new HashSet<Integer>();
		toDelete.add(blueBillValue);
		attendantIntervention.emptyBanknoteDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertNotEquals(scs.banknoteDispensers.get(blueBillValue).size(), 0, 0);
	}

	@Test
	public void testUnloadBlueBillsNotAuthenticatedButSuspended() throws SimulationException, OverloadException {
		attendantIntervention.getStationControllers().get(currentStationIndex).setState(StationState.SUSPEND);

		Integer blueBillValue = 5;
		Set<Integer> toDelete = new HashSet<Integer>();
		toDelete.add(blueBillValue);
		attendantIntervention.emptyBanknoteDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertNotEquals(scs.banknoteDispensers.get(blueBillValue).size(), 0, 0);
	}

	@Test
	public void testUnloadBlueBillsNotAuthenticatedAndActive() throws SimulationException, OverloadException {
		Integer blueBillValue = 5;

		Set<Integer> toDelete = new HashSet<Integer>();
		toDelete.add(blueBillValue);
		attendantIntervention.emptyBanknoteDispenser(currentStationIndex, toDelete);

		SelfCheckoutStation scs = attendantIntervention.getStationControllers().get(currentStationIndex).getStation();
		assertNotEquals(scs.banknoteDispensers.get(blueBillValue).size(), 0, 0);
	}
}

package Checkout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;
import Station.ControllerObserver;

public class CardPaymentControllerTest extends BaseTest {
	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testPayWithDebitInFull() throws OverloadException, IOException {
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		checkout.startCheckout();
		assertTrue(isDisabledFromAddingItems());
		checkout.selectPaymentMethod(PaymentMethod.DEBIT);
		assertTrue(isEnabledCardPayment());
		checkout.setAmountToPay(new BigDecimal(1.24));

		scs.cardReader.tap(debitCard);
		assertEquals(checkout.getTotalPayments().doubleValue(), 1.24, 0.0);
		assertTrue(checkout.isPaidInFull());
		assertTrue(isDisabledFromPayments());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);
	}

	@Test
	public void testPayWithDebitAndCredit() throws OverloadException, IOException {
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.DEBIT);
		checkout.setAmountToPay(new BigDecimal(1.00));

		while (checkout.getTotalPayments().doubleValue() == 0) {
			scs.cardReader.swipe(debitCard);
		}
		scs.cardReader.remove();
		assertEquals(checkout.getTotalPayments().doubleValue(), 1.00, 0.0);
		assertFalse(checkout.isPaidInFull());

		assertTrue(isDisabledFromPayments());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);

		Item item6 = new PLUCodedItem(pluCodeItem6, weightBunch6);
		scs.scanningArea.add(item6);
		enterPLUCodeController.entered(pluCodeItem6);
		scs.scanningArea.remove(item6);
		scs.baggingArea.add(item6);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CREDIT);
		checkout.setAmountToPay(new BigDecimal(4.34));

		scs.cardReader.insert(creditCard, pin);
		scs.cardReader.remove();
		assertEquals(checkout.getTotalPayments().doubleValue(), 5.34, 0.0);
		assertTrue(checkout.isPaidInFull());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);
	}

	@Test
	public void testPayWithGiftCards() throws OverloadException, IOException {
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.GIFT);
		checkout.setAmountToPay(new BigDecimal(1.24));

		while (checkout.getTotalPayments().doubleValue() == 0) {
			scs.cardReader.swipe(giftCard);
		}
		scs.cardReader.remove();
		assertEquals(checkout.getTotalPayments().doubleValue(), 1.24, 0);
		assertTrue(checkout.isPaidInFull());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);
	}

	@Test
	public void testPayWithAccountOfInsufficientFunds() throws OverloadException, IOException {
		Item item7 = new PLUCodedItem(pluCodeItem7, weightBunch6);
		scs.scanningArea.add(item7);
		enterPLUCodeController.entered(pluCodeItem7);
		scs.scanningArea.remove(item7);
		scs.baggingArea.add(item7);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CREDIT);
		checkout.setAmountToPay(new BigDecimal(11.01));
		scs.cardReader.insert(creditCard, pin);
		scs.cardReader.remove();
		assertEquals(checkout.getTotalPayments().doubleValue(), 0.0, 0);
		assertFalse(checkout.isPaidInFull());
	}

	@Test
	public void testNoObserverAttached() throws DisabledException, OverloadException, IOException {
		Set<ControllerObserver> observers = checkout.getAttachedObservers();
		for (ControllerObserver observer : observers) {
			if (observer instanceof CardPaymentObserver) {
				cardPaymentController.deattach((CardPaymentObserver) observer);
			}
		}

		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.GIFT);
		checkout.setAmountToPay(new BigDecimal(1.24));

		scs.cardReader.swipe(giftCard);
		scs.cardReader.remove();
		assertEquals(checkout.getTotalPayments().doubleValue(), 0.0, 0);
	}

	private boolean isDisabledFromAddingItems() {
		return scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled() && scs.scanningArea.isDisabled()
				&& scs.baggingArea.isDisabled() && scs.printer.isDisabled();
	}

	private boolean isEnabledCardPayment() {
		return !scs.cardReader.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled();
	}

	private boolean isDisabledFromPayments() {
		return !scs.mainScanner.isDisabled() && !scs.handheldScanner.isDisabled() && !scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && !scs.printer.isDisabled();
	}
}

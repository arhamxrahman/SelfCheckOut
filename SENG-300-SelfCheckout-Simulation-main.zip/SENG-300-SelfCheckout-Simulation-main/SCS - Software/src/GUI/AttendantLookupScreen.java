package GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.external.ProductDatabases;
import org.lsmr.selfcheckout.products.PLUCodedProduct;

import Station.StationController;

public class AttendantLookupScreen {

	StationController stationController;

	JFrame stationFrame;
	JFrame lookupFrame;

	JSplitPane splitPane;

	// Top
	JPanel topPanel;
	JPanel inputPanel;
	JButton backButton;
	JTextField keyword;

	// Button
	JPanel bottomPanel;
	JScrollPane scrollPane;
	JPanel lookupPanel;

	// https://stackoverflow.com/questions/15694107/how-to-layout-multiple-panels-on-a-jframe-java
	public AttendantLookupScreen(JFrame stationFrame) {
		this.stationFrame = stationFrame;

		lookupFrame = new JFrame("Look Up Product");

		splitPane = new JSplitPane();
		topPanel = new JPanel(); // for top component
		bottomPanel = new JPanel(); // for bottom component

		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		splitPane.setDividerLocation(100);
		splitPane.setTopComponent(topPanel);
		splitPane.setBottomComponent(bottomPanel);

		setupTopPanel();
		setupBottomPanel();

		lookupFrame.setSize(800, 650);
		lookupFrame.getContentPane().add(splitPane);
		lookupFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		lookupFrame.setVisible(true);
	}

	private void setupTopPanel() {
		// Top
		backButton = new JButton("Back");
		backButton.setPreferredSize(new Dimension(150, 150));
		backButton.setMaximumSize(new Dimension(150, 150));
		backButton.setBackground(Color.RED);
		backButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationFrame.setVisible(true);
				lookupFrame.dispose();
			}
		});

		keyword = new JTextField("Search for product...");
		keyword.setEditable(true);
		keyword.selectAll();
		EventQueue.invokeLater(() -> keyword.requestFocusInWindow());

		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.X_AXIS));
		topPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150));
		topPanel.add(backButton);
		topPanel.add(keyword);

		keyword.getDocument().addDocumentListener(new DocumentListener() {

			public void changedUpdate(DocumentEvent e) {
			}

			public void insertUpdate(DocumentEvent e) {
				updateLookupPanel();
			}

			public void removeUpdate(DocumentEvent e) {
				updateLookupPanel();
			}
		});

	}

	private void updateLookupPanel() {
		lookupPanel.removeAll();
		lookupPanel.revalidate();
		lookupPanel.repaint();

		List<PLUCodedProduct> listToPaint = searchResult();
		for (PLUCodedProduct product : listToPaint) {
			JButton btn = new JButton(
					"<html><center>" + product.getDescription() + "<br/>" + product.getPLUCode() + "</center></html>");
			btn.setPreferredSize(new Dimension(150, 150));

			lookupPanel.add(btn);
		}
	}

	private List<PLUCodedProduct> searchResult() {
		List<PLUCodedProduct> resultList = new ArrayList<>();

		String key = keyword.getText();
		int wordSize = key.length();

		if (wordSize == 0) {
			return resultList = new ArrayList<PLUCodedProduct>(ProductDatabases.PLU_PRODUCT_DATABASE.values());
		}

		for (PriceLookupCode plu : ProductDatabases.PLU_PRODUCT_DATABASE.keySet()) {
			PLUCodedProduct product = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu);

			if (product.getDescription().toLowerCase().contains(key.toLowerCase())) {
				resultList.add(product);
			}
		}

		return resultList;
	}

	private void setupBottomPanel() {
		// Bottom
		scrollPane = new JScrollPane();
		lookupPanel = new JPanel();

		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
		bottomPanel.add(scrollPane);
		scrollPane.setViewportView(lookupPanel);

		for (PriceLookupCode plu : ProductDatabases.PLU_PRODUCT_DATABASE.keySet()) {
			PLUCodedProduct product = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu);
			JButton btn = new JButton("<html><center>" + product.getDescription() + "<br/>" + plu + "</center></html>");
			btn.setPreferredSize(new Dimension(150, 150));

			lookupPanel.add(btn);
		}
	}
}

package Station;

public enum StationState {
	ADDING, BAGGING, PAYING, PAID, SUSPEND
}

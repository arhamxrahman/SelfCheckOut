package GUI;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Currency;

import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Card;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.Numeral;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.SupervisionStation;
import org.lsmr.selfcheckout.external.CardIssuer;
import org.lsmr.selfcheckout.external.ProductDatabases;
import org.lsmr.selfcheckout.products.BarcodedProduct;
import org.lsmr.selfcheckout.products.PLUCodedProduct;

import Checkout.CardIssuerDatabase;
import Checkout.CardPaymentController;
import Checkout.CashPaymentController;
import Checkout.Checkout;
import Checkout.MembershipController;
import ShoppingCart.BaggingAreaController;
import ShoppingCart.EnterPLUCodeController;
import ShoppingCart.ScanBarcodeController;
import ShoppingCart.ShoppingCart;
import Station.StationController;
import Supervision.AttendantIntervention;
import Supervision.AttendantLoginDatabase;

public class App {
	private SupervisionStation attendantStation = new SupervisionStation();
	private AttendantLoginDatabase loginDatabase = new AttendantLoginDatabase();
	private AttendantIntervention attendantIntervention;

	// Declaring parameters for self checkout station
	private Currency currency = Currency.getInstance("CAD");
	private final int[] banknoteDenominations = { 5, 10, 20, 50, 100 };
	private final BigDecimal[] coinDenominations = { new BigDecimal(0.05), new BigDecimal(0.10), new BigDecimal(0.25),
			new BigDecimal(1.00), new BigDecimal(2.00) };
	private int scaleMaxWeight;
	private int scaleSensitivity;

	// Initializing barcode of the items
	private Numeral[] nItem1 = { Numeral.one, Numeral.two, Numeral.three, Numeral.four };
	private Numeral[] nItem2 = { Numeral.two, Numeral.three, Numeral.four, Numeral.one };
	private Numeral[] nItem3 = { Numeral.three, Numeral.four, Numeral.one, Numeral.two };
	private Numeral[] nItem4 = { Numeral.four, Numeral.one, Numeral.two, Numeral.three };

	Barcode barcodeItem1 = new Barcode(nItem1);
	Barcode barcodeItem2 = new Barcode(nItem2);
	Barcode barcodeItem3 = new Barcode(nItem3);
	Barcode barcodeItem4 = new Barcode(nItem4);

	// Initializing description of barcode items
	private String nameItem1 = "Avocado Bags";
	private String nameItem2 = "Blueberry Muffins";
	private String nameItem3 = "Orange Juice";
	private String nameItem4 = "Cheese Crackers";

	// Initializing prices of barcode items
	private BigDecimal priceItem1 = new BigDecimal(5.99);
	private BigDecimal priceItem2 = new BigDecimal(4.50);
	private BigDecimal priceItem3 = new BigDecimal(6.79);
	private BigDecimal priceItem4 = new BigDecimal(3.49);

	// Initializing weights of barcode items
	private double weightItem1 = 170.0;
	private double weightItem2 = 570.0;
	private double weightItem3 = 2000.0;
	private double weightItem4 = 180.0;

	// Initializing PLU code of the items
	private PriceLookupCode pluCodeItem5 = new PriceLookupCode("1111");
	private PriceLookupCode pluCodeItem6 = new PriceLookupCode("2222");
	private PriceLookupCode pluCodeItem7 = new PriceLookupCode("3333");
	private PriceLookupCode pluCodeItem8 = new PriceLookupCode("4444");

	// Initializing description of PLU items
	private String nameItem5 = "Bananas";
	private String nameItem6 = "Roma Tomatos";
	private String nameItem7 = "Grapes";
	private String nameItem8 = "Broccoli Crowns";

	// Initializing prices of PLU items
	private BigDecimal priceItem5 = new BigDecimal(0.00130);
	private BigDecimal priceItem6 = new BigDecimal(0.00328);
	private BigDecimal priceItem7 = new BigDecimal(0.00880);
	private BigDecimal priceItem8 = new BigDecimal(0.00549);

	// Initializing weights of PLU items
	private double weightBunch5 = 950.0;
	private double weightBunch6 = 1250.8;
	private double weightBunch7 = 450.6;
	private double weightBunch8 = 175.5;

	// Initializing Coins
	private Coin nickel = new Coin(currency, new BigDecimal(0.05));
	private Coin dime = new Coin(currency, new BigDecimal(0.10));
	private Coin quarter = new Coin(currency, new BigDecimal(0.25));
	private Coin loonie = new Coin(currency, new BigDecimal(1.00));
	private Coin toonie = new Coin(currency, new BigDecimal(2.00));

	private Coin[] nickels = { nickel, nickel, nickel, nickel, nickel };
	private Coin[] dimes = { dime, dime, dime, dime, dime };
	private Coin[] quarters = { quarter, quarter, quarter, quarter, quarter };
	private Coin[] loonies = { loonie, loonie, loonie, loonie, loonie };
	private Coin[] toonies = { toonie, toonie, toonie, toonie, toonie };

	// Initializing Banknotes
	private Banknote fiveDollars = new Banknote(currency, 5);
	private Banknote tenDollars = new Banknote(currency, 10);
	private Banknote twentyDollars = new Banknote(currency, 20);
	private Banknote fiftyDollars = new Banknote(currency, 50);
	private Banknote hundredDollars = new Banknote(currency, 10);

	private Banknote[] fives = { fiveDollars, fiveDollars, fiveDollars, fiveDollars, fiveDollars };
	private Banknote[] tens = { tenDollars, tenDollars, tenDollars, tenDollars, tenDollars };
	private Banknote[] twenties = { twentyDollars, twentyDollars, twentyDollars, twentyDollars, twentyDollars };
	private Banknote[] fifties = { fiftyDollars, fiftyDollars, fiftyDollars };
	private Banknote[] hundreds = { hundredDollars, hundredDollars };

	// Initializing Card Data
	private String debitCardType = "debit";
	private String creditCardType = "credit";
	private String giftCardType = "gift";
	private String membershipCardType = "membership";

	private String cardNumber = "0000111122223333";
	private String cardholder = "Adam Smith";
	private String cvv = "123";
	private String pin = "4567";
	private Calendar expiry = Calendar.getInstance();
	private boolean tapEnabled = true;
	private boolean tapNotEnabled = false;
	private boolean hasChip = true;
	private boolean hasNoChip = false;
	private BigDecimal accountBalance = new BigDecimal(10.0);

	// Initializing Card Issuers
	private CardIssuer debitCardIssuer = new CardIssuer(debitCardType);
	private CardIssuer creditCardIssuer = new CardIssuer(creditCardType);
	private CardIssuer giftCardIssuer = new CardIssuer(giftCardType);
	private CardIssuer membershipCardIssuer = new CardIssuer(membershipCardType);

	// Initializing Cards
	private Card debitCard = new Card(debitCardType, cardNumber, cardholder, cvv, pin, tapEnabled, hasChip);
	private Card creditCard = new Card(creditCardType, cardNumber, cardholder, cvv, pin, tapEnabled, hasChip);
	private Card giftCard = new Card(giftCardType, cardNumber, cardholder, cvv, pin, tapEnabled, hasChip);
	private Card membershipCard = new Card(membershipCardType, cardNumber, cardholder, null, null, tapEnabled,
			hasNoChip);

	// Initializing Employee Credentials
	private String employID1 = "1234";
	private String employID2 = "5678";
	private String passcode1 = "9876";
	private String passcode2 = "5432";

	public void setup() throws OverloadException {

		// Setup Employee Login Database
		loginDatabase.addNewAttendantLogin(employID1, passcode1);
		loginDatabase.addNewAttendantLogin(employID2, passcode2);

		// Initializing parameters for SCS
		scaleMaxWeight = 23000;
		scaleSensitivity = 1;

		// Initializing 3 SCSs
		for (int i = 0; i < 3; i++) {
			SelfCheckoutStation scs = new SelfCheckoutStation(currency, banknoteDenominations, coinDenominations,
					scaleMaxWeight, scaleSensitivity);
			attendantStation.add(scs);
		}

		this.attendantIntervention = new AttendantIntervention(attendantStation, loginDatabase);
		int stationCounts = attendantIntervention.getStationControllers().size();

		for (int i = 0; i < stationCounts; i++) {
			StationController stationController = attendantIntervention.getStationControllers().get(i);
			ScanBarcodeController scanBarcodeController = new ScanBarcodeController(stationController);
			EnterPLUCodeController enterPLUCodeController = new EnterPLUCodeController(stationController);
			BaggingAreaController baggingAreaController = new BaggingAreaController(stationController);
			baggingAreaController.setBarcodeScanController(scanBarcodeController);
			baggingAreaController.setPluCodeEntryController(enterPLUCodeController);
			ShoppingCart cart = new ShoppingCart(stationController, scanBarcodeController, enterPLUCodeController,
					baggingAreaController);
			stationController.setShoppingCart(cart);

			CashPaymentController cashPaymentController = new CashPaymentController(stationController);
			CardPaymentController cardPaymentController = new CardPaymentController(stationController);
			MembershipController membershipController = new MembershipController(stationController);
			Checkout checkout = new Checkout(stationController, cart, cashPaymentController, cardPaymentController,
					membershipController);
			stationController.setCheckout(checkout);

			SelfCheckoutStation scs = stationController.getStation();
			// Loading coins and banknotes
			scs.coinDispensers.get(new BigDecimal(0.05)).load(nickels);
			scs.coinDispensers.get(new BigDecimal(0.10)).load(dimes);
			scs.coinDispensers.get(new BigDecimal(0.25)).load(quarters);
			scs.coinDispensers.get(new BigDecimal(1.00)).load(loonies);
			scs.coinDispensers.get(new BigDecimal(2.00)).load(toonies);

			scs.banknoteDispensers.get(5).load(fives);
			scs.banknoteDispensers.get(10).load(tens);
			scs.banknoteDispensers.get(20).load(twenties);
			scs.banknoteDispensers.get(50).load(fifties);
			scs.banknoteDispensers.get(100).load(hundreds);
		}

		// Initializing BARCODED_PRODUCT_DATABASE
		BarcodedProduct barProduct1 = new BarcodedProduct(barcodeItem1, nameItem1, priceItem1, weightItem1);
		BarcodedProduct barProduct2 = new BarcodedProduct(barcodeItem2, nameItem2, priceItem2, weightItem2);
		BarcodedProduct barProduct3 = new BarcodedProduct(barcodeItem3, nameItem3, priceItem3, weightItem3);
		BarcodedProduct barProduct4 = new BarcodedProduct(barcodeItem4, nameItem4, priceItem4, weightItem4);

		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem1, barProduct1);
		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem2, barProduct2);
		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem3, barProduct3);
		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem4, barProduct4);

		// Initializing PLU_PRODUCT_DATABASE
		PLUCodedProduct pluProduct5 = new PLUCodedProduct(pluCodeItem5, nameItem5, priceItem5);
		PLUCodedProduct pluProduct6 = new PLUCodedProduct(pluCodeItem6, nameItem6, priceItem6);
		PLUCodedProduct pluProduct7 = new PLUCodedProduct(pluCodeItem7, nameItem7, priceItem7);
		PLUCodedProduct pluProduct8 = new PLUCodedProduct(pluCodeItem8, nameItem8, priceItem8);

		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem5, pluProduct5);
		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem6, pluProduct6);
		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem7, pluProduct7);
		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem8, pluProduct8);

		// Initializing Card Issuer Database
		expiry.set(2024, 4, 30);

		debitCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(debitCardType, debitCardIssuer);

		creditCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(creditCardType, creditCardIssuer);

		giftCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(giftCardType, giftCardIssuer);

		membershipCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(membershipCardType, membershipCardIssuer);
	}

	public StationController getStationController(int stationIndex) {
		return attendantIntervention.getStationControllers().get(stationIndex);
	}

	public AttendantIntervention getAttendantIntervention() {
		return attendantIntervention;
	}

	public Item getDummyItem() {
		return new BarcodedItem(barcodeItem1, weightItem1);
	}

	public Card getDummyCard() {
		return creditCard;
	}

	public Card getDummyMembershipCard() {
		return membershipCard;
	}

	public String getDummyCardPin() {
		return pin;
	}

	// Main entry of GUI
	public static void main(String[] args) {
		App app = new App();
		try {
			app.setup();
//			WelcomeScreen screen = new WelcomeScreen(app, 0);
			AttendantLogin start = new AttendantLogin(app);
		} catch (OverloadException e) {
		}
	}
}

package Supervision;

public interface AttendantObserver {

	public void blockStation();

	public void unblockStation();

	public void removeItem();
}

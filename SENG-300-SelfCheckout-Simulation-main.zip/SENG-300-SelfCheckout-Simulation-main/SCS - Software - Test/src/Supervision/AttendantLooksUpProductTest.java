package Supervision;

import static org.junit.Assert.assertEquals;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.InvalidArgumentSimulationException;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.products.PLUCodedProduct;

import BaseTest.BaseTest;
import ShoppingCart.BAProcessing;
import ShoppingCart.EnterPLUCodeObserver;
import Station.ControllerObserver;

public class AttendantLooksUpProductTest extends BaseTest  {
	public String descriptionEnteredAttendant;
	AttendantLooksUpProduct obj = new AttendantLooksUpProduct(scs);


	@Before
	public void setup() throws OverloadException {
		super.setup();



	}

	@Test
	public void testAttendantLooksUpProduct() {
			}

	@Test
	public void testAttach( ) {
		obj.attach(null);

	}

	@Test
	public void testDeattach() {
		AttendantLooksUpProduct.deattach(null);
 	}

	@Test
	public void testGetDescriptionEnteredAttendant() {
		obj.getDescriptionEnteredAttendant();
 	}

	@Test
	public void testSetDescriptionEnteredAttendant() {
		obj.setDescriptionEnteredAttendant(descriptionEnteredAttendant);
 	}

	@Test
	public void testCheckEnteredDescription() throws OverloadException {
		 descriptionEnteredAttendant = "anana";
		 PLUCodedProduct plucp = new PLUCodedProduct(pluCodeItem5, nameItem5 , priceItem5);
		 assertEquals(plucp.getDescription(), "Bananas");
		 obj.checkEnteredDescription(plucp, descriptionEnteredAttendant, scs);
 	}
	@Test(expected = InvalidArgumentSimulationException.class)
	public void testCheckEnteredDescriptionElse() throws OverloadException  {
		 PLUCodedProduct plucp = new PLUCodedProduct(pluCodeItem5, nameItem5 , priceItem5);
		 String descriptionEnteredAttendant2 = "jhkjhk";

			obj.checkEnteredDescription(plucp, descriptionEnteredAttendant2, scs);
		
 	}
	@Test
	public void testGetLastEnteredPLUProductWeight() {
		obj.getLastEnteredPLUProductWeight();

 	}

	@Test
	public void testGetEnteredItemList() {
		obj.getEnteredItemList();

 	}
	
	@Test
	public void testNoObserverAttached() throws OverloadException {

	
	}


	

}

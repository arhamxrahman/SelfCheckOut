package Checkout;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.EmptyException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.external.ProductDatabases;

import ShoppingCart.ShoppingCart;

public class ReceiptController {
	private SelfCheckoutStation scs;
	private Map<Barcode, Integer> scannedBarcodeItemList; // for Barcode products
	private Map<PriceLookupCode, Double> enteredPLUItemList; // for PLU code products
	private int numOfBags = 0;
	private BigDecimal pricePerBag;
	private BigDecimal totalCosts; // value of cart
	private BigDecimal totalPayments;
	private BigDecimal change;
	private String membership;
	private ReceiptPrinterTracker printer;

	public ReceiptController(SelfCheckoutStation scs, ShoppingCart cart, Checkout checkout, String membership) {
		this.scs = scs;
		scannedBarcodeItemList = cart.getScannedItemList();
		enteredPLUItemList = cart.getEnteredItemList();
		numOfBags = cart.getNumOfBags();
		pricePerBag = cart.getPricePerBag();
		totalCosts = checkout.getTotalCosts().setScale(2, RoundingMode.HALF_DOWN);
		totalPayments = checkout.getTotalPayments().setScale(2, RoundingMode.HALF_DOWN);
		change = checkout.getTotalPayments().subtract(checkout.getTotalCosts()).setScale(2, RoundingMode.HALF_DOWN);
		this.membership = membership;
		printer = new ReceiptPrinterTracker(scs);
	}

	public void printReceipt() {
		StringBuilder str = new StringBuilder();
		str.append("Welcome #");

		if (membership != null) {
			str.append(membership);
			str.append('\n');
		}

		for (Barcode barcode : scannedBarcodeItemList.keySet()) {
			String description = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getDescription();
			int quantity = scannedBarcodeItemList.get(barcode);
			BigDecimal price = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getPrice().setScale(2,
					RoundingMode.HALF_DOWN);
			str.append(barcode);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(quantity);
			str.append(" @ $");
			str.append(price);
			str.append("		  ");
			str.append(price.multiply(new BigDecimal(quantity)));
			str.append('\n');
		}

		for (PriceLookupCode plu : enteredPLUItemList.keySet()) {
			String description = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getDescription();
			BigDecimal weight = new BigDecimal(enteredPLUItemList.get(plu) / 1000).setScale(3, RoundingMode.HALF_DOWN);
			;
			BigDecimal price = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice().multiply(new BigDecimal(1000))
					.setScale(2, RoundingMode.HALF_DOWN);
			BigDecimal cost = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice()
					.multiply(new BigDecimal(enteredPLUItemList.get(plu))).setScale(2, RoundingMode.HALF_DOWN);
			str.append(plu);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(weight);
			str.append(" kg @ $");
			str.append(price);
			str.append("/kg		  ");
			str.append(cost);
			str.append('\n');
		}

		if (numOfBags > 0) {
			BigDecimal cost = pricePerBag.multiply(new BigDecimal(numOfBags)).setScale(2, RoundingMode.HALF_DOWN);
			str.append("Plastic Bag");
			str.append('\n');
			str.append(numOfBags);
			str.append(" @ $");
			str.append(pricePerBag);
			str.append("		  ");
			str.append(cost);
			str.append('\n');
		}

		str.append("Total				");
		str.append(totalCosts);
		str.append('\n');
		str.append("Received			");
		str.append(totalPayments);
		str.append('\n');
		if (change.compareTo(new BigDecimal(0.00)) > 0) {
			str.append("Change				");
			str.append(change);
			str.append('\n');
		}

		str.append("Thank you for shopping with us!");

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			try {
				printer.print(c);
//				scs.printer.print(c);
			} catch (EmptyException e) {
				// We detect levels of paper and ink when low, they should never be empty
			} catch (OverloadException e) {
				// We assume current design of receipt will fit in each line
			}
		}
		scs.printer.cutPaper();
	}
}

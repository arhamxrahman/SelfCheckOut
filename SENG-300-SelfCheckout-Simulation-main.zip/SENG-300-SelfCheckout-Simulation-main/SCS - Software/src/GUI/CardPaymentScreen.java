package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.math.BigDecimal;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import Station.StationController;

public class CardPaymentScreen {
	StationController stationController;
	Session session;

	JFrame checkoutFrame;

	JFrame cardPaymentGUI;
	JPanel cardPaymentGUIPanel;

	JLabel cardPaymentLabel;
	JTextField amountToPay;

	JButton tapButton;
	JButton swipeButton;
	JButton insertButton;

	JButton back;

	public CardPaymentScreen(JFrame checkoutFrame, StationController stationController, Session session) {
		this.checkoutFrame = checkoutFrame;
		this.stationController = stationController;
		this.session = session;

		cardPaymentGUI = new JFrame("Card Payment");
		cardPaymentGUIPanel = new JPanel();
		cardPaymentGUIPanel.setLayout(new GridBagLayout());

		addWidgets();

		cardPaymentGUI.getContentPane().add(cardPaymentGUIPanel, BorderLayout.CENTER);
		cardPaymentGUI.setLocationRelativeTo(null);
		cardPaymentGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		cardPaymentGUI.setSize(600, 400);
		cardPaymentGUI.setVisible(true);
	}

	private void addWidgets() {

		cardPaymentLabel = new JLabel("How much would you like to pay?", SwingConstants.CENTER);

		amountToPay = new JTextField();
		amountToPay.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if ((Character.isDigit(c)) || (c == KeyEvent.VK_PERIOD) || (c == KeyEvent.VK_BACK_SPACE)) {
					int punto = 0;
					if (c == KeyEvent.VK_PERIOD) {
						String s = amountToPay.getText();
						int dot = s.indexOf('.');
						if (dot != -1) {
							e.consume();
						}
					}
				} else {
					e.consume();
				}
			}
		});

		tapButton = new JButton("Tap");
		tapButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					BigDecimal amount = new BigDecimal(amountToPay.getText()).setScale(2);
					stationController.getCheckout().setAmountToPay(amount);
					stationController.getStation().cardReader.tap(session.getCurrentCardForPayment());
					checkoutFrame.setVisible(true); // back to the adding page
					cardPaymentGUI.dispose();
				} catch (IOException e1) {

				}
			}
		});

		swipeButton = new JButton("Swipe");
		swipeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					BigDecimal amount = new BigDecimal(amountToPay.getText()).setScale(2);
					stationController.getCheckout().setAmountToPay(amount);
					stationController.getStation().cardReader.swipe(session.getCurrentCardForPayment());
					checkoutFrame.setVisible(true); // back to the adding page
					cardPaymentGUI.dispose();
				} catch (IOException e1) {

				}
			}
		});

		insertButton = new JButton("Insert");
		insertButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					BigDecimal amount = new BigDecimal(amountToPay.getText()).setScale(2);
					stationController.getCheckout().setAmountToPay(amount);
					stationController.getStation().cardReader.insert(session.getCurrentCardForPayment(),
							session.getCardPIN());
					checkoutFrame.setVisible(true); // back to the adding page
					cardPaymentGUI.dispose();
				} catch (IOException e1) {

				}
			}
		});

		back = new JButton("Back");
		back.setBackground(Color.RED);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				checkoutFrame.setVisible(true); // back to the adding page
				cardPaymentGUI.dispose();
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 3;
		cardPaymentGUIPanel.add(cardPaymentLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 3;
		cardPaymentGUIPanel.add(amountToPay, gbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		cardPaymentGUIPanel.add(tapButton, gbc);
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		cardPaymentGUIPanel.add(swipeButton, gbc);
		gbc.gridx = 2;
		gbc.gridy = 2;
		gbc.gridwidth = 1;
		cardPaymentGUIPanel.add(insertButton, gbc);
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 3;
		cardPaymentGUIPanel.add(back, gbc);
	}
}

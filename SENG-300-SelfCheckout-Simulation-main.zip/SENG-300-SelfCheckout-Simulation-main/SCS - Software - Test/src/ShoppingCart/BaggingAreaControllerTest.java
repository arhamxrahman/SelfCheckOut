package ShoppingCart;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.external.ProductDatabases;

import BaseTest.BaseTest;
import Station.ControllerObserver;
import Station.StationState;

public class BaggingAreaControllerTest extends BaseTest {

	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testUnknownItemInBaggingArea() {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item1 = new BarcodedItem(barcodeItem1, 300.0);
		scs.baggingArea.add(item1);
		assertTrue(isSystemSuspended());
	}

	@Test
	public void testCustomerUsingReusableBags() {
		assertEquals(stationController.getState(), StationState.ADDING);
		cart.useReusableBags();

		class ReusableBag extends Item {
			protected ReusableBag(double weightInGrams) {
				super(weightInGrams);
			}
		}

		double weightOfBags = 19.63;
		Item usableBags = new ReusableBag(weightOfBags);
		double lastWeight = baggingAreaController.getLastScaleWeightInGrams();

		scs.baggingArea.add(usableBags);
		assertEquals(baggingAreaController.getLastScaleWeightInGrams(), lastWeight + weightOfBags, 0);
		assertEquals(stationController.getState(), StationState.SUSPEND);
		assertTrue(isSystemSuspended());
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PENDING);
	}

	@Test
	public void testCustomerPurchasingPlasticBagsWithinLimit() {
		assertEquals(stationController.getState(), StationState.ADDING);
		int numOfBags = 5;
		cart.addPlasticBags(numOfBags);

		class PlasticBag extends Item {
			protected PlasticBag(double weightInGrams) {
				super(weightInGrams);
			}
		}

		double weightOfBag = 9;
		Item plasticBags = new PlasticBag(weightOfBag * numOfBags);
		double lastWeight = baggingAreaController.getLastScaleWeightInGrams();
		scs.baggingArea.add(plasticBags);

		assertTrue(weightOfBag * numOfBags <= baggingAreaController.getCurrentExpectedWeight());
		assertEquals(baggingAreaController.getTotalWeightInBaggingArea(), lastWeight + (weightOfBag * numOfBags), 0);
		assertEquals(baggingAreaController.getLastScaleWeightInGrams(), lastWeight + (weightOfBag * numOfBags), 0);
		assertTrue(isAddingEnabled());
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PENDING);
	}

	@Test
	public void testCustomerPurchasingPlasticBagsExceedLimit() {
		assertEquals(stationController.getState(), StationState.ADDING);
		int numOfBags = 5;
		cart.addPlasticBags(numOfBags);

		Item randomItem = new BarcodedItem(barcodeItem1, 50.01);
		scs.baggingArea.add(randomItem);

		assertTrue(randomItem.getWeight() > baggingAreaController.getCurrentExpectedWeight());
		assertEquals(stationController.getState(), StationState.SUSPEND);
		assertTrue(isSystemSuspended());
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PENDING);
	}

	@Test
	public void testExpectedBarcodeItemPlacedInBaggingArea() throws OverloadException {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		assertEquals(baggingAreaController.getStatus(), BAProcessing.BARCODE);
		assertEquals(stationController.getState(), StationState.BAGGING);
		assertTrue(isBaggingEnabled());
		assertEquals(scanBarcodeController.getScannedItemList().size(), 1, 0);
		assertEquals(scanBarcodeController.getLastScannedBarcodedProductWeight(),
				ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcodeItem1).getExpectedWeight(), 0);
		double lastWeight = baggingAreaController.getLastScaleWeightInGrams();

		scs.baggingArea.add(item1);
		assertTrue(Math.abs(scs.baggingArea.getCurrentWeight()
				- baggingAreaController.getCurrentExpectedWeight()) <= scs.baggingArea.getSensitivity());
		assertEquals(baggingAreaController.getTotalWeightInBaggingArea(), weightItem1,
				scs.baggingArea.getSensitivity());
		assertEquals(baggingAreaController.getLastScaleWeightInGrams(), lastWeight + weightItem1,
				scs.baggingArea.getSensitivity());
		assertEquals(stationController.getState(), StationState.ADDING);
		assertTrue(isAddingEnabled());
	}

	@Test
	public void testWrongBarcodeItemPlacedInBaggingArea() throws OverloadException {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		Item item2 = new BarcodedItem(barcodeItem2, weightItem2);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		assertEquals(scanBarcodeController.getLastScannedBarcodedProductWeight(),
				ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcodeItem1).getExpectedWeight(), 0);
		assertEquals(stationController.getState(), StationState.BAGGING);
		scs.baggingArea.add(item2);
		assertFalse(Math.abs(scs.baggingArea.getCurrentWeight()
				- baggingAreaController.getCurrentExpectedWeight()) <= scs.baggingArea.getSensitivity());
		assertEquals(stationController.getState(), StationState.SUSPEND);
		assertTrue(isSystemSuspended());
	}

	@Test
	public void testExpectedPLUItemPlacedInBaggingArea() throws OverloadException {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PLU);
		assertEquals(stationController.getState(), StationState.BAGGING);
		assertTrue(isBaggingEnabled());
		assertEquals(enterPLUCodeController.getEnteredItemList().size(), 1, 0);
		assertEquals(enterPLUCodeController.getEnteredItemList().get(pluCodeItem5), weightBunch5,
				scs.scanningArea.getSensitivity());
		double lastWeight = baggingAreaController.getLastScaleWeightInGrams();

		scs.baggingArea.add(item5);
		assertTrue(Math.abs(scs.baggingArea.getCurrentWeight()
				- baggingAreaController.getCurrentExpectedWeight()) <= scs.baggingArea.getSensitivity());
		assertEquals(baggingAreaController.getTotalWeightInBaggingArea(), weightBunch5,
				scs.baggingArea.getSensitivity());
		assertEquals(baggingAreaController.getLastScaleWeightInGrams(), lastWeight + weightBunch5,
				scs.baggingArea.getSensitivity());
		assertEquals(stationController.getState(), StationState.ADDING);
		assertTrue(isAddingEnabled());
	}

	@Test
	public void testWrongPLUItemPlacedInBaggingArea() throws OverloadException {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PLU);
		assertEquals(stationController.getState(), StationState.BAGGING);
		assertTrue(isBaggingEnabled());
		assertEquals(enterPLUCodeController.getEnteredItemList().get(pluCodeItem5), weightBunch5,
				scs.scanningArea.getSensitivity());

		Item item6 = new PLUCodedItem(pluCodeItem6, weightBunch6);
		scs.baggingArea.add(item6);
		assertFalse(Math.abs(scs.baggingArea.getCurrentWeight()
				- baggingAreaController.getCurrentExpectedWeight()) <= scs.baggingArea.getSensitivity());
		assertEquals(stationController.getState(), StationState.SUSPEND);
		assertTrue(isSystemSuspended());
	}

	@Test
	public void testAttendantRemoveBarcodeItemFromBaggingArea() {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		Item item2 = new BarcodedItem(barcodeItem2, weightItem2);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		scs.baggingArea.add(item1);
		while (cart.getScannedItemList().get(barcodeItem2) == null) {
			scs.handheldScanner.scan(item2);
		}
		scs.baggingArea.add(item2);
		cart.removeProduct(item2);
		assertEquals(stationController.getState(), StationState.ADDING);
		assertTrue(isAddingEnabled());
	}

	@Test
	public void testAttendantRemovePLUItemFromBaggingArea() throws OverloadException {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.baggingArea.add(item5);
		cart.removeProduct(item5);
		assertEquals(stationController.getState(), StationState.ADDING);
		assertTrue(isAddingEnabled());
	}

	@Test
	public void testAddUnexpectedItemToBaggingArea() {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.baggingArea.add(item1);
		assertEquals(stationController.getState(), StationState.SUSPEND);
		assertTrue(isSystemSuspended());
	}

	@Test
	public void testRemoveUnexpectedBarcodeItemFromBaggingArea() {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		scs.baggingArea.add(item1);
		scs.baggingArea.remove(item1);
		assertEquals(stationController.getState(), StationState.SUSPEND);
		assertTrue(isSystemSuspended());
	}

	@Test
	public void testRemoveUnexpectedPLUItemFromBaggingArea() throws OverloadException {
		assertEquals(stationController.getState(), StationState.ADDING);
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.baggingArea.add(item5);
		baggingAreaController.setCurrentExpectedWeight(weightBunch6);
		baggingAreaController.setStatus(BAProcessing.PLU);
		scs.baggingArea.remove(item5);
		assertEquals(stationController.getState(), StationState.SUSPEND);
		assertTrue(isSystemSuspended());
	}

	@Test
	public void testRemoveUnclassifiedItemFromBaggingArea() throws OverloadException {
		// This should never happen based on current design
		assertEquals(stationController.getState(), StationState.ADDING);
		class UnclassifiedItem extends Item {
			protected UnclassifiedItem(double weightInGrams) {
				super(weightInGrams);
			}
		}

		double weight = 15;
		Item UnclassifiedItem = new UnclassifiedItem(weight);
		scs.baggingArea.add(UnclassifiedItem);
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PENDING);
		cart.removeProduct(UnclassifiedItem);
	}

	@Test
	public void testLightProductPlacedInBaggingArea() {
		Item item4 = new BarcodedItem(barcodeItem4, weightItem4);
		while (cart.getScannedItemList().get(barcodeItem4) == null) {
			scs.mainScanner.scan(item4);
		}
		scs.baggingArea.add(item4);
	}

	@Test
	public void testOverload() {
		for (int i = 0; i < 12; i++) {
			Item item3 = new BarcodedItem(barcodeItem3, weightItem3);
			while (cart.getScannedItemList().get(barcodeItem3) == null
					|| cart.getScannedItemList().get(barcodeItem3) != i + 1) {
				scs.mainScanner.scan(item3);
			}
			scs.baggingArea.add(item3);
		}

		assertTrue(isSystemSuspended());
	}

	@Test
	public void testOutOfOverload() throws OverloadException {
		Item item3 = new BarcodedItem(barcodeItem3, weightItem3);
		while (cart.getScannedItemList().get(barcodeItem3) == null) {
			scs.mainScanner.scan(item3);
		}
		scs.baggingArea.add(item3);

		for (int i = 0; i < 11; i++) {
			item3 = new BarcodedItem(barcodeItem3, weightItem3);
			while (cart.getScannedItemList().get(barcodeItem3) == null
					|| cart.getScannedItemList().get(barcodeItem3) != i + 2) {
				scs.mainScanner.scan(item3);
			}
			scs.baggingArea.add(item3);
		}

		assertTrue(isSystemSuspended());
		cart.removeProduct(item3);
		assertTrue(isAddingEnabled());
	}
	
	@Test
	public void testNoObserverAttached() {
		Set<ControllerObserver> controllerObservers = cart.getControllerObservers();
		for (ControllerObserver observer : controllerObservers) {
			if (observer instanceof ScanBarcodeObserver) {
				scanBarcodeController.deattach((ScanBarcodeObserver) observer);
			}
		}
		Item item = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item);
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PENDING);
	}

	private boolean isSystemSuspended() {
		return scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled() && scs.scanningArea.isDisabled()
				&& scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && scs.printer.isDisabled();
	}

	private boolean isAddingEnabled() {
		return !scs.mainScanner.isDisabled() && !scs.handheldScanner.isDisabled() && !scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && !scs.printer.isDisabled();
	}

	private boolean isBaggingEnabled() {
		return scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled() && scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && scs.printer.isDisabled();
	}
}
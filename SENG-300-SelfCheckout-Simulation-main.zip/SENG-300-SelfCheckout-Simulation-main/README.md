# SENG 300 Winter 2022 - Iteration 3

## Management team (max 1)
- Owen Fielder (I will also work to help anyone in any part of the project)
 
## Design/quality assurance team (writing the logic/tests) (max 12)
- Fu-Yin Lin (4)
- Maham Fatima (3)
- Jordana Wintjes (2)
- Emily Tam (3)
- Aleksandr Valianski (3)
- John Hutchinson (4)
- Arham Rahman (4)
- Jared Pon (2)
- Uijin Park
- Iftekhar Mahbub

## Frontend/GUI development team (max 3)
- Kevin Thai
- Edrick Lin
- Nadim Khoury

## Documentation team (making the diagrams) (max 2)
- Scott Peters
- Mellisa Phongsa
- Max Pagels

## Demonstration team (making the presentation) (max 2)
- Max Pagels

## To-do List: :heavy_check_mark: Done :x: Not Done :construction: WIP (logic done, test/gui not done)
- :heavy_check_mark: **Previous iteration errors**
	- :heavy_check_mark: Payments methods might not work with partial payment use case-- ***(Owen Fielder)***
	- :heavy_check_mark: Receive change has issue when returning multiple banknotes-- ***(Owen Fielder)***
	- :heavy_check_mark: Complete testing of iteration 2-- ***(Owen Fielder)***
- :heavy_check_mark: **Use Cases**
	1. ShoppingCart
		- :heavy_check_mark: Customer scans an item (Iteration 1)
		- :heavy_check_mark: Customer enters PLU code for a product-- ***(Fu-Yin Lin)***
		- :heavy_check_mark: Customer looks up product-- ***(Fu-Yin Lin)***
		- :heavy_check_mark: Customer enters number of plastic bags used-- ***(Fu-Yin Lin)***
		- :heavy_check_mark: Customer adds their own bag to the bagging area (Iteration 2)
		- :heavy_check_mark: Customer places item in bagging area (Iteration 1)
		- :heavy_check_mark: Customer fails to place item in bagging area (Iteration 2)
		- :heavy_check_mark: Station detects that the weight in the bagging area does not conform to expectations-- ***(Fu-Yin Lin)***
		- :heavy_check_mark: Customer does not want to bag a scanned item-- ***(Emily Tam)***
		- :heavy_check_mark:  Customer returns to adding items-- ***(Maham Fatima)***
		- :heavy_check_mark: Customer adds additional items after partial payment (Iteration 2)
		- :heavy_check_mark: Customer removes purchased items from bagging area-- ***(Aleksandr Valianski)***
	2. Checkout
		- :heavy_check_mark: Customer wishes to checkout (Iteration 1)
		- :heavy_check_mark: Customer pays with a coin (Iteration 1)
		- :heavy_check_mark: Customer pays with a banknote (Iteration 1)
		- :heavy_check_mark: Customer receives change (Iteration 2)
		- :heavy_check_mark: Customer pays with a debit card (Iteration 2)
		- :heavy_check_mark: Customer pays with a credit card (Iteration 2)
		- :heavy_check_mark: Customer pays with gift card-- ***(Emily Tam)***
		- :heavy_check_mark: Customer scans their membership card (Iteration 2)
		- :heavy_check_mark: Customer enters their membership card information-- ***(Emily Tam)***
		- :heavy_check_mark: Station detects that the paper in a receipt printer is low-- ***(Aleksandr Valianski)***
		- :heavy_check_mark: Station detects that the ink in a receipt printer is low-- ***(Aleksandr Valianski)***
	3. Supervision
		- :heavy_check_mark: Attendant approves a weight discrepancy-- ***(John Hutchinson)***
		- :heavy_check_mark: Attendant removes product from purchases-- ***(John Hutchinson)***
		- :heavy_check_mark:  Attendant blocks a station-- ***(Maham Fatima)***
		- :heavy_check_mark:  Attendant looks up a product-- ***(Maham Fatima)***
		- :heavy_check_mark: Attendant logs in to their control console-- ***(Arham Rahman)***
		- :heavy_check_mark: Attendant logs out from their control console-- ***(Arham Rahman)***
		- :heavy_check_mark: Attendant starts up a station-- ***(Arham Rahman)***
		- :heavy_check_mark: Attendant shuts down a station-- ***(Arham Rahman)***
		- :heavy_check_mark: Attendant adds paper to receipt printer-- ***(John Hutchinson)***
		- :heavy_check_mark: Attendant adds ink to receipt printer-- ***(John Hutchinson)***
		- :heavy_check_mark: Attendant empties the coin storage unit-- ***(Jordana Wintjes)***
		- :heavy_check_mark: Attendant empties the banknote storage unit-- ***(Jordana Wintjes)***
		- :heavy_check_mark: Attendant refills the coin dispenser-- ***(Jared Pon)***
		- :heavy_check_mark: Attendant refills the banknote dispenser-- ***(Jared Pon)***

- :heavy_check_mark: **Graphical User Interface(s)**-- ***(Kevin Thai, Edrick Lin, Nadim Khoury)***

- :heavy_check_mark: **Diagrams**
	- :heavy_check_mark: Structural Diagrams
	- :heavy_check_mark: Sequence/Communication Diagrams
	- :heavy_check_mark: State Diagrams 

- :heavy_check_mark: **Video** ***(Max Pagels)***
	- [Presentation](https://youtu.be/H5dO8KX4pdg)

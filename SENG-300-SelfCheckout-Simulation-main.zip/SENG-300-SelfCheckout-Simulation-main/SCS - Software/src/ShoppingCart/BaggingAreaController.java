package ShoppingCart;

import java.util.HashSet;
import java.util.Set;

import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.ElectronicScale;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.ElectronicScaleObserver;

import Station.StationController;
import Station.StationState;

public class BaggingAreaController {
	private SelfCheckoutStation scs;
	private StationController stationController;
	private ScanBarcodeController barcodeScanController;
	private EnterPLUCodeController pluCodeEntryController;
	private final Set<BaggingAreaObserver> controllerObservers = new HashSet<>();

	private double lastScaleWeightInGrams = 0.0;
	private double currentExpectedWeight = 0.0;
	private double totalWeightInBaggingArea = 0.0;

	private BAProcessing BAstatus = BAProcessing.PENDING;

	public class BAESO implements ElectronicScaleObserver {

		@Override
		public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void weightChanged(ElectronicScale scale, double weightInGrams) {
			double weightOfCurrentChange = weightInGrams - lastScaleWeightInGrams;
			if (stationController.getState() == StationState.PAID) {
				if (weightInGrams <= scale.getSensitivity()) {
					// removed purchased item from bagging area
					stationController.setState(StationState.ADDING);
				} else {
					// something went wrong with the scale - should not happen
				}
			}

			if (weightOfCurrentChange > scale.getSensitivity()) {
				// Add items to bagging area
				switch (BAstatus) {
				case REUSABLEBAGS:
					lastScaleWeightInGrams += weightOfCurrentChange;
					stationController.setState(StationState.SUSPEND);
					notifyWeightDiscrepancy();
					BAstatus = BAProcessing.PENDING;
					// The attendant will verify that all they have placed there is the bag(s) and
					// then approve the action at their own station, permitting the client to
					// continue with scanning or payment.
					break;
				case PLASTICBAGS:
					if (weightOfCurrentChange <= currentExpectedWeight) {
						// expected weight of item is placed in bagging area
						totalWeightInBaggingArea = weightInGrams;
						lastScaleWeightInGrams += weightOfCurrentChange;
						stationController.setState(StationState.ADDING);
					} else {
						// exceed plastic bags limit
						stationController.setState(StationState.SUSPEND);
						notifyWeightDiscrepancy();
						// notify attendant to verify that the discrepancy is an error, that the wrong
						// item(s) are present (and thus, to correct the record by adding/removing as
						// needed), or any other action needed.
					}
					BAstatus = BAProcessing.PENDING;
					break;
				case BARCODE:
//					resetTimer
					currentExpectedWeight = barcodeScanController.getLastScannedBarcodedProductWeight();
					if (Math.abs(weightOfCurrentChange - currentExpectedWeight) <= scale.getSensitivity()) {
						// expected weight of item is placed in bagging area
						totalWeightInBaggingArea = weightInGrams;
						lastScaleWeightInGrams += weightOfCurrentChange;
						stationController.setState(StationState.ADDING);
					} else {
						// wrong item placed in bagging area
						stationController.setState(StationState.SUSPEND);
						notifyWeightDiscrepancy();
					}
					BAstatus = BAProcessing.PENDING;
					break;
				case PLU:
//					resetTimer
					currentExpectedWeight = pluCodeEntryController.getLastEnteredPLUProductWeight();
					if (Math.abs(weightOfCurrentChange - currentExpectedWeight) <= scale.getSensitivity()) {
						// expected weight of item is placed in bagging area
						totalWeightInBaggingArea = weightInGrams;
						lastScaleWeightInGrams += weightOfCurrentChange;
						stationController.setState(StationState.ADDING);
					} else {
						// wrong item placed in bagging area
						stationController.setState(StationState.SUSPEND);
						notifyWeightDiscrepancy();
					}
					BAstatus = BAProcessing.PENDING;
					break;
				case OVERLOAD:
				case OUTOFOVERLOAD:
					BAstatus = BAProcessing.PENDING;
					break;
				default:
					stationController.setState(StationState.SUSPEND);
					notifyWeightDiscrepancy();
					// system is not expecting any item to be place in bagging area yet
					// should print on screen to tell customer to remove those unknown item(s) from
					// bagging area
					break;
				}
			} else {
				// Removing item from bagging area
				switch (BAstatus) {
				case BARCODE:
				case PLU:
					if (Math.abs(-weightOfCurrentChange - currentExpectedWeight) <= scale.getSensitivity()) {
						// expected weight of item removed bagging area
						totalWeightInBaggingArea = weightInGrams;
						lastScaleWeightInGrams -= weightOfCurrentChange;
						stationController.setState(StationState.ADDING);
					} else {
						// unexpected item(s) removed from bagging area
						stationController.setState(StationState.SUSPEND);
						notifyWeightDiscrepancy();
					}
					BAstatus = BAProcessing.PENDING;
					break;
				case OVERLOAD:
				case OUTOFOVERLOAD:
					BAstatus = BAProcessing.PENDING;
					break;
				case PAID:
					break;
				default:
					stationController.setState(StationState.SUSPEND);
					// attendant should investigate what gets removed and adjust/approve accordingly
					break;
				}
			}
		}

		@Override
		public void overload(ElectronicScale scale) {
			stationController.setState(StationState.SUSPEND);
			BAstatus = BAProcessing.OVERLOAD;
			notifyOverload();
		}

		@Override
		public void outOfOverload(ElectronicScale scale) {
			stationController.setState(StationState.ADDING);
			BAstatus = BAProcessing.OUTOFOVERLOAD;
		}
	}

	public BaggingAreaController(StationController stationController) {
		this.scs = stationController.getStation();
		this.stationController = stationController;
	}

	public void attach(BaggingAreaObserver observer) {
		controllerObservers.add(observer);
	}

	public void deattach(BaggingAreaObserver observer) {
		controllerObservers.remove(observer);
	}

	public void setBarcodeScanController(ScanBarcodeController barcodeScanController) {
		this.barcodeScanController = barcodeScanController;
	}

	public void setPluCodeEntryController(EnterPLUCodeController pluCodeEntryController) {
		this.pluCodeEntryController = pluCodeEntryController;
	}

	public void setStatus(BAProcessing status) {
		this.BAstatus = status;
	}

	public void setCurrentExpectedWeight(double currentExpectedWeight) {
		this.currentExpectedWeight = currentExpectedWeight;
	}

	public BAProcessing getStatus() {
		return BAstatus;
	}

	public double getTotalWeightInBaggingArea() {
		return totalWeightInBaggingArea;
	}

	public double getLastScaleWeightInGrams() {
		return lastScaleWeightInGrams;
	}

	public double getCurrentExpectedWeight() {
		return currentExpectedWeight;
	}

	private void notifyWeightDiscrepancy() {
		for (BaggingAreaObserver l : controllerObservers)
			l.baggingAreaWeightDiscrepancy(this);
	}

	private void notifyOverload() {
		for (BaggingAreaObserver l : controllerObservers)
			l.baggingAreaOverload(this);
	}
}

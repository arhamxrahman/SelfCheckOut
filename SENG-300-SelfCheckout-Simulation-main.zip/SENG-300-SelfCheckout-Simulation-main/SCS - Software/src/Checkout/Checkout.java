package Checkout;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.EmptyException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

import ShoppingCart.BAProcessing;
import ShoppingCart.ShoppingCart;
import Station.ControllerObserver;
import Station.StationController;
import Station.StationState;

public class Checkout {
	private SelfCheckoutStation scs;
	private StationController stationController;
	private ShoppingCart cart;
	private CashPaymentController cashPaymentController;
	private CardPaymentController cardPaymentController;
	private MembershipController membershipController;
	private BigDecimal totalCosts; // value of cart
	private BigDecimal totalPayments = new BigDecimal(0.0);
	private Set<ControllerObserver> controllerObservers = new HashSet<>();
	private boolean paidInFull = false;
	private PaymentMethod paymentMethod;
	private Set<CheckoutObserver> checkoutObservers = new HashSet<>();

	private class CashPO implements CashPaymentObserver {
		@Override
		public void paidWithCash(CashPaymentController cashPaymentController, BigDecimal moneyInserted) {
			totalPayments = totalPayments.add(moneyInserted);
			if (isPaidInFull()) {
				CashChangeController ccc = new CashChangeController(totalPayments.subtract(totalCosts), scs);
				try {
					ccc.giveChange();
				} catch (EmptyException e) {
					stationController.setState(StationState.SUSPEND);
					notifyEmptyDispensers();
					// call attendant to refill coin/banknote dispenser
				} catch (DisabledException e) {
					stationController.setState(StationState.SUSPEND);
					// This should not happen
				} catch (OverloadException e) {
					// This should never be reached
				}
				printReceipt();
			} else {
				// continue shopping or start another payment transaction
			}
			paymentMethod = PaymentMethod.PENDING;
		}
	}

	private class CardPO implements CardPaymentObserver {
		@Override
		public void successfulCardTransaction(CardPaymentController cardPaymentController, BigDecimal amountPaid) {
			totalPayments = totalPayments.add(amountPaid);
			if (isPaidInFull()) {
				printReceipt();
			} else {
				// continue shopping or start another payment transaction
			}
			paymentMethod = PaymentMethod.PENDING;
		}

		@Override
		public void failedCardTransaction(CardPaymentController cardPaymentController) {
			stationController.setState(StationState.ADDING);
			paymentMethod = PaymentMethod.PENDING;
			notifyTransactionFailed();
		}
	}

	public Checkout(StationController stationController, ShoppingCart cart, CashPaymentController cashPaymentController,
			CardPaymentController cardPaymentController, MembershipController membershipController) {
		this.scs = stationController.getStation();
		this.stationController = stationController;
		this.cart = cart;
		this.cashPaymentController = cashPaymentController;
		CashPO cashObserver = new CashPO();
		cashPaymentController.attach(cashObserver);
		controllerObservers.add(cashObserver);

		this.cardPaymentController = cardPaymentController;
		CardPO cardObserver = new CardPO();
		cardPaymentController.attach(cardObserver);
		controllerObservers.add(cardObserver);

		this.membershipController = membershipController;
	}

	// GUI button on touch screen - press by customer to initiate checkout process
	public void startCheckout() {
		stationController.setState(StationState.PAYING);
	}

	// GUI button on touch screen - select by customer
	public void selectPaymentMethod(PaymentMethod paymentMethod) {
		this.paymentMethod = paymentMethod;
		totalCosts = cart.calculateTotalCosts();
		switch (paymentMethod) {
		case CASH:
			enableCashPayment();
			break;
		case DEBIT:
		case CREDIT:
		case GIFT:
			enableCardPayment();
			break;
		default:
			break;
		}
	}

	// GUI textfield with amount to pay - enter by customer
	public void setAmountToPay(BigDecimal amountToPay) {
		switch (paymentMethod) {
		case DEBIT:
		case CREDIT:
		case GIFT:
			cardPaymentController.setAmountToPay(amountToPay);
			break;
		default:
			break;
		}
	}

	public boolean isPaidInFull() {
		switch (paymentMethod) {
		case CASH:
			Collections.sort(scs.coinDenominations);
			if (totalCosts.compareTo(totalPayments.add(scs.coinDenominations.get(0))) < 0) {
				paidInFull = true;
				stationController.setState(StationState.PAID);
				cart.getBaggingAreaController().setStatus(BAProcessing.PAID);
				notifyPaidInFull();
			} else {
				paidInFull = false;
				stationController.setState(StationState.ADDING);
				// continue waiting for payments or return to shopping
			}
			break;
		case DEBIT:
		case CREDIT:
		case GIFT:
			if (totalCosts.setScale(2, RoundingMode.HALF_DOWN)
					.compareTo(totalPayments.setScale(2, RoundingMode.HALF_DOWN)) == 0) {
				paidInFull = true;
				stationController.setState(StationState.PAID);
				cart.getBaggingAreaController().setStatus(BAProcessing.PAID);
				notifyPaidInFull();
			} else {
				paidInFull = false;
				stationController.setState(StationState.ADDING);
				// continue waiting for payments or return to shopping
			}
			break;
		default:
			break;
		}
		return paidInFull;
	}

	public void returnToShopping() {
		stationController.setState(StationState.ADDING);
	}

	public void printReceipt() {
		String membership = membershipController.getMembershipNumber();
		ReceiptController receipt = new ReceiptController(scs, cart, this, membership);
		receipt.printReceipt();
	}
	
	public void resetPayments() {
		totalPayments = new BigDecimal(0.0);
	}

	public BigDecimal getTotalCosts() {
		return totalCosts;
	}

	public BigDecimal getTotalPayments() {
		return totalPayments;
	}

	public PaymentMethod getPaymentMethod() {
		return paymentMethod;
	}

	public Set<ControllerObserver> getAttachedObservers() {
		return controllerObservers;
	}

	public void attach(CheckoutObserver observer) {
		checkoutObservers.add(observer);
	}

	public void deattach(CheckoutObserver observer) {
		checkoutObservers.remove(observer);
	}

	public CashPaymentController getCashPaymentController() {
		return cashPaymentController;
	}

	public CardPaymentController getCardPaymentController() {
		return cardPaymentController;
	}

	public MembershipController getMembershipController() {
		return membershipController;
	}

	private void enableCashPayment() {
		scs.coinSlot.enable();
		scs.banknoteInput.enable();
		scs.cardReader.disable();
	}

	private void enableCardPayment() {
		scs.cardReader.enable();
		scs.coinSlot.disable();
		scs.banknoteInput.disable();
	}

	private void notifyTransactionFailed() {
		for (CheckoutObserver l : checkoutObservers)
			l.transactionFailed(this);
	}

	private void notifyEmptyDispensers() {
		for (CheckoutObserver l : checkoutObservers)
			l.emptyDispensers(this);
	}

	private void notifyPaidInFull() {
		for (CheckoutObserver l : checkoutObservers)
			l.paidInFull(this);
	}
}

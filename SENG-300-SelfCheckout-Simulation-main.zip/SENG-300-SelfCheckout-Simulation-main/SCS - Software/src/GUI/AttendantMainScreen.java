package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Station.StationController;

public class AttendantMainScreen {
	App app;
	JFrame loginFrame;

	JFrame attendantMainFrame;
	JPanel attendantMainPanel;

	JButton attendentCalled;
	JButton logout;

	public AttendantMainScreen(JFrame loginFrame, App app) {
		this.loginFrame = loginFrame;
		this.app = app;

		attendantMainFrame = new JFrame("Attendent Main Screen");
		attendantMainPanel = new JPanel();
		attendantMainPanel.setLayout(new GridBagLayout());

		addWidgets();

		attendantMainFrame.getContentPane().add(attendantMainPanel, BorderLayout.CENTER);
		attendantMainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		attendantMainFrame.setSize(400, 500);
		attendantMainFrame.setVisible(true);
	}

	private void addWidgets() {
		logout = new JButton("Logout");
		logout.setBackground(Color.RED);
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				app.getAttendantIntervention().logout();
				loginFrame.setVisible(true);
				attendantMainFrame.dispose();
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 1;
		attendantMainPanel.add(logout, gbc);

		ArrayList<StationController> stationControllerList = app.getAttendantIntervention().getStationControllers();

		for (int i = 0; i < stationControllerList.size(); i++) {
			JButton stationBtn = new JButton("Station #" + i);
			int stationIndex = i;
			stationBtn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					AttendantStationScreen stationScreen = new AttendantStationScreen(attendantMainFrame, app,
							stationIndex);
					stationScreen.stationFrame.setVisible(true);
					attendantMainFrame.setVisible(false);
				}
			});

			gbc.gridx = 0;
			gbc.gridy = stationIndex + 1;
			attendantMainPanel.add(stationBtn, gbc);
		}
	}
}
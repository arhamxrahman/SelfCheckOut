package GUI;

import java.math.BigDecimal;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.Card;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PriceLookupCode;

import Station.StationController;

public class Session {
	App app;
	StationController stationController;
	Item currentItemChoice;
	Card currentCardForPayment;
	String cardPIN;
	Barcode lastScannedBarcode;
	PriceLookupCode lastEnteredPLU;
	double lastScanningAreaWeight;
	double lastBaggingAreaWeight;
	BigDecimal totalPayments = new BigDecimal(0.0);
	String membership = null;
	String membershipEntryChoice = "manual";
	int StationIndex;

	public App getApp() {
		return app;
	}

	public void setApp(App app) {
		this.app = app;
	}

	public int getStationIndex() {
		return StationIndex;
	}

	public void setStationIndex(int stationIndex) {
		StationIndex = stationIndex;
	}

	public StationController getStationController() {
		return stationController;
	}

	public void setStationController(StationController stationController) {
		this.stationController = stationController;
	}

	public Item getCurrentItemChoice() {
		return currentItemChoice;
	}

	public void setCurrentItemChoice(Item currentItemChoice) {
		this.currentItemChoice = currentItemChoice;
	}

	public Card getCurrentCardForPayment() {
		return currentCardForPayment;
	}

	public void setCurrentCardForPayment(Card currentCardForPayment) {
		this.currentCardForPayment = currentCardForPayment;
	}

	public String getCardPIN() {
		return cardPIN;
	}

	public void setCardPIN(String cardPIN) {
		this.cardPIN = cardPIN;
	}

	public Barcode getLastScannedBarcode() {
		return lastScannedBarcode;
	}

	public void setLastScannedBarcode(Barcode lastScannedBarcode) {
		this.lastScannedBarcode = lastScannedBarcode;
	}

	public PriceLookupCode getLastEnteredPLU() {
		return lastEnteredPLU;
	}

	public void setLastEnteredPLU(PriceLookupCode lastEnteredPLU) {
		this.lastEnteredPLU = lastEnteredPLU;
	}

	public double getLastScanningAreaWeight() {
		return lastScanningAreaWeight;
	}

	public void setLastScanningAreaWeight(double lastScanningAreaWeight) {
		this.lastScanningAreaWeight = lastScanningAreaWeight;
	}

	public double getLastBaggingAreaWeight() {
		return lastBaggingAreaWeight;
	}

	public void setLastBaggingAreaWeight(double lastBaggingAreaWeight) {
		this.lastBaggingAreaWeight = lastBaggingAreaWeight;
	}

	public BigDecimal getTotalPayments() {
		return totalPayments;
	}

	public void setTotalPayments(BigDecimal totalPayments) {
		this.totalPayments = totalPayments;
	}

	public String getMembership() {
		return membership;
	}

	public void setMembership(String membership) {
		this.membership = membership;
	}

	public String getMembershipEntryChoice() {
		return membershipEntryChoice;
	}

	public void setMembershipEntryChoice(String membershipEntryChoice) {
		this.membershipEntryChoice = membershipEntryChoice;
	}
}

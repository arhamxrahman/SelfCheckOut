package Checkout;

public interface CheckoutObserver {
	public void transactionFailed(Checkout checkout);

	public void paidInFull(Checkout checkout);

	public void emptyDispensers(Checkout checkout);
}

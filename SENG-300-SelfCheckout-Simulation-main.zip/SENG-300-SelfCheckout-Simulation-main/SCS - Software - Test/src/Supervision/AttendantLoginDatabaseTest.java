package Supervision;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class AttendantLoginDatabaseTest {
	private AttendantLoginDatabase database;

	@Before
	public void setup() {
		database = new AttendantLoginDatabase();
	}

	@Test
	public void testAddNewLogin() {
		String employeeID = "0000";
		String employeePassword = "1234";
		database.addNewAttendantLogin(employeeID, employeePassword);
	}

	@Test
	public void testAddDuplicateLogin() {
		String employeeID = "0000";
		String employeePassword = "1234";
		database.addNewAttendantLogin(employeeID, employeePassword);
		database.addNewAttendantLogin(employeeID, employeePassword);
	}

	@Test
	public void testRemoveLogin() {
		String employeeID = "0000";
		String employeePassword = "1234";
		database.addNewAttendantLogin(employeeID, employeePassword);
		database.removeAttendantLogin(employeeID);
	}

	@Test
	public void testRemoveNullLogin() {
		String employeeID = "0000";
		database.removeAttendantLogin(employeeID);
	}

	@Test
	public void testRemoveUnknownLoginID() {
		String employeeID = "0000";
		String employeePassword = "1234";
		String wrongEmployeeID = "1111";
		database.addNewAttendantLogin(employeeID, employeePassword);
		database.removeAttendantLogin(wrongEmployeeID);
	}

	@Test
	public void testValidLogin() {
		String employeeID = "0000";
		String employeePassword = "1234";
		database.addNewAttendantLogin(employeeID, employeePassword);
		assertTrue(database.loginValid(employeeID, employeePassword));
	}

	@Test
	public void testInvalidLoginPassword() {
		String employeeID = "0000";
		String employeePassword = "1234";
		String wrongEmployeePassword = "4321";
		database.addNewAttendantLogin(employeeID, employeePassword);
		assertFalse(database.loginValid(employeeID, wrongEmployeePassword));
	}

	@Test
	public void testInvalidLoginID() {
		String employeeID = "0000";
		String employeePassword = "1234";
		String wrongEmployeeID = "1111";
		database.addNewAttendantLogin(employeeID, employeePassword);
		assertFalse(database.loginValid(wrongEmployeeID, employeePassword));
	}
}

package Supervision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.SimulationException;
import org.lsmr.selfcheckout.devices.BanknoteDispenser;
import org.lsmr.selfcheckout.devices.CoinDispenser;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.SupervisionStation;

import Checkout.CardPaymentController;
import Checkout.CashPaymentController;
import Checkout.MembershipController;
import ShoppingCart.BaggingAreaController;
import ShoppingCart.ScanBarcodeController;
import Station.StationController;
import Station.StationState;

public class AttendantIntervention {
	private SupervisionStation attendantStation;
	private List<SelfCheckoutStation> supervisedStations;
	private ArrayList<StationController> stationControllers = new ArrayList<>();
	private ArrayList<AttendantObserver> attendantObservers = new ArrayList<>();
	private AttendantLoginDatabase loginDatabase;

	private boolean isAuthenticated = false;
	private String employeeID;

	public AttendantIntervention(SupervisionStation attendantStation, AttendantLoginDatabase loginDatabase) {
		this.attendantStation = attendantStation;
		this.supervisedStations = attendantStation.supervisedStations();
		this.loginDatabase = loginDatabase;
		isAuthenticated = false;
		employeeID = null;
		for (SelfCheckoutStation station : supervisedStations) {
			StationController controller = new StationController(station);
			stationControllers.add(controller);
		}
	}

	public void attach(AttendantObserver observer) {
		attendantObservers.add(observer);
	}

	public void deattach(AttendantObserver observer) {
		attendantObservers.remove(observer);
	}

	public boolean isAuthenticated() {
		return isAuthenticated;
	}

	public ArrayList<StationController> getStationControllers() {
		return stationControllers;
	}

	public boolean login(String employeeID, String employeePassword) {
		isAuthenticated = loginDatabase.loginValid(employeeID, employeePassword);
		if (isAuthenticated) {
			this.employeeID = employeeID;
			return true;
		}
		return false;
	}

	public void logout() {
		if (isAuthenticated) {
			this.employeeID = null;
			isAuthenticated = false;
		}
	}

	/*
	 * Returns true if successfully starts up the desired station
	 */
	public boolean startUpStation(int stationIndex) {
		if (isAuthenticated) {
			StationController controller = stationControllers.get(stationIndex);
			SelfCheckoutStation scs = controller.getStation();
			ScanBarcodeController s = controller.getShoppingCart().getScanBarcodeController();
			scs.mainScanner.attach(s.new BSO());
			scs.handheldScanner.attach(s.new BSO());
			BaggingAreaController b = controller.getShoppingCart().getBaggingAreaController();
			scs.baggingArea.attach(b.new BAESO());
			CashPaymentController ch = controller.getCheckout().getCashPaymentController();
			scs.coinValidator.attach(ch.new CVO());
			scs.banknoteValidator.attach(ch.new BVO());
			CardPaymentController cd = controller.getCheckout().getCardPaymentController();
			scs.cardReader.attach(cd.new CRO());
			MembershipController m = controller.getCheckout().getMembershipController();
			scs.cardReader.attach(m.new CRO());
			return true;
		}
		return false;
	}

	/*
	 * Returns true if successfully shuts down the desired station
	 */
	public boolean shutDownStation(int stationIndex) {
		if (isAuthenticated) {
			StationController controller = stationControllers.get(stationIndex);
			SelfCheckoutStation scs = controller.getStation();
			controller.restartSession();
			scs.mainScanner.detachAll();
			scs.handheldScanner.detachAll();
			scs.scanningArea.detachAll();
			scs.baggingArea.detachAll();
			scs.coinValidator.detachAll();
			scs.banknoteValidator.detachAll();
			scs.cardReader.detachAll();
			return true;
		}
		return false;
	}

	/*
	 * Returns true if the attendant approves of a weight difference seen
	 */
	public boolean approvedWeightDiscrepancy(int stationIndex) {
		if (isAuthenticated) {
			StationController controller = stationControllers.get(stationIndex);
			controller.setState(StationState.ADDING);
			notifyStationUnBlocked();
			return true;
		}
		return false;
	}

	/*
	 * Prompts an attendant to remove a specific item Returns true if the attendant
	 * removed the item
	 */
	public boolean removeProduct(int stationIndex, Item itemToRemove) {
		if (isAuthenticated) {
			StationController controller = stationControllers.get(stationIndex);
			controller.getShoppingCart().removeProduct(itemToRemove);
			notifyItemRemoved();
			return true;
		}
		return false;
	}

	/*
	 * Attendant blocks a station Returns true if station is successfully blocked
	 */
	public boolean blocksStation(int stationIndex) {
		if (isAuthenticated) {
			StationController controller = stationControllers.get(stationIndex);
			controller.setState(StationState.SUSPEND);
			notifyStationBlocked();
			return true;
		}
		return false;
	}

	/*
	 * Prompts an attendant to add paper Returns true if the attendant added paper
	 */
	public boolean addsPaper(int stationIndex, int paperAdded) throws OverloadException {
		StationState state = stationControllers.get(stationIndex).getState();
		if (isAuthenticated && state.equals(StationState.SUSPEND)) {
			supervisedStations.get(stationIndex).printer.addPaper(paperAdded);
			notifyStationUnBlocked();
			return true;
		}
		return false;
	}

	/*
	 * Prompts an attendant to add ink to the receipt printer Returns true if the
	 * attendant added ink
	 */
	public boolean addsInk(int stationIndex, int inkAdded) throws OverloadException {
		StationState state = stationControllers.get(stationIndex).getState();
		if (isAuthenticated && state.equals(StationState.SUSPEND)) {
			supervisedStations.get(stationIndex).printer.addInk(inkAdded);
			notifyStationUnBlocked();
			return true;
		}
		return false;
	}

	/*
	 * Allows one to refill the coin dispenser (the use case) Arguments: - inp: A
	 * Map which associates each coin denomination with a list of the coins that
	 * should be loaded. If it is not the case that a denomination exists, then no
	 * coins are added to that denomination. Returns: - Void, but executes the side
	 * effect of load on the coin dispensers for which we wish to load coins on.
	 * 
	 * References: -
	 * https://d2l.ucalgary.ca/d2l/le/422926/discussions/threads/1640153/View
	 * includes discussion on what we should and shouldn't do. - CoinDispenser.java
	 * - SelfCheckoutStation.java
	 */
	public void refillCoinDispenser(int stationIndex, Map<BigDecimal, ArrayList<Coin>> inp)
			throws SimulationException, OverloadException {
		StationState state = stationControllers.get(stationIndex).getState();
		if (isAuthenticated && state.equals(StationState.SUSPEND)) {
			// Alias the coin dispensers so we don't have to refocus inside the coin
			// dispenser every time.
			Map<BigDecimal, CoinDispenser> coinDispensers = supervisedStations.get(stationIndex).coinDispensers;

			// for every single coin dispesner, we potentially load a coin (if it exists) to
			// it.
			for (BigDecimal key : coinDispensers.keySet())
				if (inp.containsKey(key))
					for (Coin c : inp.get(key))
						coinDispensers.get(key).load(c);
			notifyStationUnBlocked();
			return;
		}
	}

	// This is essentially identical to attendentRefillCoinDispenser as a
	// consequence of how the hardware was designed, except that
	// we replace coin dispenser with banknote dispenser.
	public void refillBanknoteDispenser(int stationIndex, Map<Integer, ArrayList<Banknote>> inp)
			throws SimulationException, OverloadException {
		StationState state = stationControllers.get(stationIndex).getState();
		if (isAuthenticated && state.equals(StationState.SUSPEND)) {
			// Alias the coin dispensers so we don't have to refocus inside the coin
			// dispenser every time.
			Map<Integer, BanknoteDispenser> banknoteDispensers = supervisedStations
					.get(stationIndex).banknoteDispensers;

			for (Integer key : banknoteDispensers.keySet())
				if (inp.containsKey(key))
					for (Banknote b : inp.get(key))
						banknoteDispensers.get(key).load(b);
			notifyStationUnBlocked();
			return;
		}
	}

	public void emptyCoinDispenser(int stationIndex, Set<BigDecimal> inp)
			throws SimulationException, OverloadException {
		StationState state = stationControllers.get(stationIndex).getState();
		if (isAuthenticated && state.equals(StationState.SUSPEND)) {
			Map<BigDecimal, CoinDispenser> coinDispensers = supervisedStations.get(stationIndex).coinDispensers;

			for (BigDecimal key : coinDispensers.keySet()) {
				if (inp.contains(key)) {
					coinDispensers.get(key).unload();
				}
			}

			notifyStationUnBlocked();
			return;
		}
	}

	public void emptyBanknoteDispenser(int stationIndex, Set<Integer> inp)
			throws SimulationException, OverloadException {
		StationState state = stationControllers.get(stationIndex).getState();
		if (isAuthenticated && state.equals(StationState.SUSPEND)) {
			Map<Integer, BanknoteDispenser> banknoteDispensers = supervisedStations
					.get(stationIndex).banknoteDispensers;

			for (Integer key : banknoteDispensers.keySet())
				if (inp.contains(key))
					banknoteDispensers.get(key).unload();
			notifyStationUnBlocked();
			return;
		}
	}

	private void notifyStationBlocked() {
		for (AttendantObserver l : attendantObservers)
			l.blockStation();
	}

	private void notifyStationUnBlocked() {
		for (AttendantObserver l : attendantObservers)
			l.unblockStation();
	}

	private void notifyItemRemoved() {
		for (AttendantObserver l : attendantObservers)
			l.removeItem();
	}
}

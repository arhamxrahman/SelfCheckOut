package Supervision;

import java.util.ArrayList;

public class AttendantLoginDatabase {

	private ArrayList<AttendantCredentials> allAttendantLogins;

	public AttendantLoginDatabase() {
		this.allAttendantLogins = new ArrayList<AttendantCredentials>();
	}

	public void addNewAttendantLogin(String employeeID, String employeePassword) {
		boolean idInDatabase = false;

		for (AttendantCredentials currentCredentials : allAttendantLogins) {
			if (employeeID.equals(currentCredentials.getID())) {
				idInDatabase = true;
			}
		}

		if (!idInDatabase) {

			allAttendantLogins.add(new AttendantCredentials(employeeID, employeePassword));
		}
	}

	public void removeAttendantLogin(String employeeID) {
		AttendantCredentials toRemove = null;

		for (AttendantCredentials currentCredentials : allAttendantLogins) {
			if (employeeID.equals(currentCredentials.getID())) {
				toRemove = currentCredentials;
			}
		}

		if (toRemove != null) {
			allAttendantLogins.remove(toRemove);
		}
	}

	public boolean loginValid(String employeeID, String employeePassword) {
		for (AttendantCredentials currentCredentials : allAttendantLogins) {
			if (employeeID.equals(currentCredentials.getID())) {
				if (currentCredentials.authenticateWithPassword(employeePassword)) {
					return true;
				}
			}
		}
		return false;
	}

	private class AttendantCredentials {
		private String employeeID;
		private String employeePassword;

		public AttendantCredentials(String employeeID, String employeePassword) {
			this.employeeID = employeeID;
			this.employeePassword = employeePassword;
		}

		public String getID() {
			return employeeID;
		}

		/*
		 * @Returns true if password is correct
		 */
		public boolean authenticateWithPassword(String potentialPassword) {
			if (employeePassword.equals(potentialPassword)) {
				return true;
			}
			return false;
		}
	}
}

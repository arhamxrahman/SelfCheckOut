package ShoppingCart;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.InvalidArgumentSimulationException;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.Numeral;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;
import Station.ControllerObserver;

public class ScanBarcodeControllerTest extends BaseTest {

	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test(expected = InvalidArgumentSimulationException.class)
	public void testScanUnknownBarcode() {
		Numeral[] nItem = { Numeral.zero, Numeral.zero, Numeral.zero, Numeral.zero };
		Barcode barcodeItem = new Barcode(nItem);
		Item item = new BarcodedItem(barcodeItem, 9.99);
		while (cart.getScannedItemList().get(barcodeItem) == null) {
			scs.mainScanner.scan(item);
		}
	}

	@Test
	public void testScanknownBarcode() {
		Item item = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item);
		}
		assertEquals(scanBarcodeController.getScannedItemList().get(barcodeItem1), 1, 0);
		assertTrue(isSystemBlockedAsDesired());
	}

	@Test
	public void testScanSameBarcodeItemMultipleTimes() {
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		scs.baggingArea.add(item1);
		Item item2 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) != 2) {
			scs.mainScanner.scan(item2);
		}
		scs.baggingArea.add(item2);
		Item item3 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) != 3) {
			scs.mainScanner.scan(item3);
		}
		scs.baggingArea.add(item3);
		assertEquals(scanBarcodeController.getScannedItemList().get(barcodeItem1), 3, 0);
	}

	@Test
	public void testNoObserverAttached() {
		Set<ControllerObserver> controllerObservers = cart.getControllerObservers();
		for (ControllerObserver observer : controllerObservers) {
			if (observer instanceof ScanBarcodeObserver) {
				scanBarcodeController.deattach((ScanBarcodeObserver) observer);
			}
		}
		Item item = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item);
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PENDING);
	}

	private boolean isSystemBlockedAsDesired() {
		return scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled() && scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && scs.printer.isDisabled();
	}
}
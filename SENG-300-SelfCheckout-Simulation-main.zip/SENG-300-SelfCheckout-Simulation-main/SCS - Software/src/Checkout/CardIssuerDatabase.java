package Checkout;

import java.util.HashMap;
import java.util.Map;

import org.lsmr.selfcheckout.external.CardIssuer;

public class CardIssuerDatabase {
	/**
	 * Instances of this class are not needed, so the constructor is private.
	 */
	private CardIssuerDatabase() {
	}

	/**
	 * The collaborated card issuers, indexed by issuer name.
	 */
	public static final Map<String, CardIssuer> CARD_ISSUER_DATABASE = new HashMap<>();

}

package BaseTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import Checkout.CardPaymentControllerTest;
import Checkout.CashChangeControllerTest;
import Checkout.CashPaymentControllerTest;
import Checkout.CheckoutTest;
import Checkout.MembershipControllerTest;
import Checkout.ReceiptControllerTest;
import Checkout.ReceiptPrinterTrackerTest;
import ShoppingCart.BaggingAreaControllerTest;
import ShoppingCart.EnterPLUCodeControllerTest;
import ShoppingCart.ScanBarcodeControllerTest;
import ShoppingCart.ShoppingCartTest;
import Station.StationControllerTest;
import Supervision.AttendantInterventionTest;
import Supervision.AttendantLoginDatabaseTest;
import Supervision.AttendantLooksUpProductTest;

@RunWith(Suite.class)
@SuiteClasses({ CardPaymentControllerTest.class, CashChangeControllerTest.class, CashPaymentControllerTest.class,
		CheckoutTest.class, MembershipControllerTest.class, ReceiptControllerTest.class,
		ReceiptPrinterTrackerTest.class, BaggingAreaControllerTest.class, EnterPLUCodeControllerTest.class,
		ScanBarcodeControllerTest.class, ShoppingCartTest.class, AttendantInterventionTest.class,
		AttendantLoginDatabaseTest.class, AttendantLooksUpProductTest.class, StationControllerTest.class
})

public class AllTests {

}

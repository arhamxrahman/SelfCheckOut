package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.external.ProductDatabases;

import Checkout.PaymentMethod;
import Station.StationController;

public class CheckoutScreen {
	StationController stationController;
	Session session;

	JFrame addingFrame;
	JFrame checkoutFrame;
	JPanel checkoutPanel;

	JTextArea currentItemsInCart;
	JLabel balanceLabel;

	JButton cashButton;
	JButton creditButton;
	JButton debitButton;
	JButton giftCardButton;
	JButton back;
	JButton refresh;

	public CheckoutScreen(JFrame addingItemsFrame, StationController stationController, Session session) {
		this.addingFrame = addingItemsFrame;
		this.stationController = stationController;
		this.session = session;

		checkoutFrame = new JFrame("Checkout...");
		checkoutPanel = new JPanel();
		checkoutPanel.setLayout(new GridBagLayout());

		addWidgets();

		checkoutFrame.getContentPane().add(checkoutPanel, BorderLayout.CENTER);
		checkoutFrame.setLocationRelativeTo(null);
		checkoutFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		checkoutFrame.setSize(600, 400);
		checkoutFrame.setVisible(true);
	}

	private void addWidgets() {
		BigDecimal cost = stationController.getShoppingCart().calculateTotalCosts();
		BigDecimal payment = stationController.getCheckout().getTotalPayments();
		BigDecimal balance = cost.subtract(payment);

		balanceLabel = new JLabel("<html>Total Cost: " + cost + "<br/>Total Payment: " + payment + "<br/>Amount Due: "
				+ balance + "</html>", SwingConstants.CENTER);
		balanceRefresh();

		cashButton = new JButton("Cash");
		cashButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getCheckout().selectPaymentMethod(PaymentMethod.CASH);
				CashPaymentScreen next = new CashPaymentScreen(checkoutFrame, stationController);
				next.cashPaymentGUI.setVisible(true);
			}
		});

		creditButton = new JButton("Credit");
		creditButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getCheckout().selectPaymentMethod(PaymentMethod.CREDIT);
				CardPaymentScreen next = new CardPaymentScreen(checkoutFrame, stationController, session);
				next.cardPaymentGUI.setVisible(true);
			}
		});

		debitButton = new JButton("Debit");
		debitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getCheckout().selectPaymentMethod(PaymentMethod.DEBIT);
				CardPaymentScreen next = new CardPaymentScreen(checkoutFrame, stationController, session);
				next.cardPaymentGUI.setVisible(true);
			}
		});

		giftCardButton = new JButton("Gift card");
		giftCardButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getCheckout().selectPaymentMethod(PaymentMethod.GIFT);
				CardPaymentScreen next = new CardPaymentScreen(checkoutFrame, stationController, session);
				next.cardPaymentGUI.setVisible(true);
			}
		});

		refresh = new JButton("Refresh");
		refresh.setBackground(Color.CYAN);
		refresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BigDecimal cost = stationController.getShoppingCart().calculateTotalCosts();
				BigDecimal payment = stationController.getCheckout().getTotalPayments();
				BigDecimal balance = cost.subtract(payment);

				balanceRefresh();

				if (balance.compareTo(new BigDecimal(0.05)) <= 0) {
					ThankYouScreen next = new ThankYouScreen(session);
					next.thanksFrame.setVisible(true);
					next.thanksFrame.setLocationRelativeTo(checkoutFrame);
					checkoutFrame.dispose();
					addingFrame.dispose();
					stationController.restartSession();
				}
			}
		});

		back = new JButton("Back");
		back.setBackground(Color.RED);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getCheckout().returnToShopping();
				BigDecimal cost = stationController.getShoppingCart().calculateTotalCosts();
				BigDecimal payment = stationController.getCheckout().getTotalPayments();
				BigDecimal balance = cost.subtract(payment);
				if (balance.compareTo(new BigDecimal(0.05)) <= 0) {
					back.setEnabled(false);
				} else {
					addingFrame.setVisible(true); // back to the adding page
					checkoutFrame.dispose();
				}
			}
		});

		currentItemsInCart = new JTextArea();
		currentItemsInCart.setEditable(false);

		cartListRefresh();

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridheight = 3;
		checkoutPanel.add(currentItemsInCart, gbc);

		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		checkoutPanel.add(balanceLabel, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.gridwidth = 2;
		gbc.gridheight = 1;
		checkoutPanel.add(cashButton, gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		checkoutPanel.add(creditButton, gbc);

		gbc.gridx = 2;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		checkoutPanel.add(debitButton, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridwidth = 2;
		gbc.gridheight = 1;
		checkoutPanel.add(giftCardButton, gbc);

		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		checkoutPanel.add(back, gbc);

		gbc.gridx = 2;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		checkoutPanel.add(refresh, gbc);
	}

	private void cartListRefresh() {
		StringBuilder str = new StringBuilder();

		Map<Barcode, Integer> scannedItemList = stationController.getShoppingCart().getScannedItemList();
		Map<PriceLookupCode, Double> enteredItemList = stationController.getShoppingCart().getEnteredItemList();

		if (session.getMembership() != null) {
			str.append("Welcome #");
			str.append(session.getMembership());
		}

		for (Barcode barcode : scannedItemList.keySet()) {
			String description = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getDescription();
			int quantity = scannedItemList.get(barcode);
			BigDecimal price = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getPrice().setScale(2,
					RoundingMode.HALF_DOWN);
			str.append(barcode);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(quantity);
			str.append(" @ $");
			str.append(price);
			str.append("				");
			str.append(price.multiply(new BigDecimal(quantity)));
			str.append('\n');
		}

		for (PriceLookupCode plu : enteredItemList.keySet()) {
			String description = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getDescription();
			BigDecimal weight = new BigDecimal(enteredItemList.get(plu) / 1000).setScale(3, RoundingMode.HALF_DOWN);
			;
			BigDecimal price = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice().multiply(new BigDecimal(1000))
					.setScale(2, RoundingMode.HALF_DOWN);
			BigDecimal cost = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice()
					.multiply(new BigDecimal(enteredItemList.get(plu))).setScale(2, RoundingMode.HALF_DOWN);
			str.append(plu);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(weight);
			str.append(" kg @ $");
			str.append(price);
			str.append("/kg			");
			str.append(cost);
			str.append('\n');
		}

		int numOfBags = stationController.getShoppingCart().getNumOfBags();
		BigDecimal pricePerBag = stationController.getShoppingCart().getPricePerBag();
		if (numOfBags > 0) {
			BigDecimal cost = pricePerBag.multiply(new BigDecimal(numOfBags)).setScale(2, RoundingMode.HALF_DOWN);
			str.append("Plastic Bag");
			str.append('\n');
			str.append(numOfBags);
			str.append(" @ $");
			str.append(pricePerBag.setScale(2, RoundingMode.HALF_DOWN));
			str.append("				");
			str.append(cost);
			str.append('\n');
		}
		currentItemsInCart.setText(str.toString());
	}

	private void balanceRefresh() {
		BigDecimal cost = stationController.getShoppingCart().calculateTotalCosts();
		BigDecimal payment = stationController.getCheckout().getTotalPayments().setScale(2, RoundingMode.HALF_DOWN);
		BigDecimal balance = cost.subtract(payment).setScale(2, RoundingMode.HALF_DOWN);

		balanceLabel.setText("<html>Total Cost: " + cost + "<br/>Total Payment: " + payment + "<br/>Amount Due: "
				+ balance + "</html>");
	}
}

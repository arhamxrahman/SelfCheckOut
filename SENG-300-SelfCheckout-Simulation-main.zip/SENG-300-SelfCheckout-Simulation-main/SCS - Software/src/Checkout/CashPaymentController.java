package Checkout;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashSet;
import java.util.Set;

import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.BanknoteValidator;
import org.lsmr.selfcheckout.devices.CoinValidator;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.BanknoteValidatorObserver;
import org.lsmr.selfcheckout.devices.observers.CoinValidatorObserver;

import Station.StationController;

public class CashPaymentController {
	private BigDecimal moneyInserted = new BigDecimal(0.0);
	private final Set<CashPaymentObserver> controllerObservers = new HashSet<>();

	public class CVO implements CoinValidatorObserver {

		@Override
		public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void validCoinDetected(CoinValidator validator, BigDecimal value) {
			moneyInserted = moneyInserted.add(value);
		}

		@Override
		public void invalidCoinDetected(CoinValidator validator) {
			// Ignore
		}
	}

	public class BVO implements BanknoteValidatorObserver {

		@Override
		public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void validBanknoteDetected(BanknoteValidator validator, Currency currency, int value) {
			moneyInserted = moneyInserted.add(new BigDecimal(value));
		}

		@Override
		public void invalidBanknoteDetected(BanknoteValidator validator) {
			// Ignore
		}
	}

	public CashPaymentController(StationController stationController) {

	}

	// GUI button for finishing adding cash
	public void payWithCash() {
		notifyPayWithCash(moneyInserted);
		moneyInserted = new BigDecimal(0.0);
	}

	public BigDecimal getMoneyInserted() {
		return moneyInserted;
	}

	public void attach(CashPaymentObserver observer) {
		controllerObservers.add(observer);
	}

	public void deattach(CashPaymentObserver observer) {
		controllerObservers.remove(observer);
	}

	private void notifyPayWithCash(BigDecimal moneyInserted) {
		for (CashPaymentObserver l : controllerObservers)
			l.paidWithCash(this, moneyInserted);
	}
}

package ShoppingCart;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.InvalidArgumentSimulationException;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;
import Station.ControllerObserver;

public class EnterPLUCodeControllerTest extends BaseTest {

	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test(expected = InvalidArgumentSimulationException.class)
	public void testEnterUnknownBarcode() throws OverloadException {
		enterPLUCodeController.entered(new PriceLookupCode("0000"));
	}

	@Test
	public void testEnterknownPLU() throws OverloadException {
		Item item = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item);
		enterPLUCodeController.entered(pluCodeItem5);
		assertEquals(enterPLUCodeController.getEnteredItemList().get(pluCodeItem5), weightBunch5,
				scs.scanningArea.getSensitivity());
		assertTrue(isSystemBlockedAsDesired());
	}

	@Test
	public void testEnterSamePLUItemMultipleTimes() throws OverloadException {
		Item item1 = new PLUCodedItem(pluCodeItem5, weightBunch6);
		scs.scanningArea.add(item1);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item1);
		scs.baggingArea.add(item1);

		Item item2 = new PLUCodedItem(pluCodeItem5, weightBunch7);
		scs.scanningArea.add(item2);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item2);
		scs.baggingArea.add(item2);

		Item item3 = new PLUCodedItem(pluCodeItem5, weightBunch8);
		scs.scanningArea.add(item3);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item3);
		scs.baggingArea.add(item3);

		assertEquals(enterPLUCodeController.getEnteredItemList().get(pluCodeItem5),
				weightBunch6 + weightBunch7 + weightBunch8, scs.scanningArea.getSensitivity());
	}

	@Test
	public void testNoObserverAttached() throws OverloadException {
		Set<ControllerObserver> controllerObservers = cart.getControllerObservers();
		for (ControllerObserver observer : controllerObservers) {
			if (observer instanceof EnterPLUCodeObserver) {
				enterPLUCodeController.deattach((EnterPLUCodeObserver) observer);
			}
		}
		Item item = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item);
		enterPLUCodeController.entered(pluCodeItem5);
		assertEquals(baggingAreaController.getStatus(), BAProcessing.PENDING);
	}

	private boolean isSystemBlockedAsDesired() {
		return scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled() && scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && scs.printer.isDisabled();
	}
}
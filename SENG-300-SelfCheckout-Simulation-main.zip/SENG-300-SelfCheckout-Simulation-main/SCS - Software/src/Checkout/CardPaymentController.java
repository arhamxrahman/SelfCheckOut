package Checkout;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import org.lsmr.selfcheckout.Card.CardData;
import org.lsmr.selfcheckout.devices.AbstractDevice;
import org.lsmr.selfcheckout.devices.CardReader;
import org.lsmr.selfcheckout.devices.observers.AbstractDeviceObserver;
import org.lsmr.selfcheckout.devices.observers.CardReaderObserver;
import org.lsmr.selfcheckout.external.CardIssuer;

import Station.StationController;

public class CardPaymentController {
	private final Set<CardPaymentObserver> controllerObservers = new HashSet<>();
	private BigDecimal amountToPay;
	private String cardType;
	private String cardNumber;

	public class CRO implements CardReaderObserver {

		@Override
		public void enabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void disabled(AbstractDevice<? extends AbstractDeviceObserver> device) {
			// Ignore
		}

		@Override
		public void cardInserted(CardReader reader) {
			// Do nothing
		}

		@Override
		public void cardRemoved(CardReader reader) {
			// Clear data from previous transaction
			cardType = "";
			cardNumber = "";
			amountToPay = new BigDecimal(0.0);
		}

		@Override
		public void cardTapped(CardReader reader) {
			// Do nothing
		}

		@Override
		public void cardSwiped(CardReader reader) {
			// Do nothing
		}

		@Override
		public void cardDataRead(CardReader reader, CardData data) {
			cardType = data.getType();
			cardNumber = data.getNumber();
			if (cardType != "membership") {
				processPayment();
			}
		}
	}

	public CardPaymentController(StationController stationController) {

	}

	public void setAmountToPay(BigDecimal amountToPay) {
		this.amountToPay = amountToPay;
	}

	public void attach(CardPaymentObserver observer) {
		controllerObservers.add(observer);
	}

	public void deattach(CardPaymentObserver observer) {
		controllerObservers.remove(observer);
	}

	private void processPayment() {
		CardIssuer CI = CardIssuerDatabase.CARD_ISSUER_DATABASE.get(cardType);
		int holdNumber = CI.authorizeHold(cardNumber, amountToPay);
		if (holdNumber != -1) {
			CI.postTransaction(cardNumber, holdNumber, amountToPay);
			notifySuccessfulCardPayment(amountToPay);
		} else {
			notifyFailedCardPayment();
		}
	}

	private void notifySuccessfulCardPayment(BigDecimal amountPaid) {
		for (CardPaymentObserver l : controllerObservers)
			l.successfulCardTransaction(this, amountPaid);
	}

	private void notifyFailedCardPayment() {
		for (CardPaymentObserver l : controllerObservers)
			l.failedCardTransaction(this);
	}
}

package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.external.ProductDatabases;

import Station.StationController;
import Station.StationState;
import Supervision.AttendantObserver;

public class AddingItemScreen implements AttendantObserver {
	App app;
	StationController stationController;
	Session session;

	JFrame welcomeFrame;

	JFrame addingItemsFrame;
	JPanel addingItemsPanel;

	JTextArea currentItemsInCart;
	JLabel totalLabel;

	JButton PLUButton;
	JButton LookupButton;
	JButton ownBagButton;
	JButton callAttendantButton;
	JButton bypassBAButton;
	JButton membershipButton;
	JButton cancel;
	JButton checkoutButton;

	JLabel scannerLabel;
	JComboBox barcodeList;
	JButton mainScannerButton;
	JButton handleScannerButton;

	JTextField scanningAreaInput;
	JButton scanningAreaButton;

	JLabel baggingAreaLabel;
	JButton baggingAreaButton;

	JButton refresh;

	public AddingItemScreen(App app, int stationIndex, JFrame welcomeFrame) {
		this.app = app;
		this.stationController = app.getStationController(stationIndex);
		this.welcomeFrame = welcomeFrame;

		startNewSession();
		session.setStationIndex(stationIndex);
		session.setApp(app);

		app.getAttendantIntervention().attach(this);

		addingItemsFrame = new JFrame("Pending Entry...");
		addingItemsPanel = new JPanel();
		addingItemsPanel.setLayout(new GridBagLayout());

		addWidgets();

		addingItemsFrame.getContentPane().add(addingItemsPanel, BorderLayout.CENTER);
		addingItemsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		addingItemsFrame.setSize(800, 650);
		addingItemsFrame.setVisible(true);
	}

	private void addWidgets() {

		PLUButton = new JButton("Key in Item");
		PLUButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PLUEntryScreen next = new PLUEntryScreen(addingItemsFrame, session);
				next.pluGUI.setVisible(true);
				next.pluGUI.setLocationRelativeTo(addingItemsFrame);
				addingItemsFrame.setVisible(false);
			}
		});

		LookupButton = new JButton("Look up Item");
		LookupButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LookUpProductScreen next = new LookUpProductScreen(addingItemsFrame, session);
				next.lookupFrame.setVisible(true);
				next.lookupFrame.setLocationRelativeTo(addingItemsFrame);
				addingItemsFrame.setVisible(false);
			}
		});

		ownBagButton = new JButton("Use Own Bag");
		ownBagButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				class ReusableBag extends Item {
					protected ReusableBag(double weightInGrams) {
						super(weightInGrams);
					}
				}
				Item usableBags = new ReusableBag(10);
				session.setCurrentItemChoice(usableBags);
				stationController.getShoppingCart().useReusableBags();
				updateState();
			}
		});

		callAttendantButton = new JButton("Call Attendant");
		callAttendantButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.callAttendant();
				updateState();
			}
		});

		bypassBAButton = new JButton("Item too big/heavy");
		bypassBAButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getShoppingCart().byPassBaggingArea();
				updateState();
			}
		});

		membershipButton = new JButton("Enter Memebership");
		membershipButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				session.getStationController().getCheckout().getMembershipController().enterMembership();
				session.setCurrentCardForPayment(app.getDummyMembershipCard());
				MembershipSelectionScreen next = new MembershipSelectionScreen(addingItemsFrame, session);
				next.membershipSelectionFrame.setVisible(true);
				next.membershipSelectionFrame.setLocationRelativeTo(addingItemsFrame);
				addingItemsFrame.setVisible(false);
			}
		});

		cancel = new JButton("Cancel");
		cancel.setBackground(Color.RED);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.restartSession();
				startNewSession();
				welcomeFrame.setVisible(true);
				addingItemsFrame.dispose();
			}
		});

		checkoutButton = new JButton("Checkout");
		checkoutButton.setBackground(Color.GREEN);
		checkoutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getCheckout().startCheckout();
				PlasticBagsEntryScreen next = new PlasticBagsEntryScreen(addingItemsFrame, stationController, session);
				next.bagsFrame.setVisible(true);
				next.bagsFrame.setLocationRelativeTo(addingItemsFrame);
				addingItemsFrame.setVisible(false);
				updateState();
			}
		});

		refresh = new JButton("Refresh");
		refresh.setBackground(Color.CYAN);
		refresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cartListRefresh();
				totalRefresh();
				updateState();
			}
		});

		currentItemsInCart = new JTextArea();
		currentItemsInCart.setEditable(false);
		currentItemsInCart.setText("Items In Cart" + "\n" + "-------------------------");

		// refer to the tutorial
		totalLabel = new JLabel("Total", SwingConstants.CENTER);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		scannerLabel = new JLabel("Scanners", SwingConstants.CENTER);
		addingItemsPanel.add(scannerLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;

		Barcode barcodeChoices[] = { app.barcodeItem1, app.barcodeItem2, app.barcodeItem3, app.barcodeItem4 };
		barcodeList = new JComboBox(barcodeChoices);
		addingItemsPanel.add(barcodeList, gbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		mainScannerButton = new JButton("Main");
		addingItemsPanel.add(mainScannerButton, gbc);
		gbc.gridx = 0;
		gbc.gridy = 3;
		handleScannerButton = new JButton("Handle");
		addingItemsPanel.add(handleScannerButton, gbc);
		gbc.gridx = 0;
		gbc.gridy = 4;
		scanningAreaInput = new JTextField("Enter weight to be measured by the scale");
		addingItemsPanel.add(scanningAreaInput, gbc);
		gbc.gridx = 0;
		gbc.gridy = 5;
		scanningAreaButton = new JButton("Scanning Area Scale");
		addingItemsPanel.add(scanningAreaButton, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.gridheight = 2;
		gbc.gridwidth = 3;
		addingItemsPanel.add(currentItemsInCart, gbc);
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.gridheight = 1;
		addingItemsPanel.add(totalLabel, gbc);

		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		addingItemsPanel.add(PLUButton, gbc);
		gbc.gridx = 2;
		gbc.gridy = 3;
		addingItemsPanel.add(LookupButton, gbc);
		gbc.gridx = 3;
		gbc.gridy = 3;
		addingItemsPanel.add(ownBagButton, gbc);
		gbc.gridx = 1;
		gbc.gridy = 4;
		addingItemsPanel.add(callAttendantButton, gbc);
		gbc.gridx = 2;
		gbc.gridy = 4;
		addingItemsPanel.add(bypassBAButton, gbc);
		gbc.gridx = 3;
		gbc.gridy = 4;
		addingItemsPanel.add(membershipButton, gbc);
		gbc.gridx = 1;
		gbc.gridy = 5;
		gbc.gridwidth = 2;
		addingItemsPanel.add(cancel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 5;
		gbc.gridwidth = 1;
		addingItemsPanel.add(checkoutButton, gbc);

		gbc.gridx = 4;
		gbc.gridy = 0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		addingItemsPanel.add(refresh, gbc);

		gbc.gridx = 4;
		gbc.gridy = 1;
		gbc.gridheight = 3;
		gbc.gridwidth = 2;
		baggingAreaLabel = new JLabel("Bagging Area", SwingConstants.CENTER);
		addingItemsPanel.add(baggingAreaLabel, gbc);
		gbc.gridx = 4;
		gbc.gridy = 3;
		gbc.gridheight = 3;
		gbc.gridwidth = 2;
		baggingAreaButton = new JButton("Scale");
		addingItemsPanel.add(baggingAreaButton, gbc);

		updateState();

		mainScannerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Barcode code = (Barcode) barcodeList.getSelectedItem();
				if (ProductDatabases.BARCODED_PRODUCT_DATABASE.get(code) != null) {
					double weight = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(code).getExpectedWeight();
					BarcodedItem item = new BarcodedItem(code, weight);
					session.setCurrentItemChoice(item);
					session.setLastScannedBarcode(code);
				}
				stationController.getStation().mainScanner.scan(session.getCurrentItemChoice());
				cartListRefresh();
				totalRefresh();
				updateState();
			}
		});

		handleScannerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Barcode code = (Barcode) barcodeList.getSelectedItem();
				if (ProductDatabases.BARCODED_PRODUCT_DATABASE.get(code) != null) {
					double weight = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(code).getExpectedWeight();
					BarcodedItem item = new BarcodedItem(code, weight);
					session.setCurrentItemChoice(item);
					session.setLastScannedBarcode(code);
				}
				stationController.getStation().handheldScanner.scan(session.getCurrentItemChoice());
				cartListRefresh();
				totalRefresh();
				updateState();
			}
		});

		// Code from
		// https://stackoverflow.com/questions/43473110/jtextfield-accept-only-numbers-and-one-dot
		scanningAreaInput.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if ((Character.isDigit(c)) || (c == KeyEvent.VK_PERIOD) || (c == KeyEvent.VK_BACK_SPACE)) {
					int punto = 0;
					if (c == KeyEvent.VK_PERIOD) {
						String s = scanningAreaInput.getText();
						int dot = s.indexOf('.');
						punto = dot;
						if (dot != -1) {
							e.consume();
						}
					}
				} else {
					e.consume();
				}
			}
		});

		scanningAreaButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String weight = scanningAreaInput.getText();
				PriceLookupCode code = session.getLastEnteredPLU();
				PLUCodedItem item = new PLUCodedItem(code, Double.parseDouble(weight));
				session.setCurrentItemChoice(item);
				stationController.getStation().scanningArea.add(session.getCurrentItemChoice());
				try {
					stationController.getShoppingCart().getEnterPLUCodeController().entered(code);
				} catch (OverloadException e1) {

				}
				stationController.getStation().scanningArea.remove(item);
				cartListRefresh();
				totalRefresh();
				updateState();
				scanningAreaInput.setText("weight in gram");
			}
		});

		baggingAreaButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getStation().baggingArea.add(session.getCurrentItemChoice());
				cartListRefresh();
				totalRefresh();
				updateState();
			}
		});
	}

	private void startNewSession() {
		Session session = new Session();
		session.setStationController(stationController);
		session.setCurrentItemChoice(app.getDummyItem());
		session.setCurrentCardForPayment(app.getDummyCard());
		session.setCardPIN(app.getDummyCardPin());

		this.session = session;
	}

	private void cartListRefresh() {
		StringBuilder str = new StringBuilder();

		Map<Barcode, Integer> scannedItemList = stationController.getShoppingCart().getScannedItemList();
		Map<PriceLookupCode, Double> enteredItemList = stationController.getShoppingCart().getEnteredItemList();

		if (session.getMembership() != null) {
			str.append("Welcome #");
			str.append(session.getMembership());
			str.append('\n');
		}

		for (Barcode barcode : scannedItemList.keySet()) {
			String description = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getDescription();
			int quantity = scannedItemList.get(barcode);
			BigDecimal price = ProductDatabases.BARCODED_PRODUCT_DATABASE.get(barcode).getPrice().setScale(2,
					RoundingMode.HALF_DOWN);
			str.append(barcode);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(quantity);
			str.append(" @ $");
			str.append(price);
			str.append("				");
			str.append(price.multiply(new BigDecimal(quantity)));
			str.append('\n');
		}

		for (PriceLookupCode plu : enteredItemList.keySet()) {
			String description = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getDescription();
			BigDecimal weight = new BigDecimal(enteredItemList.get(plu) / 1000).setScale(3, RoundingMode.HALF_DOWN);
			;
			BigDecimal price = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice().multiply(new BigDecimal(1000))
					.setScale(2, RoundingMode.HALF_DOWN);
			BigDecimal cost = ProductDatabases.PLU_PRODUCT_DATABASE.get(plu).getPrice()
					.multiply(new BigDecimal(enteredItemList.get(plu))).setScale(2, RoundingMode.HALF_DOWN);
			str.append(plu);
			str.append(' ');
			str.append(description);
			str.append('\n');
			str.append(weight);
			str.append(" kg @ $");
			str.append(price);
			str.append("/kg			");
			str.append(cost);
			str.append('\n');
		}

		int numOfBags = stationController.getShoppingCart().getNumOfBags();
		BigDecimal pricePerBag = stationController.getShoppingCart().getPricePerBag();
		if (numOfBags > 0) {
			BigDecimal cost = pricePerBag.multiply(new BigDecimal(numOfBags)).setScale(2, RoundingMode.HALF_DOWN);
			str.append("Plastic Bag");
			str.append('\n');
			str.append(numOfBags);
			str.append(" @ $");
			str.append(pricePerBag.setScale(2, RoundingMode.HALF_DOWN));
			str.append("				");
			str.append(cost);
			str.append('\n');
		}
		currentItemsInCart.setText(str.toString());
	}

	private void totalRefresh() {
		BigDecimal total = stationController.getShoppingCart().calculateTotalCosts();
		totalLabel.setText("Total: " + total.toString());
	}

	private void updateState() {
		StationState state = stationController.getState();
		String membership = stationController.getCheckout().getMembershipController().getMembershipNumber();
		BigDecimal payment = stationController.getCheckout().getTotalPayments();
		BigDecimal cost = stationController.getShoppingCart().calculateTotalCosts();

		switch (state) {
		case ADDING:
		case PAYING:
		case PAID:
			barcodeList.setEnabled(true);
			mainScannerButton.setEnabled(true);
			handleScannerButton.setEnabled(true);
			baggingAreaButton.setEnabled(true);
			scanningAreaInput.setEnabled(true);
			scanningAreaButton.setEnabled(true);
			PLUButton.setEnabled(true);
			LookupButton.setEnabled(true);
			ownBagButton.setEnabled(true);
			callAttendantButton.setEnabled(true);
			bypassBAButton.setEnabled(true);
			if (membership == null || membership == "") {
				membershipButton.setEnabled(true);
			} else {
				membershipButton.setEnabled(false);
			}

			if (payment.compareTo(new BigDecimal(0.0)) > 0) {
				cancel.setEnabled(false);
			} else {
				cancel.setEnabled(true);
			}

			if (cost == null || cost.compareTo(new BigDecimal(0.0)) <= 0) {
				checkoutButton.setEnabled(false);
			} else {
				checkoutButton.setEnabled(true);
			}
			refresh.setEnabled(true);
			break;
		case BAGGING:
			barcodeList.setEnabled(false);
			mainScannerButton.setEnabled(false);
			handleScannerButton.setEnabled(false);
			baggingAreaButton.setEnabled(true);
			scanningAreaInput.setEnabled(false);
			scanningAreaButton.setEnabled(false);
			PLUButton.setEnabled(false);
			LookupButton.setEnabled(false);
			ownBagButton.setEnabled(false);
			callAttendantButton.setEnabled(true);
			bypassBAButton.setEnabled(true);
			membershipButton.setEnabled(false);
			if (payment.compareTo(new BigDecimal(0.0)) > 0) {
				cancel.setEnabled(false);
			} else {
				cancel.setEnabled(true);
			}
			checkoutButton.setEnabled(false);
			refresh.setEnabled(true);
			break;
		case SUSPEND:
			barcodeList.setEnabled(false);
			mainScannerButton.setEnabled(false);
			handleScannerButton.setEnabled(false);
			baggingAreaButton.setEnabled(false);
			scanningAreaInput.setEnabled(false);
			scanningAreaButton.setEnabled(false);
			PLUButton.setEnabled(false);
			LookupButton.setEnabled(false);
			ownBagButton.setEnabled(false);
			callAttendantButton.setEnabled(false);
			bypassBAButton.setEnabled(false);
			membershipButton.setEnabled(false);
			cancel.setEnabled(false);
			checkoutButton.setEnabled(false);
			refresh.setEnabled(false);
			break;
		default:
			break;
		}
	}

	@Override
	public void unblockStation() {
		stationController.setState(StationState.ADDING);
		cartListRefresh();
		totalRefresh();
		updateState();
	}

	@Override
	public void removeItem() {
		cartListRefresh();
		totalRefresh();
		updateState();
	}

	@Override
	public void blockStation() {
		cartListRefresh();
		totalRefresh();
		updateState();
	}
}

package ShoppingCart;

import Station.ControllerObserver;

public interface ScanBarcodeObserver extends ControllerObserver {
	public void barcodeProductScanned(ScanBarcodeController scanBarcodeController);
}

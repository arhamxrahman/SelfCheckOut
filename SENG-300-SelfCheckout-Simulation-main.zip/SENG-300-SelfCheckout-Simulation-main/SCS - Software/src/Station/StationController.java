package Station;

import java.util.ArrayList;

import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

import Checkout.Checkout;
import ShoppingCart.ShoppingCart;

public class StationController {
	private SelfCheckoutStation scs;
	private StationState state = StationState.ADDING;
	private ShoppingCart cart;
	private Checkout checkout;
	private ArrayList<StationObserver> stationObservers = new ArrayList<>();
//	CSO observer = new CSO();

	public StationController(SelfCheckoutStation scs) {
		this.scs = scs;
	}

	public void setShoppingCart(ShoppingCart shoppingCart) {
		this.cart = shoppingCart;
//		cart.attach(observer);
	}

	public void setCheckout(Checkout checkout) {
		this.checkout = checkout;
//		checkout.attach(observer);
	}

	public void attach(StationObserver observer) {
		stationObservers.add(observer);
	}

	public void deattach(StationObserver observer) {
		stationObservers.remove(observer);
	}

	public void callAttendant() {
		setState(StationState.SUSPEND);
		notifyAttendantCall();
	}

	public void restartSession() {
		setState(StationState.ADDING);
		checkout.getMembershipController().resetMembership();
		cart.resetShoppingCart();
		checkout.resetPayments();
	}

	public StationState getState() {
		return state;
	}

	public void setState(StationState state) {
		this.state = state;
		switch (state) {
		case ADDING:
		case PAID:
			enableAdding();
			break;
		case BAGGING:
			enableBagging();
			break;
		case PAYING:
			enablePaying();
			break;
		case SUSPEND:
			suspendSystem();
			break;
		default:
			break;
		}
	}

	public SelfCheckoutStation getStation() {
		return scs;
	}

	public ShoppingCart getShoppingCart() {
		return cart;
	}

	public Checkout getCheckout() {
		return checkout;
	}

	private void suspendSystem() {
		scs.mainScanner.disable();
		scs.handheldScanner.disable();
		scs.scanningArea.disable();
		scs.baggingArea.disable();
		scs.coinSlot.disable();
		scs.banknoteInput.disable();
		scs.cardReader.disable();
		scs.printer.disable();
	}

	private void enableAdding() {
		scs.mainScanner.enable();
		scs.handheldScanner.enable();
		scs.scanningArea.enable();
		scs.baggingArea.enable();
		scs.coinSlot.disable();
		scs.banknoteInput.disable();
		scs.cardReader.disable();
		scs.printer.enable();
	}

	private void enableBagging() {
		scs.mainScanner.disable();
		scs.handheldScanner.disable();
		scs.scanningArea.disable();
		scs.baggingArea.enable();
		scs.coinSlot.disable();
		scs.banknoteInput.disable();
		scs.cardReader.disable();
		scs.printer.disable();
	}

	private void enablePaying() {
		scs.mainScanner.disable();
		scs.handheldScanner.disable();
		scs.scanningArea.disable();
		scs.baggingArea.disable();
		scs.coinSlot.enable();
		scs.banknoteInput.enable();
		scs.cardReader.enable();
		scs.printer.disable();
	}

	private void notifyAttendantCall() {
		for (StationObserver l : stationObservers) {
			l.callAttendant(this);
		}
	}
}

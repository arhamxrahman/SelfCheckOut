package Checkout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;

public class ReceiptControllerTest extends BaseTest {
	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testPrintReceiptWithNoMembership() throws IOException {
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		while (cart.getScannedItemList().get(barcodeItem1) == null) {
			scs.mainScanner.scan(item1);
		}
		scs.baggingArea.add(item1);
		int numOfBags = 2;
		cart.addPlasticBags(numOfBags);
		BigDecimal pricePerBag = new BigDecimal(0.1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CREDIT);
		checkout.setAmountToPay(
				priceItem1.add(pricePerBag.multiply(new BigDecimal(numOfBags))).setScale(2, RoundingMode.HALF_DOWN));

		scs.cardReader.insert(creditCard, pin);
		scs.cardReader.remove();
		assertEquals(checkout.getTotalPayments().doubleValue(), 6.19, 0.0);

		assertTrue(checkout.isPaidInFull());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);

		scs.baggingArea.remove(item1);
	}

	@Test
	public void testPrintReceiptWithMembershipEntered() throws IOException, OverloadException, DisabledException {
		Item item5 = new PLUCodedItem(pluCodeItem5, weightBunch5);
		scs.scanningArea.add(item5);
		enterPLUCodeController.entered(pluCodeItem5);
		scs.scanningArea.remove(item5);
		scs.baggingArea.add(item5);

		membershipController.enterMembership();
		membershipController.manualEntry(cardNumber);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);
		scs.coinSlot.accept(toonie);

		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 2.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 2.00, 0.0);

		assertTrue(checkout.isPaidInFull());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);

		scs.baggingArea.remove(item5);
	}
}

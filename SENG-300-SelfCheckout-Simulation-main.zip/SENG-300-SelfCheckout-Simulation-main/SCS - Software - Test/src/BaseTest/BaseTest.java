package BaseTest;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Currency;

import org.junit.Before;
import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.Barcode;
import org.lsmr.selfcheckout.Card;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.Numeral;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.devices.SupervisionStation;
import org.lsmr.selfcheckout.external.CardIssuer;
import org.lsmr.selfcheckout.external.ProductDatabases;
import org.lsmr.selfcheckout.products.BarcodedProduct;
import org.lsmr.selfcheckout.products.PLUCodedProduct;

import Checkout.CardIssuerDatabase;
import Checkout.CardPaymentController;
import Checkout.CashPaymentController;
import Checkout.Checkout;
import Checkout.MembershipController;
import ShoppingCart.BaggingAreaController;
import ShoppingCart.EnterPLUCodeController;
import ShoppingCart.ScanBarcodeController;
import ShoppingCart.ShoppingCart;
import Station.StationController;
import Supervision.AttendantIntervention;
import Supervision.AttendantLoginDatabase;

// All the weights are in grams
public class BaseTest {
	protected SupervisionStation attendantStation = new SupervisionStation();
	protected AttendantLoginDatabase loginDatabase = new AttendantLoginDatabase();
	protected AttendantIntervention attendantIntervention;
	protected SelfCheckoutStation scs;
	protected StationController stationController;
	protected int currentStationIndex = 0;

	protected ShoppingCart cart;
	protected ScanBarcodeController scanBarcodeController;
	protected EnterPLUCodeController enterPLUCodeController;
	protected BaggingAreaController baggingAreaController;

	protected Checkout checkout;
	protected CashPaymentController cashPaymentController;
	protected CardPaymentController cardPaymentController;
	protected MembershipController membershipController;

	// Declaring parameters for self checkout station
	protected Currency currency = Currency.getInstance("CAD");
	private final int[] banknoteDenominations = { 5, 10, 20, 50, 100 };
	private final BigDecimal[] coinDenominations = { new BigDecimal(0.05), new BigDecimal(0.10), new BigDecimal(0.25),
			new BigDecimal(1.00), new BigDecimal(2.00) };
	private int scaleMaxWeight;
	private int scaleSensitivity;

	// Initializing barcode of the items
	protected Numeral[] nItem1 = { Numeral.one, Numeral.two, Numeral.three, Numeral.four };
	protected Numeral[] nItem2 = { Numeral.two, Numeral.three, Numeral.four, Numeral.one };
	protected Numeral[] nItem3 = { Numeral.three, Numeral.four, Numeral.one, Numeral.two };
	protected Numeral[] nItem4 = { Numeral.four, Numeral.one, Numeral.two, Numeral.three };

	protected Barcode barcodeItem1 = new Barcode(nItem1);
	protected Barcode barcodeItem2 = new Barcode(nItem2);
	protected Barcode barcodeItem3 = new Barcode(nItem3);
	protected Barcode barcodeItem4 = new Barcode(nItem4);

	// Initializing description of barcode items
	protected String nameItem1 = "Avocado Bags";
	protected String nameItem2 = "Blueberry Muffins";
	protected String nameItem3 = "Orange Juice";
	protected String nameItem4 = "Cheese Crackers";

	// Initializing prices of barcode items
	protected BigDecimal priceItem1 = new BigDecimal(5.99);
	protected BigDecimal priceItem2 = new BigDecimal(4.50);
	protected BigDecimal priceItem3 = new BigDecimal(6.79);
	protected BigDecimal priceItem4 = new BigDecimal(3.49);

	// Initializing weights of barcode items
	protected double weightItem1 = 170.0;
	protected double weightItem2 = 570.0;
	protected double weightItem3 = 2000.0;
	protected double weightItem4 = 180.0;

	// Initializing PLU code of the items
	protected PriceLookupCode pluCodeItem5 = new PriceLookupCode("1111");
	protected PriceLookupCode pluCodeItem6 = new PriceLookupCode("2222");
	protected PriceLookupCode pluCodeItem7 = new PriceLookupCode("3333");
	protected PriceLookupCode pluCodeItem8 = new PriceLookupCode("4444");

	// Initializing description of PLU items
	protected String nameItem5 = "Bananas";
	protected String nameItem6 = "Roma Tomatos";
	protected String nameItem7 = "Grapes";
	protected String nameItem8 = "Broccoli Crowns";

	// Initializing prices of PLU items
	protected BigDecimal priceItem5 = new BigDecimal(0.00130);
	protected BigDecimal priceItem6 = new BigDecimal(0.00328);
	protected BigDecimal priceItem7 = new BigDecimal(0.00880);
	protected BigDecimal priceItem8 = new BigDecimal(0.00549);

	// Initializing weights of PLU items
	protected double weightBunch5 = 950.0;
	protected double weightBunch6 = 1250.8;
	protected double weightBunch7 = 450.6;
	protected double weightBunch8 = 175.5;

	// Initializing Coins
	protected Coin nickel = new Coin(currency, new BigDecimal(0.05));
	protected Coin dime = new Coin(currency, new BigDecimal(0.10));
	protected Coin quarter = new Coin(currency, new BigDecimal(0.25));
	protected Coin loonie = new Coin(currency, new BigDecimal(1.00));
	protected Coin toonie = new Coin(currency, new BigDecimal(2.00));

	// Initializing Banknotes
	protected Banknote fiveDollars = new Banknote(currency, 5);
	protected Banknote tenDollars = new Banknote(currency, 10);
	protected Banknote twentyDollars = new Banknote(currency, 20);
	protected Banknote fiftyDollars = new Banknote(currency, 50);
	protected Banknote hundredDollars = new Banknote(currency, 10);

	// Initializing Card Data
	protected String debitCardType = "debit";
	protected String creditCardType = "credit";
	protected String giftCardType = "gift";
	protected String membershipCardType = "membership";

	protected String cardNumber = "0000111122223333";
	protected String cardholder = "Adam Smith";
	protected String cvv = "123";
	protected String pin = "4567";
	protected Calendar expiry = Calendar.getInstance();
	protected boolean tapEnabled = true;
	protected boolean tapNotEnabled = false;
	protected boolean hasChip = true;
	protected boolean hasNoChip = false;
	protected BigDecimal accountBalance = new BigDecimal(10.0);

	// Initializing Card Issuers
	protected CardIssuer debitCardIssuer = new CardIssuer(debitCardType);
	protected CardIssuer creditCardIssuer = new CardIssuer(creditCardType);
	protected CardIssuer giftCardIssuer = new CardIssuer(giftCardType);
	protected CardIssuer membershipCardIssuer = new CardIssuer(membershipCardType);

	// Initializing Cards
	protected Card debitCard = new Card(debitCardType, cardNumber, cardholder, cvv, pin, tapEnabled, hasChip);
	protected Card creditCard = new Card(creditCardType, cardNumber, cardholder, cvv, pin, tapEnabled, hasChip);
	protected Card giftCard = new Card(giftCardType, cardNumber, cardholder, cvv, pin, tapEnabled, hasChip);
	protected Card membershipCard = new Card(membershipCardType, cardNumber, cardholder, null, null, tapEnabled,
			hasNoChip);

	// Initializing Employee Credentials
	protected String employID1 = "1234";
	protected String employID2 = "5678";
	protected String passcode1 = "9876";
	protected String passcode2 = "5432";

	/**
	 * Initializes SelfCheckoutStation with dummy data.
	 * 
	 * @throws OverloadException
	 */
	@Before
	public void setup() throws OverloadException {
		// Initializing parameters for SCS
		scaleMaxWeight = 23000;
		scaleSensitivity = 1;

		// Initializing SCS
		scs = new SelfCheckoutStation(currency, banknoteDenominations, coinDenominations, scaleMaxWeight,
				scaleSensitivity);
		attendantStation.add(scs);
		this.attendantIntervention = new AttendantIntervention(attendantStation, loginDatabase);

		// Initializing BARCODED_PRODUCT_DATABASE
		BarcodedProduct barProduct1 = new BarcodedProduct(barcodeItem1, nameItem1, priceItem1, weightItem1);
		BarcodedProduct barProduct2 = new BarcodedProduct(barcodeItem2, nameItem2, priceItem2, weightItem2);
		BarcodedProduct barProduct3 = new BarcodedProduct(barcodeItem3, nameItem3, priceItem3, weightItem3);
		BarcodedProduct barProduct4 = new BarcodedProduct(barcodeItem4, nameItem4, priceItem4, weightItem4);

		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem1, barProduct1);
		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem2, barProduct2);
		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem3, barProduct3);
		ProductDatabases.BARCODED_PRODUCT_DATABASE.put(barcodeItem4, barProduct4);

		// Initializing PLU_PRODUCT_DATABASE
		PLUCodedProduct pluProduct5 = new PLUCodedProduct(pluCodeItem5, nameItem5, priceItem5);
		PLUCodedProduct pluProduct6 = new PLUCodedProduct(pluCodeItem6, nameItem6, priceItem6);
		PLUCodedProduct pluProduct7 = new PLUCodedProduct(pluCodeItem7, nameItem7, priceItem7);
		PLUCodedProduct pluProduct8 = new PLUCodedProduct(pluCodeItem8, nameItem8, priceItem8);

		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem5, pluProduct5);
		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem6, pluProduct6);
		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem7, pluProduct7);
		ProductDatabases.PLU_PRODUCT_DATABASE.put(pluCodeItem8, pluProduct8);

		this.stationController = attendantIntervention.getStationControllers().get(0);
		this.scanBarcodeController = new ScanBarcodeController(stationController);
		this.enterPLUCodeController = new EnterPLUCodeController(stationController);
		this.baggingAreaController = new BaggingAreaController(stationController);
		baggingAreaController.setBarcodeScanController(scanBarcodeController);
		baggingAreaController.setPluCodeEntryController(enterPLUCodeController);
		this.cart = new ShoppingCart(stationController, scanBarcodeController, enterPLUCodeController,
				baggingAreaController);
		stationController.setShoppingCart(cart);

		this.cashPaymentController = new CashPaymentController(stationController);
		this.cardPaymentController = new CardPaymentController(stationController);
		this.membershipController = new MembershipController(stationController);
		this.checkout = new Checkout(stationController, cart, cashPaymentController, cardPaymentController,
				membershipController);
		stationController.setCheckout(checkout);

		scs.mainScanner.attach(scanBarcodeController.new BSO());
		scs.handheldScanner.attach(scanBarcodeController.new BSO());
		scs.baggingArea.attach(baggingAreaController.new BAESO());
		scs.coinValidator.attach(cashPaymentController.new CVO());
		scs.banknoteValidator.attach(cashPaymentController.new BVO());
		scs.cardReader.attach(cardPaymentController.new CRO());
		scs.cardReader.attach(membershipController.new CRO());

		// Loading coins and banknotes
		Coin[] nickels = { nickel, nickel, nickel, nickel, nickel };
		Coin[] dimes = { dime, dime, dime, dime, dime };
		Coin[] quarters = { quarter, quarter, quarter, quarter, quarter };
		Coin[] loonies = { loonie, loonie, loonie, loonie, loonie };
		Coin[] toonies = { toonie, toonie, toonie, toonie, toonie };

		scs.coinDispensers.get(new BigDecimal(0.05)).load(nickels);
		scs.coinDispensers.get(new BigDecimal(0.10)).load(dimes);
		scs.coinDispensers.get(new BigDecimal(0.25)).load(quarters);
		scs.coinDispensers.get(new BigDecimal(1.00)).load(loonies);
		scs.coinDispensers.get(new BigDecimal(2.00)).load(toonies);

		Banknote[] fives = { fiveDollars, fiveDollars, fiveDollars, fiveDollars, fiveDollars };
		Banknote[] tens = { tenDollars, tenDollars, tenDollars, tenDollars, tenDollars };
		Banknote[] twenties = { twentyDollars, twentyDollars, twentyDollars, twentyDollars, twentyDollars };
		Banknote[] fifties = { fiftyDollars, fiftyDollars, fiftyDollars };
		Banknote[] hundreds = { hundredDollars, hundredDollars };

		scs.banknoteDispensers.get(5).load(fives);
		scs.banknoteDispensers.get(10).load(tens);
		scs.banknoteDispensers.get(20).load(twenties);
		scs.banknoteDispensers.get(50).load(fifties);
		scs.banknoteDispensers.get(100).load(hundreds);

		// Initializing Card Issuer Database
		expiry.set(2024, 4, 30);

		debitCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(debitCardType, debitCardIssuer);

		creditCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(creditCardType, creditCardIssuer);

		giftCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(giftCardType, giftCardIssuer);

		membershipCardIssuer.addCardData(cardNumber, cardholder, expiry, cvv, accountBalance);
		CardIssuerDatabase.CARD_ISSUER_DATABASE.put(membershipCardType, membershipCardIssuer);

		// Setup Employee Login Database
		loginDatabase.addNewAttendantLogin(employID1, passcode1);
		loginDatabase.addNewAttendantLogin(employID2, passcode2);
	}
}
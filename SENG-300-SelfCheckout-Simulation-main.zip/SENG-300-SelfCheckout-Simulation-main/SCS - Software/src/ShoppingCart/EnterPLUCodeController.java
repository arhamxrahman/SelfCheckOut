package ShoppingCart;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.lsmr.selfcheckout.InvalidArgumentSimulationException;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;
import org.lsmr.selfcheckout.external.ProductDatabases;

import Station.StationController;

public class EnterPLUCodeController {
	private SelfCheckoutStation scs;
	private final Set<EnterPLUCodeObserver> controllerObservers = new HashSet<>();
	private Map<PriceLookupCode, Double> enteredItemList = new HashMap<>(); // for PLU products
	private double lastEnteredPLUProductWeight;

	public EnterPLUCodeController(StationController stationController) {
		this.scs = stationController.getStation();
	}

	public void attach(EnterPLUCodeObserver observer) {
		controllerObservers.add(observer);
	}

	public void deattach(EnterPLUCodeObserver observer) {
		controllerObservers.remove(observer);
	}

	public void entered(PriceLookupCode plu) throws OverloadException {
		if (ProductDatabases.PLU_PRODUCT_DATABASE.containsKey(plu)) {
			lastEnteredPLUProductWeight = scs.scanningArea.getCurrentWeight();
			if (enteredItemList.containsKey(plu)) {
				enteredItemList.replace(plu, enteredItemList.get(plu) + scs.scanningArea.getCurrentWeight());
			} else {
				enteredItemList.put(plu, scs.scanningArea.getCurrentWeight());
			}
			notifyProductEntered();
		} else {
			throw new InvalidArgumentSimulationException("undefined PLU");
		}
	}

	public double getLastEnteredPLUProductWeight() {
		return lastEnteredPLUProductWeight;
	}

	public Map<PriceLookupCode, Double> getEnteredItemList() {
		return enteredItemList;
	}

	public void resetEnteredItemList() {
		enteredItemList = new HashMap<>();
	}

	private void notifyProductEntered() {
		for (EnterPLUCodeObserver l : controllerObservers)
			l.pluProductEntered(this);
	}
}

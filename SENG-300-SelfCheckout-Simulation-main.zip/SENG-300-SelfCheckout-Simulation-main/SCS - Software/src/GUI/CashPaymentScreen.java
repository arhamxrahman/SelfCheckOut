package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.OverloadException;

import Station.StationController;

public class CashPaymentScreen {
	StationController stationController;

	JFrame cashPaymentGUI;
	JFrame checkoutFrame;
	JPanel cashPaymentGUIPanel;
	JLabel totalPayment;

	JButton payCoin5Cents;
	JButton payCoin10Cents;
	JButton payCoin25Cents;
	JButton payCoinLoonie;
	JButton payCoinToonie;

	JButton payBanknote5Dollars;
	JButton payBanknote10Dollars;
	JButton payBanknote20Dollars;
	JButton payBanknote50Dollars;
	JButton payBanknote100Dollars;

	JButton confirm;

	BigDecimal moneyInserted = new BigDecimal(0.0);

	public CashPaymentScreen(JFrame checkoutFrame, StationController stationController) {
		this.checkoutFrame = checkoutFrame;
		this.stationController = stationController;

		cashPaymentGUI = new JFrame("Cash Payment");
		cashPaymentGUIPanel = new JPanel();
		cashPaymentGUIPanel.setLayout(new GridBagLayout());

		addWidgets();

		cashPaymentGUI.getContentPane().add(cashPaymentGUIPanel, BorderLayout.CENTER);
		cashPaymentGUI.setLocationRelativeTo(null);
		cashPaymentGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		cashPaymentGUI.setSize(500, 300);
		cashPaymentGUI.setVisible(true);
	}

	private void addWidgets() {

		totalPayment = new JLabel("Total Cash Inserted: $0.0", SwingConstants.CENTER);

		Currency currency = Currency.getInstance("CAD");
		Coin nickel = new Coin(currency, new BigDecimal(0.05));
		Coin dime = new Coin(currency, new BigDecimal(0.10));
		Coin quarter = new Coin(currency, new BigDecimal(0.25));
		Coin loonie = new Coin(currency, new BigDecimal(1.00));
		Coin toonie = new Coin(currency, new BigDecimal(2.00));
		Banknote fiveDollars = new Banknote(currency, 5);
		Banknote tenDollars = new Banknote(currency, 10);
		Banknote twentyDollars = new Banknote(currency, 20);
		Banknote fiftyDollars = new Banknote(currency, 50);
		Banknote hundredDollars = new Banknote(currency, 100);

		payCoin5Cents = new JButton("Insert Nickle ($0.05)");
		payCoin5Cents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().coinSlot.accept(nickel);
					moneyInserted = moneyInserted.add(new BigDecimal(0.05));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payCoin10Cents = new JButton("Insert Dime ($0.10)");
		payCoin10Cents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().coinSlot.accept(dime);
					moneyInserted = moneyInserted.add(new BigDecimal(0.10));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payCoin25Cents = new JButton("Insert Quarter ($0.25)");
		payCoin25Cents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().coinSlot.accept(quarter);
					moneyInserted = moneyInserted.add(new BigDecimal(0.25));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payCoinLoonie = new JButton("Insert Loonie ($1.00)");
		payCoinLoonie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().coinSlot.accept(loonie);
					moneyInserted = moneyInserted.add(new BigDecimal(1.00));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payCoinToonie = new JButton("Insert Toonie ($2.00)");
		payCoinToonie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().coinSlot.accept(toonie);
					moneyInserted = moneyInserted.add(new BigDecimal(2.00));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payBanknote5Dollars = new JButton("Insert 5 Dollar Bill");
		payBanknote5Dollars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().banknoteInput.accept(fiveDollars);
					moneyInserted = moneyInserted.add(new BigDecimal(5.00));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payBanknote10Dollars = new JButton("Insert 10 Dollar Bill");
		payBanknote10Dollars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().banknoteInput.accept(tenDollars);
					moneyInserted = moneyInserted.add(new BigDecimal(10.00));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payBanknote20Dollars = new JButton("Insert 20 Dollar Bill");
		payBanknote20Dollars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().banknoteInput.accept(twentyDollars);
					moneyInserted = moneyInserted.add(new BigDecimal(20.00));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payBanknote50Dollars = new JButton("Insert 50 Dollar Bill");
		payBanknote50Dollars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().banknoteInput.accept(fiftyDollars);
					moneyInserted = moneyInserted.add(new BigDecimal(50.00));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		payBanknote100Dollars = new JButton("Insert 100 Dollar Bill");
		payBanknote100Dollars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					stationController.getStation().banknoteInput.accept(hundredDollars);
					moneyInserted = moneyInserted.add(new BigDecimal(100.00));
					refreshTotal();
				} catch (DisabledException | OverloadException e1) {

				}
			}
		});

		confirm = new JButton("Confirm");
		confirm.setBackground(Color.GREEN);
		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stationController.getCheckout().getCashPaymentController().payWithCash();
				checkoutFrame.setVisible(true);
				cashPaymentGUI.dispose();
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 2;
		gbc.weighty = 2;
		gbc.gridwidth = 2;
		cashPaymentGUIPanel.add(totalPayment, gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		cashPaymentGUIPanel.add(payCoin5Cents, gbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		cashPaymentGUIPanel.add(payCoin10Cents, gbc);
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 3;
		cashPaymentGUIPanel.add(payCoin25Cents, gbc);
		gbc.gridx = 0;
		gbc.gridy = 4;
		cashPaymentGUIPanel.add(payCoinLoonie, gbc);
		gbc.gridx = 0;
		gbc.gridy = 5;
		cashPaymentGUIPanel.add(payCoinToonie, gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		cashPaymentGUIPanel.add(payBanknote5Dollars, gbc);
		gbc.gridx = 1;
		gbc.gridy = 2;
		cashPaymentGUIPanel.add(payBanknote10Dollars, gbc);
		gbc.gridx = 1;
		gbc.gridy = 3;
		cashPaymentGUIPanel.add(payBanknote20Dollars, gbc);
		gbc.gridx = 1;
		gbc.gridy = 4;
		cashPaymentGUIPanel.add(payBanknote50Dollars, gbc);
		gbc.gridx = 1;
		gbc.gridy = 5;
		cashPaymentGUIPanel.add(payBanknote100Dollars, gbc);
		gbc.gridx = 0;
		gbc.gridy = 6;
		gbc.gridwidth = 2;
		cashPaymentGUIPanel.add(confirm, gbc);
	}

	private void refreshTotal() {
		totalPayment.setText("Total Cash Inserted: $" + moneyInserted.setScale(2, RoundingMode.HALF_DOWN));
	}
}

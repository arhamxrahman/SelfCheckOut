package Station;

public interface StationObserver extends ControllerObserver {
	public void callAttendant(StationController stationController);
}

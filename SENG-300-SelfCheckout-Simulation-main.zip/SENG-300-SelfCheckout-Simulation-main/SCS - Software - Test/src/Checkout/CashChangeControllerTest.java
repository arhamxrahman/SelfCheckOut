package Checkout;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.EmptyException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

public class CashChangeControllerTest {
	private SelfCheckoutStation station;
	private BigDecimal testTotal = new BigDecimal(10);
	// private ReceiveChange change;
	// private BigDecimal coinValue = new BigDecimal(0.05);
	int weightLimitTestInGr = 20;
	int sensitivityTest = 5;
	Currency currency = Currency.getInstance(Locale.CANADA);

	@Before
	public void setup() {

		int[] banknoteDenominations = { 5, 10 };
		BigDecimal[] coinDenominations = { new BigDecimal(0.10), new BigDecimal(0.05) };

		this.station = new SelfCheckoutStation(currency, banknoteDenominations, coinDenominations, weightLimitTestInGr,
				sensitivityTest);

		// this.coinPayment = new CoinPayment(testTotal, station);

		// this.coin = new Coin(currency, coinValue);
	}

	@Test
	public void testReceiveCoins() throws EmptyException, DisabledException, OverloadException {
		BigDecimal coinValue = new BigDecimal(0.10);
		Coin coin1 = new Coin(currency, coinValue);
		Coin coin2 = new Coin(currency, coinValue);
		Coin coin3 = new Coin(currency, coinValue);

		station.coinSlot.accept(coin1);
		station.coinSlot.accept(coin2);
		station.coinSlot.accept(coin3);

		BigDecimal coinValue2 = new BigDecimal(0.05);
		Coin coin4 = new Coin(currency, coinValue2);
		Coin coin5 = new Coin(currency, coinValue2);
		Coin coin6 = new Coin(currency, coinValue2);

		station.coinSlot.accept(coin4);
		station.coinSlot.accept(coin5);
		station.coinSlot.accept(coin6);

		BigDecimal changeAmount = new BigDecimal(0.05);
		CashChangeController change = new CashChangeController(changeAmount, station);
		change.giveChange();
	}

	@Test
	public void testReceiveBanknotes() throws EmptyException, DisabledException, OverloadException {
		Banknote bn = new Banknote(currency, 5);
		this.station.banknoteDispensers.get(5).load(bn);
		BigDecimal changeAmount = new BigDecimal(5.0);
		CashChangeController change = new CashChangeController(changeAmount, station);
		change.giveChange();
	}

	@Test
	public void testReceiveMultipleDifferentCoins() throws DisabledException, EmptyException, OverloadException {
		BigDecimal coinValue = new BigDecimal(0.10);
		BigDecimal coinValue2 = new BigDecimal(0.05);
		Coin coin1 = new Coin(currency, coinValue);
		Coin coin2 = new Coin(currency, coinValue);
		Coin coin3 = new Coin(currency, coinValue2);

		station.coinSlot.accept(coin1);
		station.coinSlot.accept(coin2);
		station.coinSlot.accept(coin3);

		BigDecimal changeAmount = new BigDecimal(0.15);
		CashChangeController change = new CashChangeController(changeAmount, station);
		change.giveChange();
	}

	@Test
	public void testReceiveMultipleDifferentBanknotes() throws DisabledException, EmptyException, OverloadException {
		int bnValue = 5;
		int bnValue2 = 10;
		Banknote bn1 = new Banknote(currency, bnValue);
		Banknote bn2 = new Banknote(currency, bnValue2);
		Banknote bn3 = new Banknote(currency, bnValue);

		this.station.banknoteDispensers.get(bnValue).load(bn1);
		this.station.banknoteDispensers.get(bnValue2).load(bn2);
		this.station.banknoteDispensers.get(bnValue).load(bn3);

		BigDecimal changeAmount = new BigDecimal(15.00);
		CashChangeController change = new CashChangeController(changeAmount, station);
		change.giveChange();
	}

}

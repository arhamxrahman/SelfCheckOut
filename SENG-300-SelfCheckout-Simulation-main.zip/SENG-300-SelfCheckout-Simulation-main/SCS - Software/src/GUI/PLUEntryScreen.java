package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.lsmr.selfcheckout.PLUCodedItem;
import org.lsmr.selfcheckout.PriceLookupCode;
import org.lsmr.selfcheckout.external.ProductDatabases;

public class PLUEntryScreen {
	Session session;

	JFrame addingFrame;
	JPanel PLUPanel;
	JTextField pluEntered;

	JButton button0;
	JButton button1;
	JButton button2;
	JButton button3;
	JButton button4;
	JButton button5;
	JButton button6;
	JButton button7;
	JButton button8;
	JButton button9;
	JButton button00;
	JButton clear;

	JButton enter;
	JButton back;

	JFrame pluGUI;

	public PLUEntryScreen(JFrame addingItemsFrame, Session session) {
		this.session = session;
		this.addingFrame = addingItemsFrame;
		pluGUI = new JFrame("Enter Product Number");
		PLUPanel = new JPanel();
		PLUPanel.setLayout(new GridBagLayout());

		addWidgets();

		pluGUI.getContentPane().add(PLUPanel, BorderLayout.CENTER);
		pluGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		pluGUI.setSize(500, 350);
		pluGUI.setVisible(true);
	}

	private void addWidgets() {

		pluEntered = new JTextField();
		pluEntered.setEditable(false);

		button0 = new JButton("0");
		button0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "0");
			}
		});

		button00 = new JButton("00");
		button00.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "00");
			}
		});

		button1 = new JButton("1");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "1");
			}
		});

		button2 = new JButton("2");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "2");
			}
		});

		button3 = new JButton("3");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "3");
			}
		});

		button4 = new JButton("4");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "4");
			}
		});

		button5 = new JButton("5");
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "5");
			}
		});

		button6 = new JButton("6");
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "6");
			}
		});

		button7 = new JButton("7");
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "7");
			}
		});

		button8 = new JButton("8");
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "8");
			}
		});

		button9 = new JButton("9");
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText(pluEntered.getText() + "9");
			}
		});

		clear = new JButton("Clear");
		clear.setBackground(Color.PINK);
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pluEntered.setText("");
			}
		});

		enter = new JButton("Enter");
		enter.setBackground(Color.GREEN);
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PriceLookupCode code = new PriceLookupCode(pluEntered.getText());
				if (ProductDatabases.PLU_PRODUCT_DATABASE.get(code) != null) {
					PLUCodedItem item = new PLUCodedItem(code, 1);
					session.setCurrentItemChoice(item);
					session.setLastEnteredPLU(code);

					addingFrame.setVisible(true); // set to the adding page
					pluGUI.dispose();
				}
			}
		});

		back = new JButton("Back");
		back.setBackground(Color.RED);
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addingFrame.setVisible(true); // set to the adding page
				pluGUI.dispose();
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 3;
		PLUPanel.add(pluEntered, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		PLUPanel.add(button1, gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		PLUPanel.add(button2, gbc);

		gbc.gridx = 2;
		gbc.gridy = 1;
		PLUPanel.add(button3, gbc);

		gbc.gridx = 0;
		gbc.gridy = 2;
		PLUPanel.add(button4, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		PLUPanel.add(button5, gbc);

		gbc.gridx = 2;
		gbc.gridy = 2;
		PLUPanel.add(button6, gbc);

		gbc.gridx = 0;
		gbc.gridy = 3;
		PLUPanel.add(button7, gbc);

		gbc.gridx = 1;
		gbc.gridy = 3;
		PLUPanel.add(button8, gbc);

		gbc.gridx = 2;
		gbc.gridy = 3;
		PLUPanel.add(button9, gbc);

		gbc.gridx = 0;
		gbc.gridy = 4;
		PLUPanel.add(button00, gbc);

		gbc.gridx = 1;
		gbc.gridy = 4;
		PLUPanel.add(button0, gbc);

		gbc.gridx = 2;
		gbc.gridy = 4;
		PLUPanel.add(clear, gbc);

		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.gridwidth = 1;
		PLUPanel.add(back, gbc);

		gbc.gridx = 2;
		gbc.gridy = 5;
		gbc.gridwidth = 2;
		PLUPanel.add(enter, gbc);
	}
}

package GUI;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MembershipSelectionScreen {
	Session session;

	JFrame addingFrame;
	JFrame membershipSelectionFrame;
	JPanel membershipSelectionPanel;

	JLabel membershipLabel;
	JButton manual;
	JButton swipe;

	public MembershipSelectionScreen(JFrame addingFrame, Session session) {
		this.addingFrame = addingFrame;
		this.session = session;
		membershipSelectionFrame = new JFrame("Membership Entry Method");
		membershipSelectionPanel = new JPanel();
		membershipSelectionPanel.setLayout(new GridBagLayout());

		addWidgets();

		membershipSelectionFrame.getContentPane().add(membershipSelectionPanel, BorderLayout.CENTER);
		membershipSelectionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		membershipSelectionFrame.setSize(350, 200);
		membershipSelectionFrame.setVisible(true);
	}

	private void addWidgets() {
		membershipLabel = new JLabel("How would you like to enter membership today?", SwingConstants.CENTER);

		manual = new JButton("Manual Entry");
		swipe = new JButton("Swipe Card");

		manual.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				session.setMembershipEntryChoice("manual");
				MembershipEntryScreen next = new MembershipEntryScreen(addingFrame, session);
				next.membershipFrame.setVisible(true);
				next.membershipFrame.setLocationRelativeTo(addingFrame);
				membershipSelectionFrame.dispose();
			}
		});

		swipe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				session.setMembershipEntryChoice("swipe");
				String dummyMembership = "0000111122223333";
				session.setMembership(dummyMembership);
				try {
					session.getStationController().getStation().cardReader.swipe(session.getCurrentCardForPayment());
				} catch (IOException e1) {

				}
				addingFrame.setVisible(true); // set to the adding page
				membershipSelectionFrame.dispose();
			}
		});

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 2;
		membershipSelectionPanel.add(membershipLabel, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		membershipSelectionPanel.add(manual, gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.gridwidth = 1;
		membershipSelectionPanel.add(swipe, gbc);
	}
}
package Checkout;

import org.lsmr.selfcheckout.devices.ReceiptPrinter;

import Station.ControllerObserver;

public interface ReceiptPrinterTrackerObserver extends ControllerObserver {
	public void lowInk(ReceiptPrinter printer);

	public void lowPaper(ReceiptPrinter printer);

	public void emptyInk(ReceiptPrinter printer);

	public void emptyPaper(ReceiptPrinter printer);
}

package ShoppingCart;

import Station.ControllerObserver;

public interface EnterPLUCodeObserver extends ControllerObserver {
	public void pluProductEntered(EnterPLUCodeController pluCodeEntryController);
}

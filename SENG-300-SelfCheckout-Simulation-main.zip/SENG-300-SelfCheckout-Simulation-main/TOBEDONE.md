# TO BE COMPLETED


## Testing
### ReceiptPrinterTrackerTest: testLowInk, testLowPaper tests need to test the portion of the code that relates to the observer, but I'm not sure how to do it.
## GUI
### Attendant GUIs
### Implementing The Functionality for the GUIs
### PLU lookup GUI
### Lookup By Name

## Use Cases
### Attendant approves a weight discrepancy
### Attendant code hooking to GUI
### Attendant adding paper or ink in AttendantIntervention needs to somehow use the functions in ReceiptPrinterTracker to do so for the tracker to function. The tracker is instantiated in ReceiptController. Maybe there is some other way to notify the tracker how much paper or ink were added?
## Diagrams
###sequence diagrams for:
###card payment - Erica
###scan membership card -emily
###recieve change
###enter plu code
###scan item and bagging area - Erica

package Checkout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.lsmr.selfcheckout.Banknote;
import org.lsmr.selfcheckout.BarcodedItem;
import org.lsmr.selfcheckout.Coin;
import org.lsmr.selfcheckout.Item;
import org.lsmr.selfcheckout.devices.DisabledException;
import org.lsmr.selfcheckout.devices.OverloadException;

import BaseTest.BaseTest;
import Station.ControllerObserver;

public class CashPaymentControllerTest extends BaseTest {

	@Before
	public void setup() throws OverloadException {
		super.setup();
	}

	@Test
	public void testPayWithCashInFull() throws DisabledException, OverloadException {
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		assertTrue(isDisabledFromAddingItems());
		checkout.selectPaymentMethod(PaymentMethod.CASH);
		assertTrue(isEnabledCashPayment());

		scs.banknoteInput.accept(fiveDollars);
		scs.coinSlot.accept(loonie);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 6.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 6.00, 0.0);
		assertTrue(checkout.isPaidInFull());
		assertTrue(isDisabledFromPayments());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);
	}

	@Test
	public void testPayWithCashInTwoPayments() throws DisabledException, OverloadException {
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.banknoteInput.accept(fiveDollars);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 5.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 5.00, 0.0);
		assertFalse(checkout.isPaidInFull());
		assertTrue(isDisabledFromPayments());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);

		Item item3 = new BarcodedItem(barcodeItem3, weightItem3);
		scs.mainScanner.scan(item3);
		scs.baggingArea.add(item3);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.banknoteInput.accept(fiveDollars);
		scs.coinSlot.accept(toonie);
		scs.coinSlot.accept(loonie);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 8.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 13.00, 0.0);
		assertTrue(checkout.isPaidInFull());
		assertTrue(isDisabledFromPayments());
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);
	}

	@Test
	public void testPayWithInvalidCash() throws DisabledException, OverloadException {
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);
		Coin USCoin = new Coin(Currency.getInstance("USD"), new BigDecimal(0.05));

		scs.coinSlot.accept(USCoin);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 0.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 0.00, 0.0);
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);
	}

	@Test
	public void testPayWithInvalidBanknote() throws DisabledException, OverloadException {
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);
		Banknote USBanknote = new Banknote(Currency.getInstance("USD"), 10);

		scs.banknoteInput.accept(USBanknote);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 0.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 0.00, 0.0);
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.PENDING);
	}

	@Test(expected = DisabledException.class)
	public void testCoinValidatorDisability() throws DisabledException, OverloadException {
		scs.coinValidator.disable();
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.coinSlot.accept(loonie);
	}

	@Test
	public void testCoinValidatorEnability() throws DisabledException, OverloadException {
		scs.coinValidator.enable();
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.coinSlot.accept(loonie);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 1.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 1.00, 0.0);
	}

	@Test(expected = DisabledException.class)
	public void testBanknoteValidatorDisability() throws DisabledException, OverloadException {
		scs.banknoteValidator.disable();
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.banknoteInput.accept(fiveDollars);
	}

	@Test
	public void testBanknoteValidatorEnability() throws DisabledException, OverloadException {
		scs.banknoteValidator.enable();
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.banknoteInput.accept(fiveDollars);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 5.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 5.00, 0.0);
	}

	@Test
	public void testCoinDispenserDisabled() throws DisabledException, OverloadException {
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.banknoteInput.accept(fiveDollars);
		scs.coinSlot.accept(toonie);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 7.00, 0.0);

		scs.coinDispensers.get(new BigDecimal(0.05)).disable();
		scs.coinDispensers.get(new BigDecimal(0.10)).disable();
		scs.coinDispensers.get(new BigDecimal(0.25)).disable();
		scs.coinDispensers.get(new BigDecimal(1.00)).disable();
		scs.coinDispensers.get(new BigDecimal(2.00)).disable();

		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 7.00, 0.0);
	}

	@Test
	public void testNoObserverAttached() throws DisabledException, OverloadException {
		Set<ControllerObserver> observers = checkout.getAttachedObservers();
		for (ControllerObserver observer : observers) {
			if (observer instanceof CashPaymentObserver) {
				cashPaymentController.deattach((CashPaymentObserver) observer);
			}
		}
		Item item1 = new BarcodedItem(barcodeItem1, weightItem1);
		scs.mainScanner.scan(item1);
		scs.baggingArea.add(item1);

		checkout.startCheckout();
		checkout.selectPaymentMethod(PaymentMethod.CASH);

		scs.banknoteInput.accept(fiveDollars);
		assertEquals(cashPaymentController.getMoneyInserted().doubleValue(), 5.00, 0.0);
		cashPaymentController.payWithCash();
		assertEquals(checkout.getTotalPayments().doubleValue(), 0.00, 0.0);
		assertEquals(checkout.getPaymentMethod(), PaymentMethod.CASH);
	}

	private boolean isDisabledFromAddingItems() {
		return scs.mainScanner.isDisabled() && scs.mainScanner.isDisabled() && scs.handheldScanner.isDisabled()
				&& scs.scanningArea.isDisabled() && scs.baggingArea.isDisabled() && scs.printer.isDisabled();
	}

	private boolean isEnabledCashPayment() {
		return !scs.coinSlot.isDisabled() && !scs.banknoteInput.isDisabled() && scs.cardReader.isDisabled();
	}

	private boolean isDisabledFromPayments() {
		return !scs.mainScanner.isDisabled() && !scs.handheldScanner.isDisabled() && !scs.scanningArea.isDisabled()
				&& !scs.baggingArea.isDisabled() && scs.coinSlot.isDisabled() && scs.banknoteInput.isDisabled()
				&& scs.cardReader.isDisabled() && !scs.printer.isDisabled();
	}
}

package Checkout;

public enum PaymentMethod {
	CASH, DEBIT, CREDIT, GIFT, PENDING
}

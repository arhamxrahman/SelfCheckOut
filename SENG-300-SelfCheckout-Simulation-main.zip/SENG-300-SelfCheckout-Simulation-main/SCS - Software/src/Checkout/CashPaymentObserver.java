package Checkout;

import java.math.BigDecimal;

import Station.ControllerObserver;

public interface CashPaymentObserver extends ControllerObserver {
	public void paidWithCash(CashPaymentController cashPaymentController, BigDecimal moneyInserted);
}

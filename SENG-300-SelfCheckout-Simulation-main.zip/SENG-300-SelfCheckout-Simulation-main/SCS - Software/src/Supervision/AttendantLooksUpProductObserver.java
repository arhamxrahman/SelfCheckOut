package Supervision;

public interface AttendantLooksUpProductObserver {
	public void pluProductEntered(AttendantLooksUpProduct attendantLooksUpProduct);
}

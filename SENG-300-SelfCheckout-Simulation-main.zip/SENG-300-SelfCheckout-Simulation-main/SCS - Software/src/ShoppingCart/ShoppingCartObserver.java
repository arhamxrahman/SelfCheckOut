package ShoppingCart;

public interface ShoppingCartObserver {
	
	public void itemAdded(ShoppingCart shoppingCart);
	public void baggingAreaWeightDiscrepancy(ShoppingCart shoppingCart);

	public void baggingAreaOverload(ShoppingCart shoppingCart);
}

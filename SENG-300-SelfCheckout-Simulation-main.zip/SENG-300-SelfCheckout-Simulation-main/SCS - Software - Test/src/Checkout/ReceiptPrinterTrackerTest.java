package Checkout;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.Locale;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.lsmr.selfcheckout.devices.EmptyException;
import org.lsmr.selfcheckout.devices.OverloadException;
import org.lsmr.selfcheckout.devices.SelfCheckoutStation;

public class ReceiptPrinterTrackerTest {
	private SelfCheckoutStation station;

	@Before
	public void setup() throws OverloadException {
		int[] banknoteDenominations = { 5 };
		BigDecimal[] coinDenominations = { new BigDecimal(0.10) };

		this.station = new SelfCheckoutStation(Currency.getInstance(Locale.CANADA), banknoteDenominations,
				coinDenominations, 5, 5);
	}

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	/*
	 * @Test public void testAddObserver() { //ReceiptPrinterTracker tracker = new
	 * ReceiptPrinterTracker(station); //ReceiptPrinterTrackerObserver a = new
	 * ReceiptPrinterTrackerObserver(); //tracker.addObserver(a); }
	 * 
	 * @Test public void testRemoveObserver() {
	 * 
	 * }
	 */

	@Test
	public void testPrintNonWhitespace() throws EmptyException, OverloadException {
		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station);
		tracker.addPaper(7);
		tracker.addInk(7);
		tracker.print('a');
		station.printer.cutPaper();
		assertEquals(station.printer.removeReceipt(), "a");
	}

	@Test
	public void testPrintBadWhitespace() throws EmptyException, OverloadException {
		// Might need to test every single type of whitespace
		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station);
		tracker.addPaper(7);
		tracker.addInk(7);
		tracker.print('\t');
		station.printer.cutPaper();
		assertEquals(station.printer.removeReceipt(), "");
	}

	@Test
	public void testPrintNewLine() throws EmptyException, OverloadException {
		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station);
		tracker.addPaper(7);
		tracker.addInk(7);
		tracker.print('\n');
		station.printer.cutPaper();
		assertEquals(station.printer.removeReceipt(), "\n");
	}

	@Test
	public void testLowInk() throws EmptyException, OverloadException {
		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station, 3, 5);
		tracker.addPaper(7);
		tracker.addInk(2);
		tracker.print('a');
		// Not sure how to check if it actually said that ink is low
	}

	@Test
	public void testLowPaper() throws EmptyException, OverloadException {
		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station, 5, 3);
		tracker.addPaper(2);
		tracker.addInk(7);
		tracker.print('\n');
		// Not sure how to check if it actually said that paper is low
	}

	@Test
	public void testEmptyInk() throws EmptyException, OverloadException {
		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station);
		tracker.addPaper(1);
		exceptionRule.expect(EmptyException.class);
		exceptionRule.expectMessage("There is no ink in the printer");
		tracker.print('a');

		// Should also maybe check that it notified that it is empty? Not quite sure if
		// it'll reach that if it encounters an empty exception though.
	}

	@Test
	public void testEmptyPaper() throws EmptyException, OverloadException {
		// The simulation has an error where you can create as many new lines as you
		// want as long as you don't print a character at exactly the point that the
		// paper runs out.
		// It won't throw an empty exception. You can print a character at -17 lines of
		// paper remaining if you print enought new lines, for example.

		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station);
		tracker.addInk(5);
		tracker.addPaper(1);
		exceptionRule.expect(EmptyException.class);
		exceptionRule.expectMessage("There is no paper in the printer");
		tracker.print('\n');
		tracker.print('a');

		// Should also maybe check that it notified that it is empty? Not quite sure if
		// it'll reach that if it encounters an empty exception though.
	}

	@Test
	public void testEmptyBoth() throws EmptyException, OverloadException {
		ReceiptPrinterTracker tracker = new ReceiptPrinterTracker(station);
		tracker.addPaper(1);
		exceptionRule.expect(EmptyException.class);
		tracker.print('\n');
		tracker.print('a');

		// Should also maybe check that it notified that it is empty? Not quite sure if
		// it'll reach that if it encounters an empty exception though.
	}
}
